# Future Architecture Note: Per-Machine Learners, Shared Corpus, and Agent Junction

This note expands the speculative section of the manuscript.

## Local machine learner

Each machine hosts a local learner that maintains:
- raw episodic observations when permitted
- distilled summaries
- task-specific replay buffers
- local eval probes
- adapters or small local model heads
- privacy policy and provenance logs

## Shared corpus

A shared corpus is not a dump. It is a governed memory substrate:
- source-tracked
- temporally versioned
- quality scored
- contradiction-aware
- privacy filtered
- replay-value estimated

## Agent junction

The agent junction decides:
- what is exported from local learners
- what is consolidated into shared memory
- what should be replayed to which agents
- what should be quarantined
- what has enough provenance to become durable

This remains an open design problem. The small experiments in this bundle should be viewed as seed experiments for the memory mechanics, not as an implementation of a collective intelligence system.
