lifelong_starter_corpus

This is a synthetic staged corpus for micro_lifelong_llm.py.
Each .txt file is one learning phase.

01_simple_stories.txt
02_synthetic_clinical_microcases.txt
03_code_patterns.txt
04_math_logic.txt
05_poetry_reflection.txt

Why synthetic?
- No copyright issues.
- Clear phase boundaries.
- Repeated anchor facts make forgetting easier to see.
- Different styles force interference: story, clinical prose, code, math, poetry.

Suggested run:
python micro_lifelong_llm.py --corpus-dir lifelong_starter_corpus --steps-per-phase 400 --memory-per-phase 300 --generate-every-phase

Memory-density runs:
python micro_lifelong_llm.py --corpus-dir lifelong_starter_corpus --out-dir run_mem50 --memory-per-phase 50 --steps-per-phase 500
python micro_lifelong_llm.py --corpus-dir lifelong_starter_corpus --out-dir run_mem300 --memory-per-phase 300 --steps-per-phase 500
python micro_lifelong_llm.py --corpus-dir lifelong_starter_corpus --out-dir run_mem1000 --memory-per-phase 1000 --steps-per-phase 500

Probe anchor phrases after final phase:
the red key opens the moon gate
low serum osmolality and high urine osmolality suggest SIADH
def add_one(x): return x + 1
even plus even is even
the quiet machine remembers softly
