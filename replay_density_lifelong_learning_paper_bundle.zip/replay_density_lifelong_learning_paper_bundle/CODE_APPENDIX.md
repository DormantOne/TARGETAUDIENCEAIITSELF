# Code Appendix: Verbatim Programs

This appendix reproduces the included programs verbatim so the experiments can be re-engineered from the bundle.


---

## emnist_alphabet_ablation.py

```python
# emnist_alphabet_ablation.py
#
# Continual-learning alphabet experiment using EMNIST Letters.
#
# This is the alphabet analog of the MNIST ablation:
#   Phase 1: train a conventional CNN on most letters.
#   Phase 2: train on held-out letters, optionally with a tiny old-letter replay loop.
#   Compare random replay, curated replay, anchoring, distillation, and soft consolidation.
#
# The CNN architecture is identical for every strategy.
# Phase 1 is trained ONCE per seed, saved, then reloaded for every Phase-2 condition.
#
# Requirements:
#   pip install torch torchvision
#
# Default long-ish run:
#   python emnist_alphabet_ablation.py
#
# Faster smoke test:
#   python emnist_alphabet_ablation.py --phase1-epochs 1 --phase2-epochs 1 --replay-fractions 0,0.02 --max-old-per-class 1000 --max-new-per-class 1000
#
# More serious run:
#   python emnist_alphabet_ablation.py --seeds 42,43,44 --replay-fractions 0,0.005,0.01,0.02,0.05,0.10,0.20
#
# Notes:
#   EMNIST Letters has 26 classes. Torchvision's raw labels are commonly 1..26;
#   this script auto-remaps them to 0..25.
#
#   Default held-out letters are: C,F,J,Q,V,X,Y,Z
#   That is 8/26 letters, roughly analogous to holding out 3/10 MNIST digits.

import argparse
import csv
import copy
import random
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import ConcatDataset, DataLoader, Dataset, Subset
from torchvision import datasets, transforms
from torchvision.transforms import functional as TF


# -----------------------------
# Strategy definitions
# -----------------------------


@dataclass(frozen=True)
class Strategy:
    name: str
    replay_kind: str  # "none", "random", "curated"
    anchor_strength: float = 0.0
    distill_strength: float = 0.0
    soft_consolidation: bool = False


STRATEGIES: List[Strategy] = [
    Strategy("No replay", "none"),
    Strategy("Random replay", "random"),
    Strategy("Curated replay", "curated"),

    Strategy("Random replay + anchor", "random", anchor_strength=5.0),
    Strategy("Curated replay + anchor", "curated", anchor_strength=5.0),

    Strategy("Random replay + distill", "random", distill_strength=0.70),
    Strategy("Curated replay + distill", "curated", distill_strength=0.70),

    Strategy("Random replay + anchor/distill", "random", anchor_strength=5.0, distill_strength=0.70),
    Strategy("Curated replay + anchor/distill", "curated", anchor_strength=5.0, distill_strength=0.70),

    Strategy(
        "Random replay + soft + anchor/distill",
        "random",
        anchor_strength=5.0,
        distill_strength=0.70,
        soft_consolidation=True,
    ),
    Strategy(
        "Curated replay + soft + anchor/distill",
        "curated",
        anchor_strength=5.0,
        distill_strength=0.70,
        soft_consolidation=True,
    ),
]


# -----------------------------
# Utility
# -----------------------------


ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def idx_to_letter(i: int) -> str:
    return ALPHABET[int(i)]


def class_list_to_letters(classes: Sequence[int]) -> str:
    return ",".join(idx_to_letter(c) for c in classes)


def parse_letters_or_indices(text: str) -> List[int]:
    """
    Accepts either letters, e.g. "C,F,J,Q,V,X,Y,Z", or zero-based indices, e.g. "2,5,9".
    """
    out: List[int] = []
    for raw in text.split(","):
        token = raw.strip()
        if not token:
            continue
        if token.isdigit() or (token.startswith("-") and token[1:].isdigit()):
            val = int(token)
            if not (0 <= val < 26):
                raise ValueError(f"Class index out of range 0..25: {val}")
            out.append(val)
        else:
            ch = token.upper()
            if len(ch) != 1 or ch not in ALPHABET:
                raise ValueError(f"Expected a letter A-Z or class index 0-25, got: {token}")
            out.append(ALPHABET.index(ch))
    # Preserve order but remove duplicates.
    seen = set()
    deduped = []
    for x in out:
        if x not in seen:
            seen.add(x)
            deduped.append(x)
    return deduped


def parse_floats(text: str) -> List[float]:
    out = []
    for raw in text.split(","):
        token = raw.strip()
        if not token:
            continue
        val = float(token)
        if val < 0.0 or val >= 1.0:
            raise ValueError("Replay fractions must be >= 0.0 and < 1.0")
        out.append(val)
    return out


def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in text.split(",") if x.strip()]


def pct(x: float) -> str:
    return f"{100.0 * x:5.1f}%"


def acc_fmt(x: float) -> str:
    return f"{x:.4f}"


def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# -----------------------------
# Dataset wrappers and helpers
# -----------------------------


class RemappedEMNISTLetters(Dataset):
    """
    Wrap EMNIST Letters so labels are always 0..25.
    Torchvision's EMNIST letters split usually returns 1..26.
    """

    def __init__(self, base: Dataset):
        self.base = base
        raw_targets = getattr(base, "targets", None)
        if raw_targets is None:
            vals = [int(base[i][1]) for i in range(min(1000, len(base)))]
            mn, mx = min(vals), max(vals)
        else:
            mn, mx = int(torch.as_tensor(raw_targets).min().item()), int(torch.as_tensor(raw_targets).max().item())
        self.offset = 1 if mn == 1 and mx == 26 else 0

        if raw_targets is not None:
            self.targets = torch.as_tensor(raw_targets, dtype=torch.long) - self.offset
        else:
            self.targets = torch.tensor([int(base[i][1]) - self.offset for i in range(len(base))], dtype=torch.long)

    def __len__(self) -> int:
        return len(self.base)

    def __getitem__(self, idx: int):
        x, y = self.base[idx]
        return x, int(y) - self.offset


class FlaggedDataset(Dataset):
    """Wraps a dataset so it returns (x, y, is_replay_old)."""

    def __init__(self, dataset: Dataset, is_replay_old: bool):
        self.dataset = dataset
        self.is_replay_old = bool(is_replay_old)

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int):
        x, y = self.dataset[idx]
        return x, int(y), 1 if self.is_replay_old else 0


def filter_by_classes(dataset: Dataset, classes: Sequence[int]) -> Subset:
    wanted = set(int(c) for c in classes)
    if hasattr(dataset, "targets"):
        labels = dataset.targets
        indices = [i for i, y in enumerate(labels) if int(y) in wanted]
    else:
        indices = [i for i, (_, y) in enumerate(dataset) if int(y) in wanted]
    return Subset(dataset, indices)


def subset_label(subset: Subset, local_idx: int) -> int:
    base_idx = subset.indices[local_idx]
    base = subset.dataset
    if hasattr(base, "targets"):
        return int(base.targets[base_idx])
    return int(base[base_idx][1])


def subsample_per_class(
    subset: Subset,
    classes: Sequence[int],
    max_per_class: Optional[int],
    seed: int,
) -> Subset:
    if max_per_class is None or max_per_class <= 0:
        return subset
    rng = random.Random(seed)
    by_class: Dict[int, List[int]] = {int(c): [] for c in classes}
    for local_i in range(len(subset)):
        y = subset_label(subset, local_i)
        if y in by_class:
            by_class[y].append(local_i)

    chosen_local: List[int] = []
    for c in classes:
        pool = by_class[int(c)]
        if len(pool) > max_per_class:
            chosen_local.extend(rng.sample(pool, max_per_class))
        else:
            chosen_local.extend(pool)
    rng.shuffle(chosen_local)

    # Convert local indices in the original subset into base dataset indices for a new Subset.
    chosen_base_indices = [subset.indices[i] for i in chosen_local]
    return Subset(subset.dataset, chosen_base_indices)


def make_emnist_transform(fix_orientation: bool = True):
    parts = []
    if fix_orientation:
        # Common EMNIST correction: rotate then horizontal flip.
        # The CNN would learn either way, but this makes saved examples human-readable.
        parts.append(transforms.Lambda(lambda img: TF.hflip(TF.rotate(img, -90))))
    parts.extend([
        transforms.ToTensor(),
        transforms.Normalize((0.1736,), (0.3317,)),
    ])
    return transforms.Compose(parts)


def make_loaders(
    data_dir: str,
    batch_size: int,
    old_classes: List[int],
    held_out_classes: List[int],
    max_old_per_class: Optional[int],
    max_new_per_class: Optional[int],
    seed: int,
    fix_orientation: bool = True,
) -> Tuple[DataLoader, DataLoader, DataLoader, DataLoader, DataLoader, Subset, Subset, Dataset, Dataset]:
    transform = make_emnist_transform(fix_orientation=fix_orientation)

    train_raw = datasets.EMNIST(root=data_dir, split="letters", train=True, download=True, transform=transform)
    test_raw = datasets.EMNIST(root=data_dir, split="letters", train=False, download=True, transform=transform)

    train_full = RemappedEMNISTLetters(train_raw)
    test_full = RemappedEMNISTLetters(test_raw)

    train_old = filter_by_classes(train_full, old_classes)
    train_new = filter_by_classes(train_full, held_out_classes)

    train_old = subsample_per_class(train_old, old_classes, max_old_per_class, seed=seed + 1001)
    train_new = subsample_per_class(train_new, held_out_classes, max_new_per_class, seed=seed + 1002)

    test_old = filter_by_classes(test_full, old_classes)
    test_new = filter_by_classes(test_full, held_out_classes)

    train_old_loader = DataLoader(train_old, batch_size=batch_size, shuffle=True)
    train_new_loader = DataLoader(train_new, batch_size=batch_size, shuffle=True)
    test_old_loader = DataLoader(test_old, batch_size=batch_size, shuffle=False)
    test_new_loader = DataLoader(test_new, batch_size=batch_size, shuffle=False)
    test_all_loader = DataLoader(test_full, batch_size=batch_size, shuffle=False)

    return (
        train_old_loader,
        train_new_loader,
        test_old_loader,
        test_new_loader,
        test_all_loader,
        train_old,
        train_new,
        train_full,
        test_full,
    )


# -----------------------------
# Model
# -----------------------------


class SmallCNN(nn.Module):
    def __init__(self, num_classes: int = 26) -> None:
        super().__init__()
        self.num_classes = num_classes
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, num_classes)

    def features(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = torch.flatten(x, 1)
        x = F.relu(self.fc1(x))
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.features(x)
        return self.fc2(z)


# -----------------------------
# Optimizers and losses
# -----------------------------


def make_optimizer(model: SmallCNN, strategy: Optional[Strategy] = None) -> torch.optim.Optimizer:
    """
    Same architecture for all strategies.
    Soft consolidation only changes Phase-2 learning rates, not layers/parameters.
    """
    if strategy is not None and strategy.soft_consolidation:
        groups = [
            {"name": "conv1", "params": model.conv1.parameters(), "lr": 3e-4},
            {"name": "conv2", "params": model.conv2.parameters(), "lr": 5e-4},
            {"name": "fc1", "params": model.fc1.parameters(), "lr": 8e-4},
            {"name": "fc2", "params": model.fc2.parameters(), "lr": 1e-3},
        ]
    else:
        groups = [
            {"name": "conv1", "params": model.conv1.parameters(), "lr": 1e-3},
            {"name": "conv2", "params": model.conv2.parameters(), "lr": 1e-3},
            {"name": "fc1", "params": model.fc1.parameters(), "lr": 1e-3},
            {"name": "fc2", "params": model.fc2.parameters(), "lr": 1e-3},
        ]
    return torch.optim.Adam(groups)


def mask_logits_to_classes(logits: torch.Tensor, allowed_classes: Optional[List[int]]) -> torch.Tensor:
    if allowed_classes is None:
        return logits
    masked = torch.full_like(logits, -1e9)
    allowed = torch.tensor(allowed_classes, dtype=torch.long, device=logits.device)
    masked[:, allowed] = logits[:, allowed]
    return masked


def parameter_anchor_loss(model: nn.Module, anchor_state: Dict[str, torch.Tensor]) -> torch.Tensor:
    total = None
    count = 0
    for name, p in model.named_parameters():
        old = anchor_state[name].to(p.device)
        term = (p - old).pow(2).sum()
        total = term if total is None else total + term
        count += p.numel()
    assert total is not None
    return total / max(1, count)


def distillation_loss(student_logits: torch.Tensor, teacher_logits: torch.Tensor, temperature: float) -> torch.Tensor:
    t = temperature
    student_log_probs = F.log_softmax(student_logits / t, dim=1)
    teacher_probs = F.softmax(teacher_logits / t, dim=1)
    return F.kl_div(student_log_probs, teacher_probs, reduction="batchmean") * (t * t)


# -----------------------------
# Training and evaluation
# -----------------------------


def train_phase1_epoch(
    model: SmallCNN,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: str,
    old_classes: List[int],
) -> float:
    model.train()
    total_loss = 0.0
    total_seen = 0
    for x, y in loader:
        x = x.to(device)
        y = y.to(device)
        optimizer.zero_grad(set_to_none=True)
        logits = mask_logits_to_classes(model(x), old_classes)
        loss = F.cross_entropy(logits, y)
        loss.backward()
        optimizer.step()
        total_loss += float(loss.item()) * x.size(0)
        total_seen += x.size(0)
    return total_loss / max(1, total_seen)


@torch.no_grad()
def accuracy(model: SmallCNN, loader: DataLoader, device: str) -> float:
    model.eval()
    correct = 0
    total = 0
    for x, y in loader:
        x = x.to(device)
        y = y.to(device)
        logits = model(x)
        pred = logits.argmax(dim=1)
        correct += int((pred == y).sum().item())
        total += int(y.numel())
    return correct / max(1, total)


# -----------------------------
# Memory selection
# -----------------------------


def replay_budget(n_new: int, replay_fraction: float, max_old: int) -> int:
    """
    If replay_fraction is the fraction of the Phase-2 mixed dataset that is old:
        budget / (budget + n_new) = replay_fraction
    """
    if replay_fraction <= 0.0:
        return 0
    n = int((replay_fraction / (1.0 - replay_fraction)) * n_new)
    return max(1, min(n, max_old))


def indices_by_class(subset: Subset, classes: List[int]) -> Dict[int, List[int]]:
    out = {int(c): [] for c in classes}
    for i in range(len(subset)):
        y = subset_label(subset, i)
        if y in out:
            out[y].append(i)
    return out


def balanced_random_indices(train_old: Subset, old_classes: List[int], budget: int, seed: int) -> List[int]:
    if budget <= 0:
        return []
    rng = random.Random(seed)
    by_class = indices_by_class(train_old, old_classes)
    selected: List[int] = []

    base = budget // len(old_classes)
    extra = budget % len(old_classes)
    shuffled_classes = list(old_classes)
    rng.shuffle(shuffled_classes)

    for rank, c in enumerate(shuffled_classes):
        k = base + (1 if rank < extra else 0)
        pool = by_class[c]
        if not pool:
            continue
        selected.extend(rng.sample(pool, min(k, len(pool))))

    if len(selected) < budget:
        remaining = list(set(range(len(train_old))) - set(selected))
        rng.shuffle(remaining)
        selected.extend(remaining[: budget - len(selected)])

    rng.shuffle(selected)
    return selected[:budget]


@torch.no_grad()
def curated_indices(
    model: SmallCNN,
    train_old: Subset,
    old_classes: List[int],
    budget: int,
    batch_size: int,
    device: str,
    seed: int,
    hard_fraction: float = 0.50,
) -> List[int]:
    """
    Curated memory selection.

    For each old class, select a balanced mix of:
      1. hard examples: low confidence for the true class
      2. representative examples: closest to the feature centroid

    This intentionally tests whether model-chosen memory beats random memory.
    """
    if budget <= 0:
        return []

    loader = DataLoader(train_old, batch_size=batch_size, shuffle=False)
    model.eval()

    all_features: List[torch.Tensor] = []
    all_labels: List[torch.Tensor] = []
    all_conf: List[torch.Tensor] = []

    for x, y in loader:
        x = x.to(device)
        y = y.to(device)
        feats = model.features(x)
        logits = model.fc2(feats)
        probs = F.softmax(logits, dim=1)
        conf = probs.gather(1, y.view(-1, 1)).squeeze(1)
        all_features.append(feats.cpu())
        all_labels.append(y.cpu())
        all_conf.append(conf.cpu())

    features = torch.cat(all_features, dim=0)
    labels = torch.cat(all_labels, dim=0)
    confs = torch.cat(all_conf, dim=0)

    rng = random.Random(seed)
    selected: List[int] = []

    base = budget // len(old_classes)
    extra = budget % len(old_classes)
    class_order = list(old_classes)
    rng.shuffle(class_order)

    for rank, c in enumerate(class_order):
        k = base + (1 if rank < extra else 0)
        class_idxs = (labels == c).nonzero(as_tuple=False).view(-1)
        if class_idxs.numel() == 0 or k <= 0:
            continue

        class_features = features[class_idxs]
        class_confs = confs[class_idxs]

        k_hard = int(round(k * hard_fraction))
        k_hard = min(k_hard, class_idxs.numel())
        hard_local = torch.argsort(class_confs, descending=False)[:k_hard]
        hard_global = class_idxs[hard_local].tolist()

        k_rep = k - len(hard_global)
        centroid = class_features.mean(dim=0, keepdim=True)
        dist = torch.norm(class_features - centroid, dim=1)
        rep_order = torch.argsort(dist, descending=False).tolist()

        chosen_for_class = list(hard_global)
        used = set(chosen_for_class)
        for local_idx in rep_order:
            global_idx = int(class_idxs[local_idx].item())
            if global_idx in used:
                continue
            chosen_for_class.append(global_idx)
            used.add(global_idx)
            if len(chosen_for_class) >= k:
                break

        # If k_hard consumed everything or there were duplicates, this still covers the class.
        if len(chosen_for_class) < k and k_rep > 0:
            remaining_order = list(range(class_idxs.numel()))
            rng.shuffle(remaining_order)
            for local_idx in remaining_order:
                global_idx = int(class_idxs[local_idx].item())
                if global_idx in used:
                    continue
                chosen_for_class.append(global_idx)
                used.add(global_idx)
                if len(chosen_for_class) >= k:
                    break

        selected.extend(chosen_for_class[:k])

    if len(selected) < budget:
        remaining = list(set(range(len(train_old))) - set(selected))
        rng.shuffle(remaining)
        selected.extend(remaining[: budget - len(selected)])

    rng.shuffle(selected)
    return selected[:budget]


def make_phase2_loader(
    train_new: Subset,
    train_old: Subset,
    replay_indices: List[int],
    batch_size: int,
    seed: int,
) -> DataLoader:
    datasets_for_phase2: List[Dataset] = [FlaggedDataset(train_new, is_replay_old=False)]
    if replay_indices:
        replay_subset = Subset(train_old, replay_indices)
        datasets_for_phase2.append(FlaggedDataset(replay_subset, is_replay_old=True))
    mixed = ConcatDataset(datasets_for_phase2)
    generator = torch.Generator()
    generator.manual_seed(seed)
    return DataLoader(mixed, batch_size=batch_size, shuffle=True, generator=generator)


# -----------------------------
# Phase 2 training
# -----------------------------


def train_phase2_epoch(
    model: SmallCNN,
    teacher: SmallCNN,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    strategy: Strategy,
    anchor_state: Dict[str, torch.Tensor],
    device: str,
    temperature: float,
) -> Dict[str, float]:
    model.train()
    teacher.eval()

    total_loss = 0.0
    total_ce = 0.0
    total_anchor = 0.0
    total_distill = 0.0
    total_seen = 0

    for x, y, is_old in loader:
        x = x.to(device)
        y = y.to(device)
        is_old = is_old.to(device).bool()

        optimizer.zero_grad(set_to_none=True)
        logits = model(x)
        ce = F.cross_entropy(logits, y)

        anchor = torch.zeros((), device=device)
        if strategy.anchor_strength > 0.0:
            anchor = parameter_anchor_loss(model, anchor_state)

        distill = torch.zeros((), device=device)
        if strategy.distill_strength > 0.0 and is_old.any():
            with torch.no_grad():
                teacher_logits = teacher(x[is_old])
            student_logits = logits[is_old]
            distill = distillation_loss(student_logits, teacher_logits, temperature=temperature)

        loss = ce + strategy.anchor_strength * anchor + strategy.distill_strength * distill
        loss.backward()
        optimizer.step()

        n = x.size(0)
        total_loss += float(loss.item()) * n
        total_ce += float(ce.item()) * n
        total_anchor += float(anchor.item()) * n
        total_distill += float(distill.item()) * n
        total_seen += n

    denom = max(1, total_seen)
    return {
        "loss": total_loss / denom,
        "ce": total_ce / denom,
        "anchor": total_anchor / denom,
        "distill": total_distill / denom,
    }


# -----------------------------
# Experiment
# -----------------------------


def select_replay_indices(
    strategy: Strategy,
    replay_fraction: float,
    model_after_phase1: SmallCNN,
    train_old: Subset,
    train_new: Subset,
    old_classes: List[int],
    batch_size: int,
    device: str,
    seed: int,
) -> List[int]:
    if strategy.replay_kind == "none":
        return []

    budget = replay_budget(len(train_new), replay_fraction, len(train_old))
    if budget <= 0:
        return []

    if strategy.replay_kind == "random":
        return balanced_random_indices(train_old, old_classes, budget, seed=seed)

    if strategy.replay_kind == "curated":
        return curated_indices(
            model=model_after_phase1,
            train_old=train_old,
            old_classes=old_classes,
            budget=budget,
            batch_size=batch_size,
            device=device,
            seed=seed,
            hard_fraction=0.50,
        )

    raise ValueError(f"Unknown replay_kind: {strategy.replay_kind}")


def train_phase1_once(
    seed: int,
    train_old_loader: DataLoader,
    test_old_loader: DataLoader,
    test_new_loader: DataLoader,
    test_all_loader: DataLoader,
    old_classes: List[int],
    phase1_epochs: int,
    device: str,
    quiet: bool,
) -> Tuple[Dict[str, torch.Tensor], Dict[str, float], SmallCNN]:
    set_seed(seed)
    model = SmallCNN(num_classes=26).to(device)
    optimizer = make_optimizer(model, strategy=None)

    if not quiet:
        print("\n" + "#" * 120)
        print(f"PHASE 1: train one conventional CNN on old letters only | seed={seed}")
        print("#" * 120)

    for epoch in range(1, phase1_epochs + 1):
        loss = train_phase1_epoch(model, train_old_loader, optimizer, device, old_classes)
        old_acc_now = accuracy(model, test_old_loader, device)
        if not quiet:
            print(f"Phase 1 epoch {epoch:02d} | loss {loss:.4f} | old_acc {old_acc_now:.4f}")

    old_p1 = accuracy(model, test_old_loader, device)
    new_p1 = accuracy(model, test_new_loader, device)
    all_p1 = accuracy(model, test_all_loader, device)

    if not quiet:
        print(f"Phase 1 saved state | old={old_p1:.4f} | new={new_p1:.4f} | all={all_p1:.4f}")

    state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    teacher = SmallCNN(num_classes=26).to(device)
    teacher.load_state_dict(copy.deepcopy(state))
    teacher.eval()
    for p in teacher.parameters():
        p.requires_grad_(False)

    metrics = {"old_p1": old_p1, "new_p1": new_p1, "all_p1": all_p1}
    return state, metrics, teacher


def run_one_condition(
    seed: int,
    replay_fraction: float,
    strategy: Strategy,
    phase1_state: Dict[str, torch.Tensor],
    phase1_metrics: Dict[str, float],
    teacher: SmallCNN,
    train_old: Subset,
    train_new: Subset,
    test_old_loader: DataLoader,
    test_new_loader: DataLoader,
    test_all_loader: DataLoader,
    old_classes: List[int],
    batch_size: int,
    phase2_epochs: int,
    device: str,
    temperature: float,
    condition_seed: int,
    quiet: bool,
) -> Dict[str, object]:
    model = SmallCNN(num_classes=26).to(device)
    model.load_state_dict(copy.deepcopy(phase1_state))
    optimizer = make_optimizer(model, strategy)

    replay_indices = select_replay_indices(
        strategy=strategy,
        replay_fraction=replay_fraction,
        model_after_phase1=teacher,
        train_old=train_old,
        train_new=train_new,
        old_classes=old_classes,
        batch_size=batch_size,
        device=device,
        seed=condition_seed,
    )

    phase2_loader = make_phase2_loader(
        train_new=train_new,
        train_old=train_old,
        replay_indices=replay_indices,
        batch_size=batch_size,
        seed=condition_seed + 77,
    )

    anchor_state = {k: v.detach().clone().to(device) for k, v in phase1_state.items()}

    if not quiet:
        print("=" * 140)
        print(f"Seed={seed} | Replay={pct(replay_fraction)} | {strategy.name} | budget={len(replay_indices)}")
        print("=" * 140)

    last_losses = {"loss": 0.0, "ce": 0.0, "anchor": 0.0, "distill": 0.0}
    for epoch in range(1, phase2_epochs + 1):
        last_losses = train_phase2_epoch(
            model=model,
            teacher=teacher,
            loader=phase2_loader,
            optimizer=optimizer,
            strategy=strategy,
            anchor_state=anchor_state,
            device=device,
            temperature=temperature,
        )
        old_acc_now = accuracy(model, test_old_loader, device)
        if not quiet:
            print(
                f"Phase 2 epoch {epoch:02d} | "
                f"loss {last_losses['loss']:.4f} | "
                f"ce {last_losses['ce']:.4f} | "
                f"anchor {last_losses['anchor']:.6f} | "
                f"distill {last_losses['distill']:.4f} | "
                f"old_acc {old_acc_now:.4f}"
            )

    old_p2 = accuracy(model, test_old_loader, device)
    new_p2 = accuracy(model, test_new_loader, device)
    all_p2 = accuracy(model, test_all_loader, device)
    forgetting = phase1_metrics["old_p1"] - old_p2
    stability_score = all_p2 - forgetting
    harmonic_old_new = 2.0 * old_p2 * new_p2 / max(1e-12, old_p2 + new_p2)

    result: Dict[str, object] = {
        "seed": seed,
        "replay_fraction": replay_fraction,
        "strategy": strategy.name,
        "replay_kind": strategy.replay_kind,
        "budget": len(replay_indices),
        "anchor_strength": strategy.anchor_strength,
        "distill_strength": strategy.distill_strength,
        "soft_consolidation": strategy.soft_consolidation,
        "old_p1": phase1_metrics["old_p1"],
        "new_p1": phase1_metrics["new_p1"],
        "all_p1": phase1_metrics["all_p1"],
        "old_p2": old_p2,
        "new_p2": new_p2,
        "all_p2": all_p2,
        "forgetting": forgetting,
        "stability_score": stability_score,
        "harmonic_old_new": harmonic_old_new,
        "final_loss": last_losses["loss"],
        "final_ce": last_losses["ce"],
        "final_anchor_loss": last_losses["anchor"],
        "final_distill_loss": last_losses["distill"],
    }

    if not quiet:
        print(
            f"Result | Old P2={old_p2:.4f} | New P2={new_p2:.4f} | "
            f"All P2={all_p2:.4f} | Forget={forgetting:.4f} | "
            f"Score={stability_score:.4f} | H(old,new)={harmonic_old_new:.4f}\n"
        )

    return result


# -----------------------------
# Reporting
# -----------------------------


def print_results(results: List[Dict[str, object]]) -> None:
    print("\nFINAL ALPHABET ABLATION RESULTS")
    print("=" * 176)
    print(
        f"{'Seed':>5s} {'Replay':>8s} {'Strategy':52s} {'Budget':>7s} "
        f"{'Old P2':>8s} {'New P2':>8s} {'All P2':>8s} {'Forget':>8s} "
        f"{'Score':>8s} {'Harmonic':>9s}"
    )
    print("-" * 176)

    for r in sorted(results, key=lambda x: (int(x["seed"]), float(x["replay_fraction"]), str(x["strategy"]))):
        print(
            f"{int(r['seed']):5d} {pct(float(r['replay_fraction'])):>8s} "
            f"{str(r['strategy']):52s} {int(r['budget']):7d} "
            f"{acc_fmt(float(r['old_p2'])):>8s} {acc_fmt(float(r['new_p2'])):>8s} "
            f"{acc_fmt(float(r['all_p2'])):>8s} {acc_fmt(float(r['forgetting'])):>8s} "
            f"{acc_fmt(float(r['stability_score'])):>8s} {acc_fmt(float(r['harmonic_old_new'])):>9s}"
        )


def average_results(results: List[Dict[str, object]]) -> List[Dict[str, object]]:
    grouped: Dict[Tuple[float, str], List[Dict[str, object]]] = {}
    for r in results:
        key = (float(r["replay_fraction"]), str(r["strategy"]))
        grouped.setdefault(key, []).append(r)

    avg_rows: List[Dict[str, object]] = []
    numeric_fields = [
        "budget",
        "old_p1",
        "new_p1",
        "all_p1",
        "old_p2",
        "new_p2",
        "all_p2",
        "forgetting",
        "stability_score",
        "harmonic_old_new",
        "final_loss",
        "final_ce",
        "final_anchor_loss",
        "final_distill_loss",
    ]

    for (frac, strat), rows in grouped.items():
        out: Dict[str, object] = {
            "replay_fraction": frac,
            "strategy": strat,
            "n_seeds": len(rows),
        }
        for field in numeric_fields:
            vals = [float(r[field]) for r in rows]
            out[field] = sum(vals) / len(vals)
        avg_rows.append(out)

    return sorted(avg_rows, key=lambda x: (float(x["replay_fraction"]), str(x["strategy"])))


def print_average_results(avg_rows: List[Dict[str, object]]) -> None:
    print("\nAVERAGE RESULTS OVER SEEDS")
    print("=" * 176)
    print(
        f"{'Replay':>8s} {'Strategy':52s} {'Seeds':>5s} {'Budget':>7s} "
        f"{'Old P2':>8s} {'New P2':>8s} {'All P2':>8s} {'Forget':>8s} "
        f"{'Score':>8s} {'Harmonic':>9s}"
    )
    print("-" * 176)
    for r in avg_rows:
        print(
            f"{pct(float(r['replay_fraction'])):>8s} {str(r['strategy']):52s} {int(r['n_seeds']):5d} "
            f"{float(r['budget']):7.1f} {acc_fmt(float(r['old_p2'])):>8s} "
            f"{acc_fmt(float(r['new_p2'])):>8s} {acc_fmt(float(r['all_p2'])):>8s} "
            f"{acc_fmt(float(r['forgetting'])):>8s} {acc_fmt(float(r['stability_score'])):>8s} "
            f"{acc_fmt(float(r['harmonic_old_new'])):>9s}"
        )


def print_best_by_replay(avg_rows: List[Dict[str, object]]) -> None:
    print("\nBEST BY REPLAY FRACTION")
    print("=" * 176)
    print("Primary sort: stability_score = All P2 - Forget. Secondary: harmonic mean of Old P2 and New P2.")
    print("-" * 176)
    fracs = sorted(set(float(r["replay_fraction"]) for r in avg_rows))
    for frac in fracs:
        rows = [r for r in avg_rows if float(r["replay_fraction"]) == frac]
        best = sorted(
            rows,
            key=lambda r: (float(r["stability_score"]), float(r["harmonic_old_new"]), float(r["all_p2"])),
            reverse=True,
        )[0]
        print(
            f"Replay {pct(frac)} | best: {best['strategy']} | "
            f"Old P2={float(best['old_p2']):.4f} | "
            f"New P2={float(best['new_p2']):.4f} | "
            f"All P2={float(best['all_p2']):.4f} | "
            f"Forget={float(best['forgetting']):.4f} | "
            f"Score={float(best['stability_score']):.4f} | "
            f"H={float(best['harmonic_old_new']):.4f}"
        )


def save_csv(path: str, rows: List[Dict[str, object]]) -> None:
    if not rows:
        return
    fieldnames = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


# -----------------------------
# Main
# -----------------------------


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=str, default="./data")
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--phase1-epochs", type=int, default=3)
    parser.add_argument("--phase2-epochs", type=int, default=3)
    parser.add_argument("--held-out-letters", type=str, default="C,F,J,Q,V,X,Y,Z")
    parser.add_argument("--replay-fractions", type=str, default="0,0.005,0.01,0.02,0.05,0.10,0.20")
    parser.add_argument("--seeds", type=str, default="42")
    parser.add_argument("--temperature", type=float, default=2.0)
    parser.add_argument("--csv", type=str, default="emnist_alphabet_ablation_results.csv")
    parser.add_argument("--avg-csv", type=str, default="emnist_alphabet_ablation_avg_results.csv")
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--no-fix-orientation", action="store_true")
    parser.add_argument(
        "--max-old-per-class",
        type=int,
        default=0,
        help="Optional speed cap. 0 means use all old-letter training examples.",
    )
    parser.add_argument(
        "--max-new-per-class",
        type=int,
        default=0,
        help="Optional speed cap. 0 means use all held-out-letter training examples.",
    )
    args = parser.parse_args()

    held_out_classes = parse_letters_or_indices(args.held_out_letters)
    if not held_out_classes:
        raise ValueError("Need at least one held-out letter.")
    old_classes = [c for c in range(26) if c not in set(held_out_classes)]
    replay_fractions = parse_floats(args.replay_fractions)
    seeds = parse_ints(args.seeds)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    max_old = args.max_old_per_class if args.max_old_per_class > 0 else None
    max_new = args.max_new_per_class if args.max_new_per_class > 0 else None

    print(f"Device:              {device}")
    print(f"Old letters:          {class_list_to_letters(old_classes)}")
    print(f"Held-out letters:     {class_list_to_letters(held_out_classes)}")
    print(f"Old classes count:    {len(old_classes)}")
    print(f"Held-out count:       {len(held_out_classes)}")
    print(f"Replay fractions:     {replay_fractions}")
    print(f"Seeds:                {seeds}")
    print(f"Phase 1 epochs:       {args.phase1_epochs}")
    print(f"Phase 2 epochs:       {args.phase2_epochs}")
    print(f"CNN architecture:     identical for every strategy")
    print(f"Dataset:              EMNIST Letters")
    if max_old is not None or max_new is not None:
        print(f"Speed caps:           old/class={max_old}, new/class={max_new}")
    print()

    # Load once. If multiple seeds are used, the exact data split is the same;
    # only initialization/replay sampling seeds change.
    loaders = make_loaders(
        data_dir=args.data_dir,
        batch_size=args.batch_size,
        old_classes=old_classes,
        held_out_classes=held_out_classes,
        max_old_per_class=max_old,
        max_new_per_class=max_new,
        seed=min(seeds),
        fix_orientation=not args.no_fix_orientation,
    )

    (
        train_old_loader,
        _train_new_loader,
        test_old_loader,
        test_new_loader,
        test_all_loader,
        train_old,
        train_new,
        _train_full,
        _test_full,
    ) = loaders

    print(f"Train old examples:   {len(train_old)}")
    print(f"Train new examples:   {len(train_new)}")
    print()

    results: List[Dict[str, object]] = []

    for seed in seeds:
        phase1_state, phase1_metrics, teacher = train_phase1_once(
            seed=seed,
            train_old_loader=train_old_loader,
            test_old_loader=test_old_loader,
            test_new_loader=test_new_loader,
            test_all_loader=test_all_loader,
            old_classes=old_classes,
            phase1_epochs=args.phase1_epochs,
            device=device,
            quiet=args.quiet,
        )

        for replay_fraction in replay_fractions:
            for strategy_idx, strategy in enumerate(STRATEGIES):
                condition_seed = seed * 100000 + int(replay_fraction * 1_000_000) + strategy_idx * 997
                result = run_one_condition(
                    seed=seed,
                    replay_fraction=replay_fraction,
                    strategy=strategy,
                    phase1_state=phase1_state,
                    phase1_metrics=phase1_metrics,
                    teacher=teacher,
                    train_old=train_old,
                    train_new=train_new,
                    test_old_loader=test_old_loader,
                    test_new_loader=test_new_loader,
                    test_all_loader=test_all_loader,
                    old_classes=old_classes,
                    batch_size=args.batch_size,
                    phase2_epochs=args.phase2_epochs,
                    device=device,
                    temperature=args.temperature,
                    condition_seed=condition_seed,
                    quiet=args.quiet,
                )
                results.append(result)

    print_results(results)
    avg_rows = average_results(results)
    print_average_results(avg_rows)
    print_best_by_replay(avg_rows)

    save_csv(args.csv, results)
    save_csv(args.avg_csv, avg_rows)
    print()
    print(f"Saved per-run results to: {args.csv}")
    print(f"Saved average results to: {args.avg_csv}")


if __name__ == "__main__":
    main()

```


---

## fastslow_full.py

```python

# fastslow_full.py
#
# Continual MNIST experiment:
# 1) Train on 7 digits.
# 2) Then train on the 3 held-out digits, optionally with a small replay buffer.
# 3) Compare regular CNN, fixed layer-rate CNNs, and adaptive early-lock CNN.
#
# Run:
#   pip install torch torchvision
#   python fastslow_full.py
#
# Optional:
#   python fastslow_full.py --phase1-epochs 3 --phase2-epochs 3 --replay-fractions 0,0.05,0.10,0.20,0.50

import argparse
import csv
import random
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import ConcatDataset, DataLoader, Subset
from torchvision import datasets, transforms


# -----------------------------
# Model config
# -----------------------------

@dataclass
class ModelConfig:
    name: str

    lr_conv1: float
    lr_conv2: float
    lr_fc1: float
    lr_fc2: float

    adaptive_lock: bool = False

    conv1_lock_acc: Optional[float] = None
    conv2_lock_acc: Optional[float] = None
    fc1_lock_acc: Optional[float] = None

    locked_lr: float = 1e-6


CONFIGS: List[ModelConfig] = [
    ModelConfig(
        name="Regular CNN",
        lr_conv1=1e-3,
        lr_conv2=1e-3,
        lr_fc1=1e-3,
        lr_fc2=1e-3,
    ),
    ModelConfig(
        name="Fixed front-fast/back-slow CNN",
        lr_conv1=3e-3,
        lr_conv2=1e-3,
        lr_fc1=3e-4,
        lr_fc2=1e-4,
    ),
    ModelConfig(
        name="Fixed front-slow/back-fast CNN",
        lr_conv1=1e-4,
        lr_conv2=3e-4,
        lr_fc1=1e-3,
        lr_fc2=3e-3,
    ),
    ModelConfig(
        name="Adaptive early-lock CNN",
        lr_conv1=3e-3,
        lr_conv2=1e-3,
        lr_fc1=1e-3,
        lr_fc2=1e-3,
        adaptive_lock=True,

        # Layer-consolidation thresholds.
        # When old-digit accuracy crosses these thresholds, the layer slows way down.
        conv1_lock_acc=0.970,
        conv2_lock_acc=0.985,

        # Keep fc1/fc2 plastic by default. Locking classifiers often prevents adaptation.
        fc1_lock_acc=None,

        locked_lr=1e-6,
    ),
]


# -----------------------------
# Utilities
# -----------------------------

def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_replay_fractions(text: str) -> List[float]:
    vals = []
    for part in text.split(","):
        part = part.strip()
        if not part:
            continue
        val = float(part)
        if val < 0.0 or val >= 1.0:
            raise ValueError("Replay fractions must be >= 0.0 and < 1.0")
        vals.append(val)
    return vals


def pct(x: float) -> str:
    return f"{100.0 * x:5.1f}%"


def format_acc(x: float) -> str:
    return f"{x:.4f}"


# -----------------------------
# Dataset helpers
# -----------------------------

def filter_by_digits(dataset, digits: List[int]) -> Subset:
    wanted = set(int(d) for d in digits)

    # MNIST has .targets, which avoids calling __getitem__ repeatedly.
    if hasattr(dataset, "targets"):
        labels = dataset.targets
        indices = [i for i, y in enumerate(labels) if int(y) in wanted]
    else:
        indices = [i for i, (_, y) in enumerate(dataset) if int(y) in wanted]

    return Subset(dataset, indices)


def make_loaders(
    data_dir: str,
    batch_size: int,
    old_digits: List[int],
    held_out_digits: List[int],
) -> Tuple[DataLoader, DataLoader, DataLoader, DataLoader, DataLoader, Subset, Subset]:
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])

    train_full = datasets.MNIST(
        root=data_dir,
        train=True,
        download=True,
        transform=transform,
    )

    test_full = datasets.MNIST(
        root=data_dir,
        train=False,
        download=True,
        transform=transform,
    )

    train_old = filter_by_digits(train_full, old_digits)
    train_new = filter_by_digits(train_full, held_out_digits)

    test_old = filter_by_digits(test_full, old_digits)
    test_new = filter_by_digits(test_full, held_out_digits)

    train_old_loader = DataLoader(train_old, batch_size=batch_size, shuffle=True)
    train_new_loader = DataLoader(train_new, batch_size=batch_size, shuffle=True)

    test_old_loader = DataLoader(test_old, batch_size=batch_size, shuffle=False)
    test_new_loader = DataLoader(test_new, batch_size=batch_size, shuffle=False)
    test_all_loader = DataLoader(test_full, batch_size=batch_size, shuffle=False)

    return (
        train_old_loader,
        train_new_loader,
        test_old_loader,
        test_new_loader,
        test_all_loader,
        train_old,
        train_new,
    )


def make_replay_loader(
    train_new_subset: Subset,
    train_old_subset: Subset,
    replay_fraction: float,
    batch_size: int,
    seed: int,
) -> DataLoader:
    """
    Phase-2 dataset.

    replay_fraction means fraction of phase-2 examples that are old replay examples.

    replay_fraction = 0.00:
        100% new digits, 0% old digits.

    replay_fraction = 0.20:
        80% new digits, 20% old replay.

    replay_fraction = 0.50:
        50% new digits, 50% old replay.
    """
    if replay_fraction <= 0.0:
        generator = torch.Generator()
        generator.manual_seed(seed)
        return DataLoader(
            train_new_subset,
            batch_size=batch_size,
            shuffle=True,
            generator=generator,
        )

    n_new = len(train_new_subset)

    old_replay_size = int((replay_fraction / (1.0 - replay_fraction)) * n_new)
    old_replay_size = max(1, old_replay_size)
    old_replay_size = min(old_replay_size, len(train_old_subset))

    rng = random.Random(seed)
    old_indices = rng.sample(range(len(train_old_subset)), old_replay_size)

    old_replay_subset = Subset(train_old_subset, old_indices)

    mixed_dataset = ConcatDataset([
        train_new_subset,
        old_replay_subset,
    ])

    generator = torch.Generator()
    generator.manual_seed(seed)

    return DataLoader(
        mixed_dataset,
        batch_size=batch_size,
        shuffle=True,
        generator=generator,
    )


# -----------------------------
# CNN model
# -----------------------------

class SmallCNN(nn.Module):
    def __init__(self) -> None:
        super().__init__()

        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)

        self.pool = nn.MaxPool2d(2, 2)

        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pool(F.relu(self.conv1(x)))  # 28x28 -> 14x14
        x = self.pool(F.relu(self.conv2(x)))  # 14x14 -> 7x7
        x = torch.flatten(x, 1)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x


# -----------------------------
# Optimizer / adaptive locks
# -----------------------------

def make_optimizer(model: SmallCNN, cfg: ModelConfig) -> torch.optim.Optimizer:
    return torch.optim.Adam([
        {
            "name": "conv1",
            "params": model.conv1.parameters(),
            "lr": cfg.lr_conv1,
        },
        {
            "name": "conv2",
            "params": model.conv2.parameters(),
            "lr": cfg.lr_conv2,
        },
        {
            "name": "fc1",
            "params": model.fc1.parameters(),
            "lr": cfg.lr_fc1,
        },
        {
            "name": "fc2",
            "params": model.fc2.parameters(),
            "lr": cfg.lr_fc2,
        },
    ])


def set_group_lr(optimizer: torch.optim.Optimizer, group_name: str, new_lr: float) -> None:
    for group in optimizer.param_groups:
        if group.get("name") == group_name:
            group["lr"] = new_lr


def get_group_lrs(optimizer: torch.optim.Optimizer) -> Dict[str, float]:
    out = {}
    for group in optimizer.param_groups:
        out[str(group.get("name"))] = float(group["lr"])
    return out


def lr_string(optimizer: torch.optim.Optimizer) -> str:
    lrs = get_group_lrs(optimizer)
    return " | ".join(f"{k}={v:.1e}" for k, v in lrs.items())


def maybe_lock_layers(
    cfg: ModelConfig,
    optimizer: torch.optim.Optimizer,
    old_acc: float,
    lock_state: Dict[str, bool],
) -> List[str]:
    events = []

    if not cfg.adaptive_lock:
        return events

    if cfg.conv1_lock_acc is not None:
        if old_acc >= cfg.conv1_lock_acc and not lock_state["conv1"]:
            set_group_lr(optimizer, "conv1", cfg.locked_lr)
            lock_state["conv1"] = True
            events.append(f"LOCK conv1 at old_acc={old_acc:.4f}")

    if cfg.conv2_lock_acc is not None:
        if old_acc >= cfg.conv2_lock_acc and not lock_state["conv2"]:
            set_group_lr(optimizer, "conv2", cfg.locked_lr)
            lock_state["conv2"] = True
            events.append(f"LOCK conv2 at old_acc={old_acc:.4f}")

    if cfg.fc1_lock_acc is not None:
        if old_acc >= cfg.fc1_lock_acc and not lock_state["fc1"]:
            set_group_lr(optimizer, "fc1", cfg.locked_lr)
            lock_state["fc1"] = True
            events.append(f"LOCK fc1 at old_acc={old_acc:.4f}")

    return events


# -----------------------------
# Training / eval
# -----------------------------

def mask_logits_to_digits(
    logits: torch.Tensor,
    allowed_digits: Optional[List[int]],
) -> torch.Tensor:
    """
    During phase 1, we train on only old digits.
    Masking prevents the network from being explicitly punished for assigning
    probability to held-out digits it has never seen.

    In phase 2, use allowed_digits=None so all 10 classes compete.
    """
    if allowed_digits is None:
        return logits

    masked = torch.full_like(logits, -1e9)
    allowed = torch.tensor(allowed_digits, dtype=torch.long, device=logits.device)
    masked[:, allowed] = logits[:, allowed]
    return masked


def train_one_epoch(
    model: nn.Module,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: str,
    allowed_digits_for_loss: Optional[List[int]],
) -> float:
    model.train()

    total_loss = 0.0
    total_seen = 0

    for x, y in loader:
        x = x.to(device)
        y = y.to(device)

        optimizer.zero_grad(set_to_none=True)

        logits = model(x)
        logits = mask_logits_to_digits(logits, allowed_digits_for_loss)

        loss = F.cross_entropy(logits, y)
        loss.backward()
        optimizer.step()

        total_loss += float(loss.item()) * x.size(0)
        total_seen += x.size(0)

    return total_loss / max(1, total_seen)


@torch.no_grad()
def accuracy(
    model: nn.Module,
    loader: DataLoader,
    device: str,
) -> float:
    model.eval()

    correct = 0
    total = 0

    for x, y in loader:
        x = x.to(device)
        y = y.to(device)

        logits = model(x)
        pred = logits.argmax(dim=1)

        correct += int((pred == y).sum().item())
        total += int(y.numel())

    return correct / max(1, total)


def train_phase(
    model: nn.Module,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: str,
    epochs: int,
    allowed_digits_for_loss: Optional[List[int]],
    phase_name: str,
    cfg: ModelConfig,
    lock_state: Dict[str, bool],
    test_old_loader: DataLoader,
    quiet: bool = False,
) -> None:
    for epoch in range(1, epochs + 1):
        loss = train_one_epoch(
            model=model,
            loader=loader,
            optimizer=optimizer,
            device=device,
            allowed_digits_for_loss=allowed_digits_for_loss,
        )

        old_acc_now = accuracy(model, test_old_loader, device)
        lock_events = maybe_lock_layers(cfg, optimizer, old_acc_now, lock_state)

        if not quiet:
            msg = (
                f"{phase_name} epoch {epoch:02d} "
                f"| loss {loss:.4f} "
                f"| old_acc {old_acc_now:.4f} "
                f"| {lr_string(optimizer)}"
            )
            print(msg)
            for event in lock_events:
                print("  " + event)


# -----------------------------
# Experiment runner
# -----------------------------

def run_single_experiment(
    cfg: ModelConfig,
    replay_fraction: float,
    loaders,
    old_digits: List[int],
    phase1_epochs: int,
    phase2_epochs: int,
    batch_size: int,
    seed: int,
    device: str,
    quiet: bool = False,
) -> Dict[str, object]:
    (
        train_old_loader,
        _train_new_loader,
        test_old_loader,
        test_new_loader,
        test_all_loader,
        train_old_subset,
        train_new_subset,
    ) = loaders

    # Different but deterministic seed per condition.
    condition_seed = seed + int(replay_fraction * 10000) + abs(hash(cfg.name)) % 1000
    set_seed(condition_seed)

    model = SmallCNN().to(device)
    optimizer = make_optimizer(model, cfg)

    lock_state = {
        "conv1": False,
        "conv2": False,
        "fc1": False,
    }

    if not quiet:
        print("=" * 100)
        print(f"{cfg.name} | replay_fraction={replay_fraction:.2f}")
        print("=" * 100)

    # Phase 1: old digits only.
    # Mask missing classes during loss.
    train_phase(
        model=model,
        loader=train_old_loader,
        optimizer=optimizer,
        device=device,
        epochs=phase1_epochs,
        allowed_digits_for_loss=old_digits,
        phase_name="Phase 1 old digits",
        cfg=cfg,
        lock_state=lock_state,
        test_old_loader=test_old_loader,
        quiet=quiet,
    )

    old_acc_phase1 = accuracy(model, test_old_loader, device)
    new_acc_phase1 = accuracy(model, test_new_loader, device)
    all_acc_phase1 = accuracy(model, test_all_loader, device)

    # Phase 2: new digits + optional old replay.
    phase2_loader = make_replay_loader(
        train_new_subset=train_new_subset,
        train_old_subset=train_old_subset,
        replay_fraction=replay_fraction,
        batch_size=batch_size,
        seed=condition_seed + 123,
    )

    train_phase(
        model=model,
        loader=phase2_loader,
        optimizer=optimizer,
        device=device,
        epochs=phase2_epochs,
        allowed_digits_for_loss=None,
        phase_name=f"Phase 2 new + replay {pct(replay_fraction)}",
        cfg=cfg,
        lock_state=lock_state,
        test_old_loader=test_old_loader,
        quiet=quiet,
    )

    old_acc_phase2 = accuracy(model, test_old_loader, device)
    new_acc_phase2 = accuracy(model, test_new_loader, device)
    all_acc_phase2 = accuracy(model, test_all_loader, device)

    forgetting = old_acc_phase1 - old_acc_phase2

    # A rough one-number score:
    # high overall accuracy is good; forgetting is bad.
    # This is not sacred; it is just useful for sorting.
    stability_score = all_acc_phase2 - forgetting

    lrs = get_group_lrs(optimizer)

    result: Dict[str, object] = {
        "model": cfg.name,
        "replay_fraction": replay_fraction,

        "old_acc_phase1": old_acc_phase1,
        "new_acc_phase1": new_acc_phase1,
        "all_acc_phase1": all_acc_phase1,

        "old_acc_phase2": old_acc_phase2,
        "new_acc_phase2": new_acc_phase2,
        "all_acc_phase2": all_acc_phase2,

        "forgetting": forgetting,
        "stability_score": stability_score,

        "conv1_locked": lock_state["conv1"],
        "conv2_locked": lock_state["conv2"],
        "fc1_locked": lock_state["fc1"],

        "final_lr_conv1": lrs.get("conv1", None),
        "final_lr_conv2": lrs.get("conv2", None),
        "final_lr_fc1": lrs.get("fc1", None),
        "final_lr_fc2": lrs.get("fc2", None),
    }

    if not quiet:
        print()
        print(f"After phase 1 old accuracy: {old_acc_phase1:.4f}")
        print(f"After phase 1 new accuracy: {new_acc_phase1:.4f}")
        print(f"After phase 1 all accuracy: {all_acc_phase1:.4f}")
        print()
        print(f"After phase 2 old accuracy: {old_acc_phase2:.4f}")
        print(f"After phase 2 new accuracy: {new_acc_phase2:.4f}")
        print(f"After phase 2 all accuracy: {all_acc_phase2:.4f}")
        print(f"Forgetting:                 {forgetting:.4f}")
        print(f"Stability score:            {stability_score:.4f}")
        print()

    return result


def print_results_table(results: List[Dict[str, object]]) -> None:
    print()
    print()
    print("FINAL FULL GRID")
    print("=" * 150)

    header = (
        f"{'Replay':>8s} "
        f"{'Model':38s} "
        f"{'Old P1':>8s} "
        f"{'New P1':>8s} "
        f"{'All P1':>8s} "
        f"{'Old P2':>8s} "
        f"{'New P2':>8s} "
        f"{'All P2':>8s} "
        f"{'Forget':>8s} "
        f"{'Score':>8s} "
        f"{'Locks':>12s}"
    )
    print(header)
    print("-" * 150)

    results_sorted = sorted(results, key=lambda r: (float(r["replay_fraction"]), str(r["model"])))

    for r in results_sorted:
        locks = ""
        locks += "C1" if r["conv1_locked"] else "--"
        locks += "/"
        locks += "C2" if r["conv2_locked"] else "--"
        locks += "/"
        locks += "F1" if r["fc1_locked"] else "--"

        print(
            f"{pct(float(r['replay_fraction'])):>8s} "
            f"{str(r['model']):38s} "
            f"{format_acc(float(r['old_acc_phase1'])):>8s} "
            f"{format_acc(float(r['new_acc_phase1'])):>8s} "
            f"{format_acc(float(r['all_acc_phase1'])):>8s} "
            f"{format_acc(float(r['old_acc_phase2'])):>8s} "
            f"{format_acc(float(r['new_acc_phase2'])):>8s} "
            f"{format_acc(float(r['all_acc_phase2'])):>8s} "
            f"{format_acc(float(r['forgetting'])):>8s} "
            f"{format_acc(float(r['stability_score'])):>8s} "
            f"{locks:>12s}"
        )


def print_best_by_replay(results: List[Dict[str, object]]) -> None:
    print()
    print()
    print("BEST BY REPLAY FRACTION")
    print("=" * 150)
    print("Sorted by: highest stability_score = all phase-2 accuracy minus forgetting")
    print("-" * 150)

    fractions = sorted(set(float(r["replay_fraction"]) for r in results))

    for frac in fractions:
        subset = [r for r in results if float(r["replay_fraction"]) == frac]
        subset_sorted = sorted(
            subset,
            key=lambda r: (
                float(r["stability_score"]),
                float(r["all_acc_phase2"]),
                -float(r["forgetting"]),
            ),
            reverse=True,
        )
        best = subset_sorted[0]

        print(
            f"Replay {pct(frac)} | "
            f"best: {best['model']} | "
            f"Old P2={float(best['old_acc_phase2']):.4f} | "
            f"New P2={float(best['new_acc_phase2']):.4f} | "
            f"All P2={float(best['all_acc_phase2']):.4f} | "
            f"Forget={float(best['forgetting']):.4f} | "
            f"Score={float(best['stability_score']):.4f}"
        )


def save_csv(results: List[Dict[str, object]], path: str) -> None:
    if not results:
        return

    fieldnames = list(results[0].keys())

    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in results:
            writer.writerow(r)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=str, default="./data")
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--phase1-epochs", type=int, default=3)
    parser.add_argument("--phase2-epochs", type=int, default=3)
    parser.add_argument("--held-out", type=str, default="3,6,9")
    parser.add_argument("--replay-fractions", type=str, default="0,0.05,0.10,0.20,0.50")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--csv", type=str, default="fastslow_results.csv")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    held_out_digits = [int(x.strip()) for x in args.held_out.split(",") if x.strip()]
    old_digits = [d for d in range(10) if d not in held_out_digits]
    replay_fractions = parse_replay_fractions(args.replay_fractions)

    device = "cuda" if torch.cuda.is_available() else "cpu"

    print(f"Device:          {device}")
    print(f"Old digits:      {old_digits}")
    print(f"Held-out digits: {held_out_digits}")
    print(f"Replay fractions: {replay_fractions}")
    print(f"Phase 1 epochs:  {args.phase1_epochs}")
    print(f"Phase 2 epochs:  {args.phase2_epochs}")
    print()

    set_seed(args.seed)

    loaders = make_loaders(
        data_dir=args.data_dir,
        batch_size=args.batch_size,
        old_digits=old_digits,
        held_out_digits=held_out_digits,
    )

    results: List[Dict[str, object]] = []

    for replay_fraction in replay_fractions:
        for cfg in CONFIGS:
            result = run_single_experiment(
                cfg=cfg,
                replay_fraction=replay_fraction,
                loaders=loaders,
                old_digits=old_digits,
                phase1_epochs=args.phase1_epochs,
                phase2_epochs=args.phase2_epochs,
                batch_size=args.batch_size,
                seed=args.seed,
                device=device,
                quiet=args.quiet,
            )
            results.append(result)

    print_results_table(results)
    print_best_by_replay(results)

    save_csv(results, args.csv)
    print()
    print(f"Saved results to: {args.csv}")


if __name__ == "__main__":
    main()

```


---

## lifelong_gui.py

```python
#!/usr/bin/env python3
"""
lifelong_gui.py

Tkinter GUI for the toy byte-level lifelong LLM.

It trains a laughably small Transformer over a staged .txt corpus. Each .txt file
is one learning phase. The GUI shows live logs plus milestone completions on
fixed prompts so you can watch the model learn new text while being tested on
old anchors.
"""

from __future__ import annotations

import copy
import csv
import json
import math
import os
import queue
import random
import subprocess
import sys
import threading
import time
import traceback
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Dict, List

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
except Exception as exc:  # pragma: no cover
    raise SystemExit(f"Tkinter could not be loaded: {exc}")

try:
    import torch
    import torch.nn.functional as F
except Exception as exc:  # pragma: no cover
    torch = None
    TORCH_IMPORT_ERROR = exc
else:
    TORCH_IMPORT_ERROR = None

# Local core. This file is included in the ZIP.
try:
    import micro_lifelong_llm as core
except Exception as exc:  # pragma: no cover
    core = None
    CORE_IMPORT_ERROR = exc
else:
    CORE_IMPORT_ERROR = None


APP_DIR = Path(__file__).resolve().parent
DEFAULT_CORPUS = APP_DIR / "corpus"
DEFAULT_OUT = APP_DIR / "runs_gui_lifelong"


@dataclass
class GUIConfig:
    corpus_dir: Path
    out_dir: Path
    seed: int
    device_choice: str
    block_size: int
    n_embd: int
    n_head: int
    n_layer: int
    dropout: float
    steps_per_phase: int
    batch_size: int
    replay_batch: int
    lr: float
    weight_decay: float
    replay_ce_weight: float
    distill_weight: float
    temperature: float
    anchor_weight: float
    memory_per_phase: int
    memory_policy: str
    eval_batches: int
    print_every: int
    milestone_every: int
    gen_tokens: int
    prompts: List[str]
    max_chars_per_file: int | None


def open_folder(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    try:
        if sys.platform.startswith("win"):
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except Exception:
        pass


def put(q: queue.Queue, kind: str, text: str) -> None:
    q.put({"kind": kind, "text": text, "time": time.strftime("%H:%M:%S")})


def choose_device(choice: str):
    if choice == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(choice)


def make_args_from_config(cfg: GUIConfig) -> SimpleNamespace:
    # Shape matches the fields used by the core training functions.
    return SimpleNamespace(
        lr=cfg.lr,
        weight_decay=cfg.weight_decay,
        anchor_weight=cfg.anchor_weight,
        distill_weight=cfg.distill_weight,
        temperature=cfg.temperature,
        steps_per_phase=cfg.steps_per_phase,
        batch_size=cfg.batch_size,
        replay_batch=cfg.replay_batch,
        replay_ce_weight=cfg.replay_ce_weight,
        grad_clip=1.0,
        eval_batches=cfg.eval_batches,
        print_every=cfg.print_every,
        memory_per_phase=cfg.memory_per_phase,
        memory_policy=cfg.memory_policy,
    )


def auto_distill_lambda(distill_weight: float, memory_chunks: int, phase_index: int) -> float:
    """Same idea as the CLI: choose old-self pressure from memory density."""
    if distill_weight >= 0:
        return distill_weight
    spc_proxy = memory_chunks / max(1, phase_index) if phase_index > 0 else 0
    if spc_proxy < 200:
        return 0.0
    if spc_proxy < 900:
        return 0.05
    return 0.15


@torch.no_grad()
def evaluate_seen(model, phases, seen_until: int, device, batch_size: int, eval_batches: int) -> Dict[str, float]:
    out: Dict[str, float] = {}
    for i in range(seen_until + 1):
        loss = core.estimate_loss(
            model,
            phases[i]["chunks"],
            device,
            eval_batches=max(1, eval_batches),
            batch_size=max(1, batch_size),
        )
        out[f"phase_{i:02d}_{phases[i]['name']}_loss"] = loss
        out[f"phase_{i:02d}_{phases[i]['name']}_ppl"] = math.exp(min(loss, 20))
    return out


def render_eval(eval_dict: Dict[str, float]) -> str:
    lines = []
    for k in sorted(eval_dict.keys()):
        if k.endswith("_loss"):
            base = k[:-5]
            ppl = eval_dict.get(base + "_ppl", float("nan"))
            lines.append(f"  {base}: loss {eval_dict[k]:.4f} | ppl {ppl:.2f}")
    return "\n".join(lines)


def generate_milestone_text(model, prompts: List[str], device, gen_tokens: int) -> str:
    lines = []
    for prompt in prompts:
        prompt = prompt.strip()
        if not prompt:
            continue
        try:
            sample = model.generate(prompt, max_new_tokens=gen_tokens, temperature=0.85, top_k=60, device=str(device))
        except Exception as exc:
            sample = f"[generation failed: {exc}]"
        lines.append(f"PROMPT: {prompt}\n{sample}\n")
    return "\n".join(lines).strip()


def train_lifelong(cfg: GUIConfig, q: queue.Queue, stop_event: threading.Event) -> None:
    if torch is None:
        raise RuntimeError(f"PyTorch could not be imported: {TORCH_IMPORT_ERROR}")
    if core is None:
        raise RuntimeError(f"Core module could not be imported: {CORE_IMPORT_ERROR}")

    cfg.out_dir.mkdir(parents=True, exist_ok=True)
    (cfg.out_dir / "gui_config.json").write_text(json.dumps({
        k: str(v) if isinstance(v, Path) else v for k, v in cfg.__dict__.items()
    }, indent=2), encoding="utf-8")

    core.set_seed(cfg.seed)
    device = choose_device(cfg.device_choice)
    put(q, "log", f"Device: {device}")
    put(q, "log", f"Corpus: {cfg.corpus_dir}")
    put(q, "log", f"Output: {cfg.out_dir}")

    max_chars = cfg.max_chars_per_file if cfg.max_chars_per_file and cfg.max_chars_per_file > 0 else None
    phases = core.load_phases(cfg.corpus_dir, block_size=cfg.block_size, max_chars_per_file=max_chars)
    put(q, "milestone", "Loaded phases:\n" + "\n".join(
        f"  {ph['id']:02d}: {ph['name']} | chars={len(ph['text'])} | chunks={len(ph['chunks'])}"
        for ph in phases
    ))

    model = core.TinyGPT(
        block_size=cfg.block_size,
        n_embd=cfg.n_embd,
        n_head=cfg.n_head,
        n_layer=cfg.n_layer,
        dropout=cfg.dropout,
    ).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    put(q, "log", f"Model parameters: {n_params:,} ({n_params/1e6:.3f}M)")

    args = make_args_from_config(cfg)
    memory_by_phase: Dict[int, List[torch.Tensor]] = {}
    train_csv = cfg.out_dir / "training_log.csv"
    eval_csv = cfg.out_dir / "milestone_eval_log.csv"

    train_fields = [
        "phase", "phase_name", "step", "loss", "ce_current", "ce_replay",
        "distill", "lambda_distill", "anchor", "memory_chunks",
    ]
    eval_rows: List[Dict[str, object]] = []

    with train_csv.open("w", newline="", encoding="utf-8") as tf:
        tw = csv.DictWriter(tf, fieldnames=train_fields)
        tw.writeheader()

        for phase_index, phase in enumerate(phases):
            if stop_event.is_set():
                put(q, "log", "Training stopped by user.")
                break

            put(q, "milestone", "\n" + "#" * 72 + f"\nPHASE {phase_index}: learning {phase['name']}\n" + "#" * 72)
            old_teacher = None
            if phase_index > 0:
                old_teacher = copy.deepcopy(model).to(device)
                old_teacher.eval()
                for p in old_teacher.parameters():
                    p.requires_grad_(False)

            all_memory: List[torch.Tensor] = []
            for chunks in memory_by_phase.values():
                all_memory.extend(chunks)
            lambda_d = auto_distill_lambda(cfg.distill_weight, len(all_memory), phase_index)
            put(q, "log", f"Phase {phase_index}: replay memory={len(all_memory)} chunks | lambda_distill={lambda_d:.3f}")

            optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
            old_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()} if cfg.anchor_weight > 0 else None
            current_chunks = phase["chunks"]
            replay_available = len(all_memory) > 0 and cfg.replay_batch > 0

            for step in range(1, cfg.steps_per_phase + 1):
                if stop_event.is_set():
                    put(q, "log", "Training stopped by user.")
                    break

                model.train()
                optimizer.zero_grad(set_to_none=True)
                x_cur, y_cur = core.sample_batch(current_chunks, cfg.batch_size, device)
                logits_cur, ce_cur = model(x_cur, y_cur)
                loss = ce_cur
                ce_replay = torch.tensor(0.0, device=device)
                dloss = torch.tensor(0.0, device=device)
                aloss = torch.tensor(0.0, device=device)

                if replay_available:
                    x_rep, y_rep = core.sample_batch(all_memory, cfg.replay_batch, device)
                    logits_rep, ce_replay = model(x_rep, y_rep)
                    loss = loss + cfg.replay_ce_weight * ce_replay
                    if old_teacher is not None and lambda_d > 0:
                        with torch.no_grad():
                            teacher_logits, _ = old_teacher(x_rep)
                        dloss = core.distill_loss(logits_rep, teacher_logits, cfg.temperature)
                        loss = loss + lambda_d * dloss

                if old_state is not None and cfg.anchor_weight > 0:
                    aloss = core.anchor_loss(model, old_state, device)
                    loss = loss + cfg.anchor_weight * aloss

                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()

                if step == 1 or step % cfg.print_every == 0 or step == cfg.steps_per_phase:
                    row = {
                        "phase": phase_index,
                        "phase_name": phase["name"],
                        "step": step,
                        "loss": float(loss.item()),
                        "ce_current": float(ce_cur.item()),
                        "ce_replay": float(ce_replay.item()),
                        "distill": float(dloss.item()),
                        "lambda_distill": float(lambda_d),
                        "anchor": float(aloss.item()),
                        "memory_chunks": len(all_memory),
                    }
                    tw.writerow(row)
                    tf.flush()
                    put(
                        q,
                        "log",
                        f"phase {phase_index:02d} {phase['name']:<28} step {step:04d}/{cfg.steps_per_phase} "
                        f"loss {loss.item():.4f} ce_cur {ce_cur.item():.4f} ce_rep {ce_replay.item():.4f} "
                        f"distill {dloss.item():.4f} λd {lambda_d:.3f}",
                    )

                if step == cfg.steps_per_phase or (cfg.milestone_every > 0 and step % cfg.milestone_every == 0):
                    eval_dict = evaluate_seen(model, phases, phase_index, device, cfg.batch_size, cfg.eval_batches)
                    text = [
                        f"MILESTONE | phase {phase_index} {phase['name']} | step {step}/{cfg.steps_per_phase}",
                        "Evaluation on seen phases:",
                        render_eval(eval_dict),
                    ]
                    gen = generate_milestone_text(model, cfg.prompts, device, cfg.gen_tokens)
                    if gen:
                        text.extend(["", "Fixed-prompt completions:", gen])
                    put(q, "milestone", "\n".join(text))
                    eval_row = {"phase": phase_index, "phase_name": phase["name"], "step": step, **eval_dict}
                    eval_rows.append(eval_row)

            # After phase: store memory and save checkpoint.
            mem_cfg = core.MemoryConfig(memory_per_phase=cfg.memory_per_phase, policy=cfg.memory_policy)
            selected = core.select_memory_chunks(model, phase["chunks"], mem_cfg, device)
            memory_by_phase[phase_index] = selected
            total_mem = sum(len(v) for v in memory_by_phase.values())
            put(q, "milestone", f"Stored {len(selected)} chunks for phase {phase_index}; total memory now {total_mem} chunks.")

            torch.save({
                "model_state": model.state_dict(),
                "phase": phase_index,
                "phase_name": phase["name"],
                "memory_by_phase": memory_by_phase,
            }, cfg.out_dir / f"checkpoint_after_phase_{phase_index:02d}.pt")

    # Flexible eval CSV.
    if eval_rows:
        fields = sorted({k for row in eval_rows for k in row.keys()})
        with eval_csv.open("w", newline="", encoding="utf-8") as ef:
            ew = csv.DictWriter(ef, fieldnames=fields)
            ew.writeheader()
            for row in eval_rows:
                ew.writerow(row)

    torch.save({
        "model_state": model.state_dict(),
        "memory_by_phase": memory_by_phase,
        "phase_names": [p["name"] for p in phases],
    }, cfg.out_dir / "model_final.pt")
    put(q, "milestone", f"DONE. Saved outputs in:\n{cfg.out_dir}")


class LifelongGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Micro Lifelong LLM — Replay / Distillation Toy")
        self.geometry("1180x780")
        self.queue: queue.Queue = queue.Queue()
        self.stop_event = threading.Event()
        self.worker: threading.Thread | None = None
        self._build_ui()
        self.after(100, self._poll_queue)

        if TORCH_IMPORT_ERROR is not None:
            messagebox.showerror("PyTorch missing", f"PyTorch could not be imported. Install it first.\n\n{TORCH_IMPORT_ERROR}")
        if CORE_IMPORT_ERROR is not None:
            messagebox.showerror("Core import failed", f"micro_lifelong_llm.py could not be imported.\n\n{CORE_IMPORT_ERROR}")

    def _build_ui(self):
        root = ttk.Frame(self, padding=8)
        root.pack(fill="both", expand=True)

        controls = ttk.LabelFrame(root, text="Run controls", padding=8)
        controls.pack(fill="x", side="top")

        self.vars: Dict[str, tk.StringVar] = {}
        def add_entry(row, col, label, key, default, width=12):
            ttk.Label(controls, text=label).grid(row=row, column=col, sticky="w", padx=4, pady=3)
            var = tk.StringVar(value=str(default))
            self.vars[key] = var
            ttk.Entry(controls, textvariable=var, width=width).grid(row=row, column=col+1, sticky="we", padx=4, pady=3)
            return var

        # Row 0 paths
        add_entry(0, 0, "Corpus", "corpus_dir", DEFAULT_CORPUS, width=48)
        ttk.Button(controls, text="Browse", command=self._browse_corpus).grid(row=0, column=2, padx=4)
        add_entry(0, 3, "Output", "out_dir", DEFAULT_OUT, width=48)
        ttk.Button(controls, text="Open", command=self._open_out).grid(row=0, column=5, padx=4)

        # Row 1 model/run
        add_entry(1, 0, "Steps/phase", "steps_per_phase", 300)
        add_entry(1, 2, "Memory/phase", "memory_per_phase", 300)
        add_entry(1, 4, "Milestone every", "milestone_every", 100)
        add_entry(1, 6, "Seed", "seed", 42)

        # Row 2 batches/loss
        add_entry(2, 0, "Batch", "batch_size", 16)
        add_entry(2, 2, "Replay batch", "replay_batch", 16)
        add_entry(2, 4, "Distill weight", "distill_weight", -1.0)
        add_entry(2, 6, "Anchor", "anchor_weight", 0.0)

        # Row 3 architecture
        add_entry(3, 0, "Block", "block_size", 128)
        add_entry(3, 2, "Emb", "n_embd", 96)
        add_entry(3, 4, "Layers", "n_layer", 2)
        add_entry(3, 6, "Heads", "n_head", 4)

        # Row 4 learning
        add_entry(4, 0, "LR", "lr", 3e-4)
        add_entry(4, 2, "Eval batches", "eval_batches", 6)
        add_entry(4, 4, "Sample tokens", "gen_tokens", 180)
        add_entry(4, 6, "Max chars/file", "max_chars_per_file", 0)

        ttk.Label(controls, text="Device").grid(row=5, column=0, sticky="w", padx=4, pady=3)
        self.device_var = tk.StringVar(value="auto")
        ttk.Combobox(controls, textvariable=self.device_var, values=["auto", "cpu", "cuda"], width=10, state="readonly").grid(row=5, column=1, sticky="w", padx=4)

        ttk.Label(controls, text="Memory policy").grid(row=5, column=2, sticky="w", padx=4, pady=3)
        self.policy_var = tk.StringVar(value="auto")
        ttk.Combobox(controls, textvariable=self.policy_var, values=["auto", "balanced", "diverse", "hard", "hard_diverse"], width=14, state="readonly").grid(row=5, column=3, sticky="w", padx=4)

        self.start_btn = ttk.Button(controls, text="Start training", command=self._start)
        self.start_btn.grid(row=5, column=4, padx=4, pady=4, sticky="we")
        self.stop_btn = ttk.Button(controls, text="Stop", command=self._stop, state="disabled")
        self.stop_btn.grid(row=5, column=5, padx=4, pady=4, sticky="we")
        ttk.Button(controls, text="Open corpus", command=self._open_corpus).grid(row=5, column=6, padx=4, pady=4, sticky="we")

        # Prompt area and output panes
        lower = ttk.PanedWindow(root, orient="horizontal")
        lower.pack(fill="both", expand=True, pady=(8, 0))

        left = ttk.Frame(lower)
        right = ttk.Frame(lower)
        lower.add(left, weight=1)
        lower.add(right, weight=2)

        prompt_frame = ttk.LabelFrame(left, text="Fixed milestone prompts", padding=6)
        prompt_frame.pack(fill="both", expand=False)
        self.prompt_text = tk.Text(prompt_frame, height=12, wrap="word")
        self.prompt_text.pack(fill="both", expand=True)
        self.prompt_text.insert("1.0", "Memory is\nThe red key\nlow serum osmolality\ndef add_one\neven plus even\nthe quiet machine")

        help_frame = ttk.LabelFrame(left, text="What to watch", padding=6)
        help_frame.pack(fill="both", expand=True, pady=(8,0))
        self.help_text = tk.Text(help_frame, wrap="word", height=14)
        self.help_text.pack(fill="both", expand=True)
        self.help_text.insert("1.0", (
            "Milestones show losses on all phases seen so far and completions from fixed prompts.\n\n"
            "A good lifelong run should keep earlier phase losses from exploding after later phases.\n\n"
            "Use memory_per_phase=50, 300, and 1000 to test the same memory-density idea from the symbol experiments.\n\n"
            "distill_weight=-1 uses auto: little/no distillation when memory is tiny; weak distillation when memory is denser."
        ))
        self.help_text.config(state="disabled")

        nb = ttk.Notebook(right)
        nb.pack(fill="both", expand=True)
        log_frame = ttk.Frame(nb)
        mile_frame = ttk.Frame(nb)
        nb.add(mile_frame, text="Milestones / completions")
        nb.add(log_frame, text="Live training log")

        self.milestone_text = tk.Text(mile_frame, wrap="word")
        self.milestone_text.pack(fill="both", expand=True)
        self.log_text = tk.Text(log_frame, wrap="none")
        self.log_text.pack(fill="both", expand=True)

    def _browse_corpus(self):
        p = filedialog.askdirectory(initialdir=str(DEFAULT_CORPUS.parent), title="Select corpus folder")
        if p:
            self.vars["corpus_dir"].set(p)

    def _open_out(self):
        open_folder(Path(self.vars["out_dir"].get()))

    def _open_corpus(self):
        open_folder(Path(self.vars["corpus_dir"].get()))

    def _parse_config(self) -> GUIConfig:
        def get_int(k): return int(float(self.vars[k].get()))
        def get_float(k): return float(self.vars[k].get())
        prompts = [line.strip() for line in self.prompt_text.get("1.0", "end").splitlines() if line.strip()]
        return GUIConfig(
            corpus_dir=Path(self.vars["corpus_dir"].get()),
            out_dir=Path(self.vars["out_dir"].get()),
            seed=get_int("seed"),
            device_choice=self.device_var.get(),
            block_size=get_int("block_size"),
            n_embd=get_int("n_embd"),
            n_head=get_int("n_head"),
            n_layer=get_int("n_layer"),
            dropout=0.1,
            steps_per_phase=get_int("steps_per_phase"),
            batch_size=get_int("batch_size"),
            replay_batch=get_int("replay_batch"),
            lr=get_float("lr"),
            weight_decay=0.01,
            replay_ce_weight=1.0,
            distill_weight=get_float("distill_weight"),
            temperature=2.0,
            anchor_weight=get_float("anchor_weight"),
            memory_per_phase=get_int("memory_per_phase"),
            memory_policy=self.policy_var.get(),
            eval_batches=get_int("eval_batches"),
            print_every=50,
            milestone_every=get_int("milestone_every"),
            gen_tokens=get_int("gen_tokens"),
            prompts=prompts,
            max_chars_per_file=get_int("max_chars_per_file") or None,
        )

    def _start(self):
        if self.worker and self.worker.is_alive():
            return
        if TORCH_IMPORT_ERROR is not None:
            messagebox.showerror("PyTorch missing", "Install PyTorch first: pip install torch")
            return
        try:
            cfg = self._parse_config()
        except Exception as exc:
            messagebox.showerror("Bad setting", str(exc))
            return
        if not cfg.corpus_dir.exists():
            messagebox.showerror("Missing corpus", f"Corpus folder does not exist:\n{cfg.corpus_dir}")
            return
        self.stop_event.clear()
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.log_text.delete("1.0", "end")
        self.milestone_text.delete("1.0", "end")
        self.worker = threading.Thread(target=self._worker_wrapper, args=(cfg,), daemon=True)
        self.worker.start()

    def _worker_wrapper(self, cfg: GUIConfig):
        try:
            train_lifelong(cfg, self.queue, self.stop_event)
        except Exception:
            put(self.queue, "milestone", "ERROR:\n" + traceback.format_exc())
        finally:
            self.queue.put({"kind": "done", "text": "", "time": time.strftime("%H:%M:%S")})

    def _stop(self):
        self.stop_event.set()
        self.stop_btn.config(state="disabled")

    def _poll_queue(self):
        try:
            while True:
                msg = self.queue.get_nowait()
                kind = msg.get("kind")
                stamp = msg.get("time", "")
                text = msg.get("text", "")
                if kind == "log":
                    self.log_text.insert("end", f"[{stamp}] {text}\n")
                    self.log_text.see("end")
                elif kind == "milestone":
                    self.milestone_text.insert("end", f"\n[{stamp}] {text}\n")
                    self.milestone_text.see("end")
                elif kind == "done":
                    self.start_btn.config(state="normal")
                    self.stop_btn.config(state="disabled")
        except queue.Empty:
            pass
        self.after(100, self._poll_queue)


if __name__ == "__main__":
    app = LifelongGUI()
    app.mainloop()

```


---

## micro_lifelong_llm.py

```python
#!/usr/bin/env python3
"""
micro_lifelong_llm.py

A laughably small continuously-learning byte-level Transformer.

It learns text in phases. At each new phase it mixes current material with a
replay buffer from earlier phases, optionally distilling from a frozen copy of
its old self on replay examples. This is a toy embodiment of the replay-density
finding:

    sparse memory     -> prioritize balanced coverage
    moderate memory   -> weak teacher distillation
    larger memory     -> add diverse / high-loss examples

Run demo:
    python micro_lifelong_llm.py --make-demo-corpus --corpus-dir demo_corpus --steps-per-phase 200

Run on your own corpus folder:
    python micro_lifelong_llm.py --corpus-dir my_corpus --steps-per-phase 500 --memory-per-phase 300

Each .txt file in corpus-dir is one learning phase, sorted by filename.
Put filenames like:
    01_stories.txt
    02_medicine.txt
    03_code.txt
    04_poems.txt

Outputs:
    runs_micro_lifelong/model_final.pt
    runs_micro_lifelong/memory.pt
    runs_micro_lifelong/training_log.csv
"""

from __future__ import annotations

import argparse
import copy
import csv
import math
import os
import random
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


# ----------------------------
# Data utilities
# ----------------------------

VOCAB_SIZE = 256  # byte-level model: no tokenizer needed


def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def encode_bytes(text: str) -> torch.Tensor:
    return torch.tensor(list(text.encode("utf-8", errors="replace")), dtype=torch.long)


def decode_bytes(tokens: torch.Tensor) -> str:
    if tokens.dim() > 1:
        tokens = tokens.flatten()
    data = bytes([int(t) % 256 for t in tokens.tolist()])
    return data.decode("utf-8", errors="replace")


def read_text_file(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def clean_text(s: str) -> str:
    # Mild cleanup only. Do not destroy domain-specific punctuation.
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip() + "\n"


def make_chunks(tokens: torch.Tensor, block_size: int, stride: Optional[int] = None) -> List[torch.Tensor]:
    """Return chunks of length block_size + 1 for next-token prediction."""
    if stride is None:
        stride = block_size
    n = len(tokens)
    if n < block_size + 1:
        pad = torch.full((block_size + 1 - n,), ord(" "), dtype=torch.long)
        return [torch.cat([tokens, pad])]
    chunks = []
    for i in range(0, n - block_size, stride):
        chunks.append(tokens[i : i + block_size + 1].clone())
    if not chunks:
        chunks = [tokens[: block_size + 1].clone()]
    return chunks


def sample_batch(chunks: List[torch.Tensor], batch_size: int, device: torch.device) -> Tuple[torch.Tensor, torch.Tensor]:
    batch = random.choices(chunks, k=batch_size)
    x = torch.stack([b[:-1] for b in batch]).to(device)
    y = torch.stack([b[1:] for b in batch]).to(device)
    return x, y


def load_phases(corpus_dir: Path, block_size: int, max_chars_per_file: Optional[int] = None) -> List[Dict]:
    files = sorted([p for p in corpus_dir.glob("*.txt") if p.is_file()])
    if not files:
        raise FileNotFoundError(f"No .txt files found in {corpus_dir}")
    phases = []
    for idx, path in enumerate(files):
        text = clean_text(read_text_file(path))
        if max_chars_per_file is not None and len(text) > max_chars_per_file:
            text = text[:max_chars_per_file]
        tokens = encode_bytes(text)
        chunks = make_chunks(tokens, block_size=block_size, stride=block_size)
        phases.append({"id": idx, "name": path.stem, "path": str(path), "text": text, "tokens": tokens, "chunks": chunks})
    return phases


def create_demo_corpus(corpus_dir: Path) -> None:
    corpus_dir.mkdir(parents=True, exist_ok=True)
    files = {
        "01_tiny_stories.txt": """
Milo found a blue button under the kitchen table. He put it in a little box and called it his moon.
Every morning he opened the box and said, good morning moon. The button did not answer, but Milo felt brave.
Lina had a red kite. The wind pulled and pulled. She held the string and laughed when the kite climbed over the trees.
A small dog named Pepper learned the sound of the bell. When the bell rang, Pepper sat by the door and waited for a walk.
The garden had three stones, two flowers, and one sleepy bee. The bee liked the yellow flower best.
""" * 40,
        "02_clinical_plain.txt": """
The patient has fever, chills, cough, and fatigue. The clinician asks about timing, exposure, medication, and travel.
A careful assessment separates urgent danger from stable illness. Blood pressure, pulse, oxygen level, and mental status guide the first decision.
In diabetes care, treatment balances glucose control, kidney protection, heart protection, side effects, and cost.
A good note states the problem, the evidence, the uncertainty, and the plan. The plan should be safe even when the diagnosis is incomplete.
Heart failure management considers congestion, perfusion, kidney function, potassium, blood pressure, and symptoms.
""" * 40,
        "03_code_like.txt": """
def add_one(x):
    return x + 1

for item in list_of_items:
    if item.ready:
        process(item)
    else:
        wait(item)

class MemoryBank:
    def __init__(self):
        self.items = []
    def add(self, value):
        self.items.append(value)

# The loop reads data, updates state, saves memory, and tests old behavior.
""" * 40,
        "04_poetry.txt": """
The river remembers the stone but does not stop moving.
A lantern in the rain is not the sun, but it is enough for the next step.
Old leaves teach the soil what the tree cannot say.
The small machine dreamed in sparks, then woke and counted every spark again.
Memory is a room with many doors. Learning is the courage to open one more.
""" * 40,
    }
    for name, text in files.items():
        (corpus_dir / name).write_text(clean_text(text), encoding="utf-8")


# ----------------------------
# Tiny Transformer language model
# ----------------------------

class CausalSelfAttention(nn.Module):
    def __init__(self, n_embd: int, n_head: int, dropout: float, block_size: int):
        super().__init__()
        assert n_embd % n_head == 0
        self.n_head = n_head
        self.head_dim = n_embd // n_head
        self.qkv = nn.Linear(n_embd, 3 * n_embd)
        self.proj = nn.Linear(n_embd, n_embd)
        self.dropout = nn.Dropout(dropout)
        mask = torch.tril(torch.ones(block_size, block_size)).view(1, 1, block_size, block_size)
        self.register_buffer("mask", mask)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        qkv = self.qkv(x)
        q, k, v = qkv.split(C, dim=2)
        q = q.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        k = k.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        v = v.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        att = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_dim)
        att = att.masked_fill(self.mask[:, :, :T, :T] == 0, float("-inf"))
        att = F.softmax(att, dim=-1)
        att = self.dropout(att)
        y = att @ v
        y = y.transpose(1, 2).contiguous().view(B, T, C)
        return self.dropout(self.proj(y))


class Block(nn.Module):
    def __init__(self, n_embd: int, n_head: int, dropout: float, block_size: int):
        super().__init__()
        self.ln1 = nn.LayerNorm(n_embd)
        self.attn = CausalSelfAttention(n_embd, n_head, dropout, block_size)
        self.ln2 = nn.LayerNorm(n_embd)
        self.ff = nn.Sequential(
            nn.Linear(n_embd, 4 * n_embd),
            nn.GELU(),
            nn.Linear(4 * n_embd, n_embd),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.ln1(x))
        x = x + self.ff(self.ln2(x))
        return x


class TinyGPT(nn.Module):
    def __init__(self, block_size: int = 128, n_embd: int = 96, n_head: int = 4, n_layer: int = 2, dropout: float = 0.1):
        super().__init__()
        self.block_size = block_size
        self.token_emb = nn.Embedding(VOCAB_SIZE, n_embd)
        self.pos_emb = nn.Embedding(block_size, n_embd)
        self.drop = nn.Dropout(dropout)
        self.blocks = nn.Sequential(*[Block(n_embd, n_head, dropout, block_size) for _ in range(n_layer)])
        self.ln_f = nn.LayerNorm(n_embd)
        self.head = nn.Linear(n_embd, VOCAB_SIZE, bias=False)
        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, idx: torch.Tensor, targets: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        B, T = idx.shape
        if T > self.block_size:
            raise ValueError(f"Sequence length {T} exceeds block_size {self.block_size}")
        pos = torch.arange(0, T, device=idx.device).unsqueeze(0)
        x = self.token_emb(idx) + self.pos_emb(pos)
        x = self.drop(x)
        x = self.blocks(x)
        x = self.ln_f(x)
        logits = self.head(x)
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, VOCAB_SIZE), targets.reshape(-1))
        return logits, loss

    @torch.no_grad()
    def generate(self, prompt: str, max_new_tokens: int = 300, temperature: float = 0.9, top_k: int = 50, device: str = "cpu") -> str:
        self.eval()
        idx = encode_bytes(prompt).unsqueeze(0).to(device)
        for _ in range(max_new_tokens):
            idx_cond = idx[:, -self.block_size :]
            logits, _ = self(idx_cond)
            logits = logits[:, -1, :] / max(temperature, 1e-6)
            if top_k is not None and top_k > 0:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, [-1]]] = -float("Inf")
            probs = F.softmax(logits, dim=-1)
            next_id = torch.multinomial(probs, num_samples=1)
            idx = torch.cat((idx, next_id), dim=1)
        return decode_bytes(idx[0].cpu())


# ----------------------------
# Replay memory selection
# ----------------------------

@dataclass
class MemoryConfig:
    memory_per_phase: int
    policy: str  # auto, balanced, diverse, hard_diverse


@torch.no_grad()
def chunk_loss(model: TinyGPT, chunk: torch.Tensor, device: torch.device) -> float:
    x = chunk[:-1].unsqueeze(0).to(device)
    y = chunk[1:].unsqueeze(0).to(device)
    _, loss = model(x, y)
    return float(loss.item())


def byte_hist_distance(chunks: List[torch.Tensor]) -> List[float]:
    """Cheap diversity score: distance from mean byte histogram."""
    if not chunks:
        return []
    hists = []
    for c in chunks:
        hist = torch.bincount(c, minlength=VOCAB_SIZE).float()
        hist = hist / hist.sum().clamp_min(1)
        hists.append(hist)
    H = torch.stack(hists)
    mean = H.mean(dim=0, keepdim=True)
    dist = torch.norm(H - mean, dim=1)
    return dist.tolist()


def select_memory_chunks(
    model: TinyGPT,
    chunks: List[torch.Tensor],
    cfg: MemoryConfig,
    device: torch.device,
) -> List[torch.Tensor]:
    if cfg.memory_per_phase <= 0:
        return []
    n = min(cfg.memory_per_phase, len(chunks))
    if len(chunks) <= n:
        return [c.cpu().clone() for c in chunks]

    policy = cfg.policy
    if policy == "auto":
        # Our experimental rule of thumb:
        # tiny memory: coverage/random; moderate: include hard chunks; larger: diverse + hard.
        if n < 80:
            policy = "balanced"
        elif n < 300:
            policy = "hard"
        else:
            policy = "hard_diverse"

    if policy == "balanced":
        return [c.cpu().clone() for c in random.sample(chunks, n)]

    if policy == "diverse":
        scores = byte_hist_distance(chunks)
        # choose evenly from low to high distance, not only extremes
        order = sorted(range(len(chunks)), key=lambda i: scores[i])
        picks = []
        for j in range(n):
            idx = order[int(j * (len(order) - 1) / max(1, n - 1))]
            picks.append(chunks[idx].cpu().clone())
        return picks

    # Hard examples = chunks the current/old model finds surprising.
    # This is the language-model analog of boundary examples.
    losses = [(i, chunk_loss(model, c, device)) for i, c in enumerate(chunks)]
    losses_sorted = sorted(losses, key=lambda x: x[1], reverse=True)

    if policy == "hard":
        chosen = [chunks[i].cpu().clone() for i, _ in losses_sorted[:n]]
        return chosen

    if policy == "hard_diverse":
        n_hard = int(0.50 * n)
        n_div = int(0.35 * n)
        n_proto = n - n_hard - n_div

        hard_ids = [i for i, _ in losses_sorted[:n_hard]]
        div_scores = byte_hist_distance(chunks)
        div_order = sorted(range(len(chunks)), key=lambda i: div_scores[i], reverse=True)
        proto_order = sorted(losses, key=lambda x: x[1])  # easiest chunks as prototypes

        chosen_ids = []
        for i in hard_ids:
            if i not in chosen_ids:
                chosen_ids.append(i)
        for i in div_order:
            if len(chosen_ids) >= n_hard + n_div:
                break
            if i not in chosen_ids:
                chosen_ids.append(i)
        for i, _ in proto_order:
            if len(chosen_ids) >= n:
                break
            if i not in chosen_ids:
                chosen_ids.append(i)
        return [chunks[i].cpu().clone() for i in chosen_ids]

    raise ValueError(f"Unknown memory policy: {cfg.policy}")


# ----------------------------
# Training / evaluation
# ----------------------------

@torch.no_grad()
def estimate_loss(model: TinyGPT, chunks: List[torch.Tensor], device: torch.device, eval_batches: int = 20, batch_size: int = 16) -> float:
    model.eval()
    losses = []
    if not chunks:
        return float("nan")
    for _ in range(eval_batches):
        x, y = sample_batch(chunks, batch_size, device)
        _, loss = model(x, y)
        losses.append(float(loss.item()))
    model.train()
    return sum(losses) / len(losses)


def distill_loss(student_logits: torch.Tensor, teacher_logits: torch.Tensor, T: float) -> torch.Tensor:
    # KL(teacher || student), averaged over sequence positions.
    s_logp = F.log_softmax(student_logits / T, dim=-1)
    t_p = F.softmax(teacher_logits / T, dim=-1)
    return (T * T) * F.kl_div(s_logp, t_p, reduction="batchmean") / student_logits.shape[1]


def anchor_loss(model: TinyGPT, old_state: Dict[str, torch.Tensor], device: torch.device) -> torch.Tensor:
    loss = torch.tensor(0.0, device=device)
    count = 0
    for name, p in model.named_parameters():
        if name in old_state:
            loss = loss + F.mse_loss(p, old_state[name].to(device), reduction="mean")
            count += 1
    return loss / max(1, count)


def train_phase(
    model: TinyGPT,
    phase: Dict,
    all_memory: List[torch.Tensor],
    old_teacher: Optional[TinyGPT],
    device: torch.device,
    args,
    phase_index: int,
    log_writer,
) -> None:
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    old_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()} if args.anchor_weight > 0 else None

    current_chunks = phase["chunks"]
    replay_available = len(all_memory) > 0

    # Memory-density policy: weak/no distill when memory is tiny, unless user overrides.
    if args.distill_weight < 0:
        spc_proxy = len(all_memory) / max(1, phase_index) if phase_index > 0 else 0
        if spc_proxy < 200:
            lambda_d = 0.0
        elif spc_proxy < 900:
            lambda_d = 0.05
        else:
            lambda_d = 0.15
    else:
        lambda_d = args.distill_weight

    for step in range(1, args.steps_per_phase + 1):
        optimizer.zero_grad(set_to_none=True)
        x_cur, y_cur = sample_batch(current_chunks, args.batch_size, device)
        logits_cur, ce_cur = model(x_cur, y_cur)
        loss = ce_cur
        ce_replay = torch.tensor(0.0, device=device)
        dloss = torch.tensor(0.0, device=device)
        aloss = torch.tensor(0.0, device=device)

        if replay_available and args.replay_batch > 0:
            x_rep, y_rep = sample_batch(all_memory, args.replay_batch, device)
            logits_rep, ce_replay = model(x_rep, y_rep)
            loss = loss + args.replay_ce_weight * ce_replay

            if old_teacher is not None and lambda_d > 0:
                with torch.no_grad():
                    teacher_logits, _ = old_teacher(x_rep)
                dloss = distill_loss(logits_rep, teacher_logits, args.temperature)
                loss = loss + lambda_d * dloss

        if old_state is not None and args.anchor_weight > 0:
            aloss = anchor_loss(model, old_state, device)
            loss = loss + args.anchor_weight * aloss

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
        optimizer.step()

        if step % args.print_every == 0 or step == 1 or step == args.steps_per_phase:
            print(
                f"phase {phase_index:02d} {phase['name']:<20} step {step:04d}/{args.steps_per_phase} "
                f"loss {loss.item():.4f} ce_cur {ce_cur.item():.4f} ce_rep {ce_replay.item():.4f} "
                f"distill {dloss.item():.4f} lambda_d {lambda_d:.3f} anchor {aloss.item():.6f}"
            )
            log_writer.writerow({
                "phase": phase_index,
                "phase_name": phase["name"],
                "step": step,
                "loss": float(loss.item()),
                "ce_current": float(ce_cur.item()),
                "ce_replay": float(ce_replay.item()),
                "distill": float(dloss.item()),
                "lambda_distill": float(lambda_d),
                "anchor": float(aloss.item()),
                "memory_chunks": len(all_memory),
            })


def evaluate_all_phases(model: TinyGPT, phases: List[Dict], seen_until: int, device: torch.device, args) -> Dict[str, float]:
    out = {}
    for i in range(seen_until + 1):
        loss = estimate_loss(model, phases[i]["chunks"], device, eval_batches=args.eval_batches, batch_size=args.batch_size)
        out[f"loss_phase_{i:02d}_{phases[i]['name']}"] = loss
        out[f"ppl_phase_{i:02d}_{phases[i]['name']}"] = math.exp(min(loss, 20))
    return out


# ----------------------------
# Main
# ----------------------------

def parse_args():
    p = argparse.ArgumentParser(description="A tiny continuously-learning replay/distillation language model.")
    p.add_argument("--corpus-dir", type=str, default="demo_corpus", help="Folder of .txt files; each file is one phase.")
    p.add_argument("--make-demo-corpus", action="store_true", help="Create a tiny demo corpus in corpus-dir first.")
    p.add_argument("--out-dir", type=str, default="runs_micro_lifelong")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", type=str, default="auto", choices=["auto", "cpu", "cuda"])

    p.add_argument("--block-size", type=int, default=128)
    p.add_argument("--n-embd", type=int, default=96)
    p.add_argument("--n-head", type=int, default=4)
    p.add_argument("--n-layer", type=int, default=2)
    p.add_argument("--dropout", type=float, default=0.1)

    p.add_argument("--steps-per-phase", type=int, default=300)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--replay-batch", type=int, default=16)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--weight-decay", type=float, default=0.01)
    p.add_argument("--grad-clip", type=float, default=1.0)
    p.add_argument("--replay-ce-weight", type=float, default=1.0)
    p.add_argument("--distill-weight", type=float, default=-1.0, help="-1 = auto by memory density; otherwise fixed lambda.")
    p.add_argument("--temperature", type=float, default=2.0)
    p.add_argument("--anchor-weight", type=float, default=0.0)

    p.add_argument("--memory-per-phase", type=int, default=300, help="Chunks retained after each phase.")
    p.add_argument("--memory-policy", type=str, default="auto", choices=["auto", "balanced", "diverse", "hard", "hard_diverse"])
    p.add_argument("--max-chars-per-file", type=int, default=None)
    p.add_argument("--eval-batches", type=int, default=20)
    p.add_argument("--print-every", type=int, default=50)
    p.add_argument("--generate-every-phase", action="store_true")
    p.add_argument("--prompt", type=str, default="Memory is")
    return p.parse_args()


def main():
    args = parse_args()
    set_seed(args.seed)
    corpus_dir = Path(args.corpus_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if args.make_demo_corpus:
        create_demo_corpus(corpus_dir)
        print(f"Demo corpus written to {corpus_dir.resolve()}")

    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)

    phases = load_phases(corpus_dir, block_size=args.block_size, max_chars_per_file=args.max_chars_per_file)
    print(f"Device: {device}")
    print(f"Loaded {len(phases)} phases from {corpus_dir}")
    for ph in phases:
        print(f"  phase {ph['id']:02d}: {ph['name']:<24} chars={len(ph['text']):>7} chunks={len(ph['chunks']):>5}")

    model = TinyGPT(
        block_size=args.block_size,
        n_embd=args.n_embd,
        n_head=args.n_head,
        n_layer=args.n_layer,
        dropout=args.dropout,
    ).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    print(f"Model parameters: {n_params:,} ({n_params/1e6:.3f}M)")

    memory_by_phase: Dict[int, List[torch.Tensor]] = {}
    eval_rows = []

    log_path = out_dir / "training_log.csv"
    with log_path.open("w", newline="", encoding="utf-8") as f:
        fieldnames = ["phase", "phase_name", "step", "loss", "ce_current", "ce_replay", "distill", "lambda_distill", "anchor", "memory_chunks"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for i, phase in enumerate(phases):
            print("\n" + "#" * 100)
            print(f"PHASE {i}: learning {phase['name']}")
            print("#" * 100)

            old_teacher = None
            if i > 0:
                old_teacher = copy.deepcopy(model).to(device)
                old_teacher.eval()
                for p in old_teacher.parameters():
                    p.requires_grad_(False)

            all_memory = []
            for chunks in memory_by_phase.values():
                all_memory.extend(chunks)
            print(f"Replay memory available: {len(all_memory)} chunks")

            train_phase(model, phase, all_memory, old_teacher, device, args, i, writer)

            # Evaluation after phase
            eval_dict = evaluate_all_phases(model, phases, i, device, args)
            eval_dict["after_phase"] = i
            eval_dict["after_phase_name"] = phase["name"]
            eval_rows.append(eval_dict)
            print("\nEvaluation on seen phases:")
            for k, v in eval_dict.items():
                if k.startswith("loss_phase"):
                    print(f"  {k}: {v:.4f} | ppl {math.exp(min(v,20)):.2f}")

            if args.generate_every_phase:
                print("\nSample generation:")
                print(model.generate(args.prompt, max_new_tokens=350, temperature=0.9, top_k=60, device=str(device)))

            # Update memory with selected chunks from this phase
            mem_cfg = MemoryConfig(memory_per_phase=args.memory_per_phase, policy=args.memory_policy)
            selected = select_memory_chunks(model, phase["chunks"], mem_cfg, device)
            memory_by_phase[i] = selected
            total_mem = sum(len(v) for v in memory_by_phase.values())
            print(f"Stored {len(selected)} chunks for phase {i}; total memory now {total_mem} chunks")

            torch.save({
                "model_state": model.state_dict(),
                "args": vars(args),
                "phase": i,
                "memory_by_phase": memory_by_phase,
            }, out_dir / f"checkpoint_after_phase_{i:02d}.pt")

    # Save evaluation CSV with flexible columns
    eval_path = out_dir / "eval_log.csv"
    all_fields = sorted(set().union(*(r.keys() for r in eval_rows))) if eval_rows else []
    with eval_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=all_fields)
        writer.writeheader()
        for r in eval_rows:
            writer.writerow(r)

    torch.save({
        "model_state": model.state_dict(),
        "args": vars(args),
        "memory_by_phase": memory_by_phase,
        "phase_names": [p["name"] for p in phases],
    }, out_dir / "model_final.pt")
    torch.save(memory_by_phase, out_dir / "memory.pt")

    print("\nFinal sample:")
    print(model.generate(args.prompt, max_new_tokens=500, temperature=0.9, top_k=60, device=str(device)))
    print(f"\nSaved outputs in: {out_dir.resolve()}")


if __name__ == "__main__":
    main()

```


---

## mnist_ablation_next.py

```python
# mnist_ablation_next.py
#
# Next ablation for the MNIST continual-learning memory-loop experiment.
#
# Goal:
#   Separate the ingredients that were bundled in the previous winning condition:
#       replay selection: none vs random vs curated
#       anchoring: off vs on
#       distillation: off vs on
#       soft consolidation: off vs on
#
# The CNN architecture is identical for every strategy.
# Phase 1 is trained ONCE per seed on the old digits, then the same saved Phase-1
# state is reloaded for every Phase-2 condition.
#
# Run:
#   pip install torch torchvision
#   python mnist_ablation_next.py
#
# Faster:
#   python mnist_ablation_next.py --phase1-epochs 2 --phase2-epochs 2 --replay-fractions 0,0.02,0.05
#
# More serious:
#   python mnist_ablation_next.py --seeds 42,43,44 --replay-fractions 0,0.01,0.02,0.05,0.10,0.20

import argparse
import csv
import copy
import math
import random
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import ConcatDataset, DataLoader, Dataset, Subset
from torchvision import datasets, transforms


# -----------------------------
# Configuration objects
# -----------------------------


@dataclass(frozen=True)
class Strategy:
    name: str
    replay_kind: str  # "none", "random", "curated"
    anchor_strength: float = 0.0
    distill_strength: float = 0.0
    soft_consolidation: bool = False


STRATEGIES: List[Strategy] = [
    # Basic controls
    Strategy("No replay", "none"),
    Strategy("Random replay", "random"),
    Strategy("Curated replay", "curated"),

    # Isolate anchoring alone
    Strategy("Random replay + anchor", "random", anchor_strength=5.0),
    Strategy("Curated replay + anchor", "curated", anchor_strength=5.0),

    # Isolate distillation alone
    Strategy("Random replay + distill", "random", distill_strength=0.70),
    Strategy("Curated replay + distill", "curated", distill_strength=0.70),

    # The likely important combination
    Strategy("Random replay + anchor/distill", "random", anchor_strength=5.0, distill_strength=0.70),
    Strategy("Curated replay + anchor/distill", "curated", anchor_strength=5.0, distill_strength=0.70),

    # Does soft consolidation add anything when anchor/distill is present?
    Strategy(
        "Random replay + soft + anchor/distill",
        "random",
        anchor_strength=5.0,
        distill_strength=0.70,
        soft_consolidation=True,
    ),
    Strategy(
        "Curated replay + soft + anchor/distill",
        "curated",
        anchor_strength=5.0,
        distill_strength=0.70,
        soft_consolidation=True,
    ),
]


# -----------------------------
# Utility
# -----------------------------


def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in text.split(",") if x.strip()]


def parse_floats(text: str) -> List[float]:
    out = []
    for x in text.split(","):
        x = x.strip()
        if not x:
            continue
        val = float(x)
        if val < 0.0 or val >= 1.0:
            raise ValueError("Replay fractions must be >= 0.0 and < 1.0")
        out.append(val)
    return out


def pct(x: float) -> str:
    return f"{100.0 * x:5.1f}%"


def acc_fmt(x: float) -> str:
    return f"{x:.4f}"


# -----------------------------
# Dataset helpers
# -----------------------------


def filter_by_digits(dataset: Dataset, digits: Sequence[int]) -> Subset:
    wanted = set(int(d) for d in digits)
    if hasattr(dataset, "targets"):
        labels = dataset.targets
        indices = [i for i, y in enumerate(labels) if int(y) in wanted]
    else:
        indices = [i for i, (_, y) in enumerate(dataset) if int(y) in wanted]
    return Subset(dataset, indices)


def subset_label(subset: Subset, local_idx: int) -> int:
    base_idx = subset.indices[local_idx]
    base = subset.dataset
    if hasattr(base, "targets"):
        return int(base.targets[base_idx])
    return int(base[base_idx][1])


class FlaggedDataset(Dataset):
    """Wraps a dataset so it returns (x, y, is_replay_old)."""

    def __init__(self, dataset: Dataset, is_replay_old: bool):
        self.dataset = dataset
        self.is_replay_old = bool(is_replay_old)

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int):
        x, y = self.dataset[idx]
        flag = 1 if self.is_replay_old else 0
        return x, int(y), flag


def make_loaders(
    data_dir: str,
    batch_size: int,
    old_digits: List[int],
    held_out_digits: List[int],
) -> Tuple[DataLoader, DataLoader, DataLoader, DataLoader, DataLoader, Subset, Subset]:
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])

    train_full = datasets.MNIST(root=data_dir, train=True, download=True, transform=transform)
    test_full = datasets.MNIST(root=data_dir, train=False, download=True, transform=transform)

    train_old = filter_by_digits(train_full, old_digits)
    train_new = filter_by_digits(train_full, held_out_digits)

    test_old = filter_by_digits(test_full, old_digits)
    test_new = filter_by_digits(test_full, held_out_digits)

    train_old_loader = DataLoader(train_old, batch_size=batch_size, shuffle=True)
    train_new_loader = DataLoader(train_new, batch_size=batch_size, shuffle=True)
    test_old_loader = DataLoader(test_old, batch_size=batch_size, shuffle=False)
    test_new_loader = DataLoader(test_new, batch_size=batch_size, shuffle=False)
    test_all_loader = DataLoader(test_full, batch_size=batch_size, shuffle=False)

    return (
        train_old_loader,
        train_new_loader,
        test_old_loader,
        test_new_loader,
        test_all_loader,
        train_old,
        train_new,
    )


# -----------------------------
# Model
# -----------------------------


class SmallCNN(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, 10)

    def features(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = torch.flatten(x, 1)
        x = F.relu(self.fc1(x))
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.features(x)
        return self.fc2(z)


# -----------------------------
# Optimizers and losses
# -----------------------------


def make_optimizer(model: SmallCNN, strategy: Optional[Strategy] = None) -> torch.optim.Optimizer:
    """
    Same architecture for all strategies.
    Soft consolidation only changes Phase-2 learning rates, not layers/parameters.
    """
    if strategy is not None and strategy.soft_consolidation:
        groups = [
            {"name": "conv1", "params": model.conv1.parameters(), "lr": 3e-4},
            {"name": "conv2", "params": model.conv2.parameters(), "lr": 5e-4},
            {"name": "fc1", "params": model.fc1.parameters(), "lr": 8e-4},
            {"name": "fc2", "params": model.fc2.parameters(), "lr": 1e-3},
        ]
    else:
        groups = [
            {"name": "conv1", "params": model.conv1.parameters(), "lr": 1e-3},
            {"name": "conv2", "params": model.conv2.parameters(), "lr": 1e-3},
            {"name": "fc1", "params": model.fc1.parameters(), "lr": 1e-3},
            {"name": "fc2", "params": model.fc2.parameters(), "lr": 1e-3},
        ]
    return torch.optim.Adam(groups)


def mask_logits_to_digits(logits: torch.Tensor, allowed_digits: Optional[List[int]]) -> torch.Tensor:
    if allowed_digits is None:
        return logits
    masked = torch.full_like(logits, -1e9)
    allowed = torch.tensor(allowed_digits, dtype=torch.long, device=logits.device)
    masked[:, allowed] = logits[:, allowed]
    return masked


def parameter_anchor_loss(model: nn.Module, anchor_state: Dict[str, torch.Tensor]) -> torch.Tensor:
    total = None
    count = 0
    for name, p in model.named_parameters():
        old = anchor_state[name].to(p.device)
        term = (p - old).pow(2).sum()
        total = term if total is None else total + term
        count += p.numel()
    assert total is not None
    return total / max(1, count)


def distillation_loss(
    student_logits: torch.Tensor,
    teacher_logits: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    t = temperature
    student_log_probs = F.log_softmax(student_logits / t, dim=1)
    teacher_probs = F.softmax(teacher_logits / t, dim=1)
    return F.kl_div(student_log_probs, teacher_probs, reduction="batchmean") * (t * t)


# -----------------------------
# Phase 1 training and evaluation
# -----------------------------


def train_phase1_epoch(
    model: SmallCNN,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: str,
    old_digits: List[int],
) -> float:
    model.train()
    total_loss = 0.0
    total_seen = 0
    for x, y in loader:
        x = x.to(device)
        y = y.to(device)
        optimizer.zero_grad(set_to_none=True)
        logits = mask_logits_to_digits(model(x), old_digits)
        loss = F.cross_entropy(logits, y)
        loss.backward()
        optimizer.step()
        total_loss += float(loss.item()) * x.size(0)
        total_seen += x.size(0)
    return total_loss / max(1, total_seen)


@torch.no_grad()
def accuracy(model: SmallCNN, loader: DataLoader, device: str) -> float:
    model.eval()
    correct = 0
    total = 0
    for x, y in loader:
        x = x.to(device)
        y = y.to(device)
        logits = model(x)
        pred = logits.argmax(dim=1)
        correct += int((pred == y).sum().item())
        total += int(y.numel())
    return correct / max(1, total)


# -----------------------------
# Memory selection
# -----------------------------


def replay_budget(n_new: int, replay_fraction: float, max_old: int) -> int:
    """
    If replay_fraction is the fraction of the Phase-2 mixed dataset that is old:
        budget / (budget + n_new) = replay_fraction
    """
    if replay_fraction <= 0.0:
        return 0
    n = int((replay_fraction / (1.0 - replay_fraction)) * n_new)
    return max(1, min(n, max_old))


def indices_by_digit(subset: Subset, digits: List[int]) -> Dict[int, List[int]]:
    out = {d: [] for d in digits}
    for i in range(len(subset)):
        y = subset_label(subset, i)
        if y in out:
            out[y].append(i)
    return out


def balanced_random_indices(
    train_old: Subset,
    old_digits: List[int],
    budget: int,
    seed: int,
) -> List[int]:
    if budget <= 0:
        return []
    rng = random.Random(seed)
    by_digit = indices_by_digit(train_old, old_digits)
    selected: List[int] = []

    base = budget // len(old_digits)
    extra = budget % len(old_digits)
    shuffled_digits = list(old_digits)
    rng.shuffle(shuffled_digits)

    for rank, d in enumerate(shuffled_digits):
        k = base + (1 if rank < extra else 0)
        pool = by_digit[d]
        if not pool:
            continue
        k = min(k, len(pool))
        selected.extend(rng.sample(pool, k))

    # Fill if some class was too small.
    if len(selected) < budget:
        remaining = list(set(range(len(train_old))) - set(selected))
        rng.shuffle(remaining)
        selected.extend(remaining[: budget - len(selected)])

    rng.shuffle(selected)
    return selected[:budget]


@torch.no_grad()
def curated_indices(
    model: SmallCNN,
    train_old: Subset,
    old_digits: List[int],
    budget: int,
    batch_size: int,
    device: str,
    seed: int,
    hard_fraction: float = 0.50,
) -> List[int]:
    """
    Curated memory selection.

    For each old digit, select a balanced mix of:
      1. hard examples: low confidence for the true class
      2. representative examples: closest to the feature centroid

    This intentionally tests whether model-chosen memory beats random memory.
    """
    if budget <= 0:
        return []

    loader = DataLoader(train_old, batch_size=batch_size, shuffle=False)
    model.eval()

    all_features: List[torch.Tensor] = []
    all_labels: List[torch.Tensor] = []
    all_conf: List[torch.Tensor] = []

    for x, y in loader:
        x = x.to(device)
        y = y.to(device)
        feats = model.features(x)
        logits = model.fc2(feats)
        probs = F.softmax(logits, dim=1)
        conf = probs.gather(1, y.view(-1, 1)).squeeze(1)
        all_features.append(feats.cpu())
        all_labels.append(y.cpu())
        all_conf.append(conf.cpu())

    features = torch.cat(all_features, dim=0)
    labels = torch.cat(all_labels, dim=0)
    confs = torch.cat(all_conf, dim=0)

    rng = random.Random(seed)
    selected: List[int] = []

    base = budget // len(old_digits)
    extra = budget % len(old_digits)
    digit_order = list(old_digits)
    rng.shuffle(digit_order)

    for rank, d in enumerate(digit_order):
        k = base + (1 if rank < extra else 0)
        class_idxs = (labels == d).nonzero(as_tuple=False).view(-1)
        if class_idxs.numel() == 0 or k <= 0:
            continue

        class_features = features[class_idxs]
        class_confs = confs[class_idxs]

        # Hard examples: lowest confidence.
        k_hard = int(round(k * hard_fraction))
        k_hard = min(k_hard, class_idxs.numel())
        hard_local = torch.argsort(class_confs, descending=False)[:k_hard]
        hard_global = class_idxs[hard_local].tolist()

        # Representative examples: closest to centroid, excluding hard examples if possible.
        k_rep = k - len(hard_global)
        centroid = class_features.mean(dim=0, keepdim=True)
        dist = torch.norm(class_features - centroid, dim=1)
        rep_order = torch.argsort(dist, descending=False).tolist()

        chosen_for_class = list(hard_global)
        used = set(chosen_for_class)
        for local_idx in rep_order:
            global_idx = int(class_idxs[local_idx].item())
            if global_idx in used:
                continue
            chosen_for_class.append(global_idx)
            used.add(global_idx)
            if len(chosen_for_class) >= k:
                break

        selected.extend(chosen_for_class)

    # Fill if needed.
    if len(selected) < budget:
        remaining = list(set(range(len(train_old))) - set(selected))
        rng.shuffle(remaining)
        selected.extend(remaining[: budget - len(selected)])

    rng.shuffle(selected)
    return selected[:budget]


def make_phase2_loader(
    train_new: Subset,
    train_old: Subset,
    replay_indices: List[int],
    batch_size: int,
    seed: int,
) -> DataLoader:
    datasets_for_phase2: List[Dataset] = [FlaggedDataset(train_new, is_replay_old=False)]
    if replay_indices:
        replay_subset = Subset(train_old, replay_indices)
        datasets_for_phase2.append(FlaggedDataset(replay_subset, is_replay_old=True))
    mixed = ConcatDataset(datasets_for_phase2)
    generator = torch.Generator()
    generator.manual_seed(seed)
    return DataLoader(mixed, batch_size=batch_size, shuffle=True, generator=generator)


# -----------------------------
# Phase 2 training
# -----------------------------


def train_phase2_epoch(
    model: SmallCNN,
    teacher: SmallCNN,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    strategy: Strategy,
    anchor_state: Dict[str, torch.Tensor],
    device: str,
    temperature: float,
) -> Dict[str, float]:
    model.train()
    teacher.eval()

    total_loss = 0.0
    total_ce = 0.0
    total_anchor = 0.0
    total_distill = 0.0
    total_seen = 0

    for x, y, is_old in loader:
        x = x.to(device)
        y = y.to(device)
        is_old = is_old.to(device).bool()

        optimizer.zero_grad(set_to_none=True)
        logits = model(x)

        ce = F.cross_entropy(logits, y)

        anchor = torch.zeros((), device=device)
        if strategy.anchor_strength > 0.0:
            anchor = parameter_anchor_loss(model, anchor_state)

        distill = torch.zeros((), device=device)
        if strategy.distill_strength > 0.0 and is_old.any():
            with torch.no_grad():
                teacher_logits = teacher(x[is_old])
            student_logits = logits[is_old]
            distill = distillation_loss(student_logits, teacher_logits, temperature=temperature)

        loss = ce + strategy.anchor_strength * anchor + strategy.distill_strength * distill
        loss.backward()
        optimizer.step()

        n = x.size(0)
        total_loss += float(loss.item()) * n
        total_ce += float(ce.item()) * n
        total_anchor += float(anchor.item()) * n
        total_distill += float(distill.item()) * n
        total_seen += n

    denom = max(1, total_seen)
    return {
        "loss": total_loss / denom,
        "ce": total_ce / denom,
        "anchor": total_anchor / denom,
        "distill": total_distill / denom,
    }


# -----------------------------
# Experiment
# -----------------------------


def select_replay_indices(
    strategy: Strategy,
    replay_fraction: float,
    model_after_phase1: SmallCNN,
    train_old: Subset,
    train_new: Subset,
    old_digits: List[int],
    batch_size: int,
    device: str,
    seed: int,
) -> List[int]:
    if strategy.replay_kind == "none":
        return []

    budget = replay_budget(len(train_new), replay_fraction, len(train_old))
    if budget <= 0:
        return []

    if strategy.replay_kind == "random":
        return balanced_random_indices(train_old, old_digits, budget, seed=seed)

    if strategy.replay_kind == "curated":
        return curated_indices(
            model=model_after_phase1,
            train_old=train_old,
            old_digits=old_digits,
            budget=budget,
            batch_size=batch_size,
            device=device,
            seed=seed,
            hard_fraction=0.50,
        )

    raise ValueError(f"Unknown replay_kind: {strategy.replay_kind}")


def run_one_condition(
    seed: int,
    replay_fraction: float,
    strategy: Strategy,
    phase1_state: Dict[str, torch.Tensor],
    phase1_metrics: Dict[str, float],
    teacher: SmallCNN,
    train_old: Subset,
    train_new: Subset,
    test_old_loader: DataLoader,
    test_new_loader: DataLoader,
    test_all_loader: DataLoader,
    old_digits: List[int],
    batch_size: int,
    phase2_epochs: int,
    device: str,
    temperature: float,
    condition_seed: int,
    quiet: bool,
) -> Dict[str, object]:
    model = SmallCNN().to(device)
    model.load_state_dict(copy.deepcopy(phase1_state))
    optimizer = make_optimizer(model, strategy)

    replay_indices = select_replay_indices(
        strategy=strategy,
        replay_fraction=replay_fraction,
        model_after_phase1=teacher,
        train_old=train_old,
        train_new=train_new,
        old_digits=old_digits,
        batch_size=batch_size,
        device=device,
        seed=condition_seed,
    )

    phase2_loader = make_phase2_loader(
        train_new=train_new,
        train_old=train_old,
        replay_indices=replay_indices,
        batch_size=batch_size,
        seed=condition_seed + 77,
    )

    anchor_state = {k: v.detach().clone().to(device) for k, v in phase1_state.items()}

    if not quiet:
        print("=" * 132)
        print(f"Seed={seed} | Replay={pct(replay_fraction)} | {strategy.name} | budget={len(replay_indices)}")
        print("=" * 132)

    last_losses = {"loss": 0.0, "ce": 0.0, "anchor": 0.0, "distill": 0.0}
    for epoch in range(1, phase2_epochs + 1):
        last_losses = train_phase2_epoch(
            model=model,
            teacher=teacher,
            loader=phase2_loader,
            optimizer=optimizer,
            strategy=strategy,
            anchor_state=anchor_state,
            device=device,
            temperature=temperature,
        )
        old_acc_now = accuracy(model, test_old_loader, device)
        if not quiet:
            print(
                f"Phase 2 epoch {epoch:02d} | "
                f"loss {last_losses['loss']:.4f} | "
                f"ce {last_losses['ce']:.4f} | "
                f"anchor {last_losses['anchor']:.6f} | "
                f"distill {last_losses['distill']:.4f} | "
                f"old_acc {old_acc_now:.4f}"
            )

    old_p2 = accuracy(model, test_old_loader, device)
    new_p2 = accuracy(model, test_new_loader, device)
    all_p2 = accuracy(model, test_all_loader, device)
    forgetting = phase1_metrics["old_p1"] - old_p2
    stability_score = all_p2 - forgetting
    harmonic_old_new = 2.0 * old_p2 * new_p2 / max(1e-12, old_p2 + new_p2)

    result: Dict[str, object] = {
        "seed": seed,
        "replay_fraction": replay_fraction,
        "strategy": strategy.name,
        "replay_kind": strategy.replay_kind,
        "budget": len(replay_indices),
        "anchor_strength": strategy.anchor_strength,
        "distill_strength": strategy.distill_strength,
        "soft_consolidation": strategy.soft_consolidation,
        "old_p1": phase1_metrics["old_p1"],
        "new_p1": phase1_metrics["new_p1"],
        "all_p1": phase1_metrics["all_p1"],
        "old_p2": old_p2,
        "new_p2": new_p2,
        "all_p2": all_p2,
        "forgetting": forgetting,
        "stability_score": stability_score,
        "harmonic_old_new": harmonic_old_new,
        "final_loss": last_losses["loss"],
        "final_ce": last_losses["ce"],
        "final_anchor_loss": last_losses["anchor"],
        "final_distill_loss": last_losses["distill"],
    }

    if not quiet:
        print(
            f"Result | Old P2={old_p2:.4f} | New P2={new_p2:.4f} | "
            f"All P2={all_p2:.4f} | Forget={forgetting:.4f} | "
            f"Score={stability_score:.4f} | H(old,new)={harmonic_old_new:.4f}\n"
        )

    return result


def train_phase1_once(
    seed: int,
    train_old_loader: DataLoader,
    test_old_loader: DataLoader,
    test_new_loader: DataLoader,
    test_all_loader: DataLoader,
    old_digits: List[int],
    phase1_epochs: int,
    device: str,
    quiet: bool,
) -> Tuple[Dict[str, torch.Tensor], Dict[str, float], SmallCNN]:
    set_seed(seed)
    model = SmallCNN().to(device)
    optimizer = make_optimizer(model, strategy=None)

    if not quiet:
        print("\n" + "#" * 110)
        print(f"PHASE 1: train one conventional CNN on old digits only | seed={seed}")
        print("#" * 110)

    for epoch in range(1, phase1_epochs + 1):
        loss = train_phase1_epoch(model, train_old_loader, optimizer, device, old_digits)
        old_acc_now = accuracy(model, test_old_loader, device)
        if not quiet:
            print(f"Phase 1 epoch {epoch:02d} | loss {loss:.4f} | old_acc {old_acc_now:.4f}")

    old_p1 = accuracy(model, test_old_loader, device)
    new_p1 = accuracy(model, test_new_loader, device)
    all_p1 = accuracy(model, test_all_loader, device)

    if not quiet:
        print(f"Phase 1 saved state | old={old_p1:.4f} | new={new_p1:.4f} | all={all_p1:.4f}")

    state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    teacher = SmallCNN().to(device)
    teacher.load_state_dict(copy.deepcopy(state))
    teacher.eval()
    for p in teacher.parameters():
        p.requires_grad_(False)

    metrics = {"old_p1": old_p1, "new_p1": new_p1, "all_p1": all_p1}
    return state, metrics, teacher


def print_results(results: List[Dict[str, object]]) -> None:
    print("\nFINAL ABLATION RESULTS")
    print("=" * 172)
    print(
        f"{'Seed':>5s} {'Replay':>8s} {'Strategy':52s} {'Budget':>7s} "
        f"{'Old P2':>8s} {'New P2':>8s} {'All P2':>8s} {'Forget':>8s} "
        f"{'Score':>8s} {'Harmonic':>9s}"
    )
    print("-" * 172)

    for r in sorted(results, key=lambda x: (int(x["seed"]), float(x["replay_fraction"]), str(x["strategy"]))):
        print(
            f"{int(r['seed']):5d} {pct(float(r['replay_fraction'])):>8s} "
            f"{str(r['strategy']):52s} {int(r['budget']):7d} "
            f"{acc_fmt(float(r['old_p2'])):>8s} {acc_fmt(float(r['new_p2'])):>8s} "
            f"{acc_fmt(float(r['all_p2'])):>8s} {acc_fmt(float(r['forgetting'])):>8s} "
            f"{acc_fmt(float(r['stability_score'])):>8s} {acc_fmt(float(r['harmonic_old_new'])):>9s}"
        )


def average_results(results: List[Dict[str, object]]) -> List[Dict[str, object]]:
    grouped: Dict[Tuple[float, str], List[Dict[str, object]]] = {}
    for r in results:
        key = (float(r["replay_fraction"]), str(r["strategy"]))
        grouped.setdefault(key, []).append(r)

    avg_rows: List[Dict[str, object]] = []
    numeric_fields = [
        "budget",
        "old_p1",
        "new_p1",
        "all_p1",
        "old_p2",
        "new_p2",
        "all_p2",
        "forgetting",
        "stability_score",
        "harmonic_old_new",
        "final_loss",
        "final_ce",
        "final_anchor_loss",
        "final_distill_loss",
    ]

    for (frac, strat), rows in grouped.items():
        out: Dict[str, object] = {
            "replay_fraction": frac,
            "strategy": strat,
            "n_seeds": len(rows),
        }
        for field in numeric_fields:
            vals = [float(r[field]) for r in rows]
            out[field] = sum(vals) / len(vals)
        avg_rows.append(out)

    return sorted(avg_rows, key=lambda x: (float(x["replay_fraction"]), str(x["strategy"])))


def print_average_results(avg_rows: List[Dict[str, object]]) -> None:
    print("\nAVERAGE RESULTS OVER SEEDS")
    print("=" * 172)
    print(
        f"{'Replay':>8s} {'Strategy':52s} {'Seeds':>5s} {'Budget':>7s} "
        f"{'Old P2':>8s} {'New P2':>8s} {'All P2':>8s} {'Forget':>8s} "
        f"{'Score':>8s} {'Harmonic':>9s}"
    )
    print("-" * 172)
    for r in avg_rows:
        print(
            f"{pct(float(r['replay_fraction'])):>8s} {str(r['strategy']):52s} {int(r['n_seeds']):5d} "
            f"{float(r['budget']):7.1f} {acc_fmt(float(r['old_p2'])):>8s} "
            f"{acc_fmt(float(r['new_p2'])):>8s} {acc_fmt(float(r['all_p2'])):>8s} "
            f"{acc_fmt(float(r['forgetting'])):>8s} {acc_fmt(float(r['stability_score'])):>8s} "
            f"{acc_fmt(float(r['harmonic_old_new'])):>9s}"
        )


def print_best_by_replay(avg_rows: List[Dict[str, object]]) -> None:
    print("\nBEST BY REPLAY FRACTION")
    print("=" * 172)
    print("Primary sort: stability_score = All P2 - Forget. Secondary: harmonic mean of Old P2 and New P2.")
    print("-" * 172)
    fracs = sorted(set(float(r["replay_fraction"]) for r in avg_rows))
    for frac in fracs:
        rows = [r for r in avg_rows if float(r["replay_fraction"]) == frac]
        best = sorted(
            rows,
            key=lambda r: (float(r["stability_score"]), float(r["harmonic_old_new"]), float(r["all_p2"])),
            reverse=True,
        )[0]
        print(
            f"Replay {pct(frac)} | best: {best['strategy']} | "
            f"Old P2={float(best['old_p2']):.4f} | "
            f"New P2={float(best['new_p2']):.4f} | "
            f"All P2={float(best['all_p2']):.4f} | "
            f"Forget={float(best['forgetting']):.4f} | "
            f"Score={float(best['stability_score']):.4f} | "
            f"H={float(best['harmonic_old_new']):.4f}"
        )


def save_csv(path: str, rows: List[Dict[str, object]]) -> None:
    if not rows:
        return
    fieldnames = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


# -----------------------------
# Main
# -----------------------------


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=str, default="./data")
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--phase1-epochs", type=int, default=3)
    parser.add_argument("--phase2-epochs", type=int, default=3)
    parser.add_argument("--held-out", type=str, default="3,6,9")
    parser.add_argument("--replay-fractions", type=str, default="0,0.01,0.02,0.05,0.10,0.20")
    parser.add_argument("--seeds", type=str, default="42")
    parser.add_argument("--temperature", type=float, default=2.0)
    parser.add_argument("--csv", type=str, default="mnist_ablation_next_results.csv")
    parser.add_argument("--avg-csv", type=str, default="mnist_ablation_next_avg_results.csv")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    held_out_digits = parse_ints(args.held_out)
    old_digits = [d for d in range(10) if d not in held_out_digits]
    replay_fractions = parse_floats(args.replay_fractions)
    seeds = parse_ints(args.seeds)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    print(f"Device:           {device}")
    print(f"Old digits:       {old_digits}")
    print(f"Held-out digits:  {held_out_digits}")
    print(f"Replay fractions: {replay_fractions}")
    print(f"Seeds:            {seeds}")
    print("CNN architecture: identical for every strategy")
    print("Ablation: replay selection x anchor x distill x soft consolidation")
    print()

    loaders = make_loaders(
        data_dir=args.data_dir,
        batch_size=args.batch_size,
        old_digits=old_digits,
        held_out_digits=held_out_digits,
    )
    (
        train_old_loader,
        _train_new_loader,
        test_old_loader,
        test_new_loader,
        test_all_loader,
        train_old,
        train_new,
    ) = loaders

    all_results: List[Dict[str, object]] = []

    for seed in seeds:
        phase1_state, phase1_metrics, teacher = train_phase1_once(
            seed=seed,
            train_old_loader=train_old_loader,
            test_old_loader=test_old_loader,
            test_new_loader=test_new_loader,
            test_all_loader=test_all_loader,
            old_digits=old_digits,
            phase1_epochs=args.phase1_epochs,
            device=device,
            quiet=args.quiet,
        )

        condition_counter = 0
        for replay_fraction in replay_fractions:
            for strategy in STRATEGIES:
                condition_counter += 1
                condition_seed = seed * 1000003 + condition_counter * 9176
                result = run_one_condition(
                    seed=seed,
                    replay_fraction=replay_fraction,
                    strategy=strategy,
                    phase1_state=phase1_state,
                    phase1_metrics=phase1_metrics,
                    teacher=teacher,
                    train_old=train_old,
                    train_new=train_new,
                    test_old_loader=test_old_loader,
                    test_new_loader=test_new_loader,
                    test_all_loader=test_all_loader,
                    old_digits=old_digits,
                    batch_size=args.batch_size,
                    phase2_epochs=args.phase2_epochs,
                    device=device,
                    temperature=args.temperature,
                    condition_seed=condition_seed,
                    quiet=args.quiet,
                )
                all_results.append(result)

    print_results(all_results)
    avg_rows = average_results(all_results)
    print_average_results(avg_rows)
    print_best_by_replay(avg_rows)

    save_csv(args.csv, all_results)
    save_csv(args.avg_csv, avg_rows)
    print()
    print(f"Saved per-run results to: {args.csv}")
    print(f"Saved average results to: {args.avg_csv}")


if __name__ == "__main__":
    main()

```


---

## mnist_memory_loop_compare.py

```python
# mnist_memory_loop_compare.py
#
# Continual MNIST experiment with a learned/curated replay memory loop.
#
# Same CNN architecture for all conditions. No extra model parameters are added.
# The only differences are training strategy in Phase 2:
#   1. Conventional CNN, no replay
#   2. Conventional CNN, random replay
#   3. Conventional CNN, curated replay chosen by the trained model
#   4. Curated replay + soft consolidation learning rates
#   5. Curated replay + soft consolidation + anchoring + distillation
#
# Concept:
#   Phase 1: learn old digits only.
#   Phase 2: learn held-out digits, with or without an old-digit memory loop.
#
# Run:
#   pip install torch torchvision
#   python mnist_memory_loop_compare.py
#
# Faster first run:
#   python mnist_memory_loop_compare.py --phase1-epochs 2 --phase2-epochs 2 --replay-fractions 0,0.05,0.10
#
# More serious run:
#   python mnist_memory_loop_compare.py --seeds 42,43,44 --phase1-epochs 3 --phase2-epochs 3 --replay-fractions 0,0.02,0.05,0.10,0.20

import argparse
import copy
import csv
import math
import random
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import ConcatDataset, DataLoader, Dataset, Subset
from torchvision import datasets, transforms


# -----------------------------
# Utilities
# -----------------------------


def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_float_list(text: str) -> List[float]:
    vals = []
    for x in text.split(','):
        x = x.strip()
        if x:
            vals.append(float(x))
    return vals


def parse_int_list(text: str) -> List[int]:
    vals = []
    for x in text.split(','):
        x = x.strip()
        if x:
            vals.append(int(x))
    return vals


def pct(x: float) -> str:
    return f"{100.0 * x:5.1f}%"


def fmt(x: float) -> str:
    return f"{x:.4f}"


# -----------------------------
# Dataset helpers
# -----------------------------


def filter_by_digits(dataset: Dataset, digits: Sequence[int]) -> Subset:
    wanted = set(int(d) for d in digits)
    if hasattr(dataset, 'targets'):
        labels = dataset.targets
        indices = [i for i, y in enumerate(labels) if int(y) in wanted]
    else:
        indices = [i for i, (_, y) in enumerate(dataset) if int(y) in wanted]
    return Subset(dataset, indices)


class MarkedDataset(Dataset):
    """Wraps a dataset and returns (x, y, source_flag). source_flag: 0=new, 1=replay."""

    def __init__(self, base: Dataset, source_flag: int) -> None:
        self.base = base
        self.source_flag = int(source_flag)

    def __len__(self) -> int:
        return len(self.base)

    def __getitem__(self, idx: int):
        x, y = self.base[idx]
        return x, y, self.source_flag


def make_loaders(
    data_dir: str,
    batch_size: int,
    old_digits: Sequence[int],
    held_out_digits: Sequence[int],
) -> Tuple[DataLoader, DataLoader, DataLoader, DataLoader, DataLoader, Subset, Subset]:
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])

    train_full = datasets.MNIST(root=data_dir, train=True, download=True, transform=transform)
    test_full = datasets.MNIST(root=data_dir, train=False, download=True, transform=transform)

    train_old = filter_by_digits(train_full, old_digits)
    train_new = filter_by_digits(train_full, held_out_digits)
    test_old = filter_by_digits(test_full, old_digits)
    test_new = filter_by_digits(test_full, held_out_digits)

    train_old_loader = DataLoader(train_old, batch_size=batch_size, shuffle=True)
    train_new_loader = DataLoader(train_new, batch_size=batch_size, shuffle=True)
    test_old_loader = DataLoader(test_old, batch_size=batch_size, shuffle=False)
    test_new_loader = DataLoader(test_new, batch_size=batch_size, shuffle=False)
    test_all_loader = DataLoader(test_full, batch_size=batch_size, shuffle=False)

    return (
        train_old_loader,
        train_new_loader,
        test_old_loader,
        test_new_loader,
        test_all_loader,
        train_old,
        train_new,
    )


# -----------------------------
# Same CNN for every condition
# -----------------------------


class SmallCNN(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, 10)

    def features(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = torch.flatten(x, 1)
        x = F.relu(self.fc1(x))
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        return self.fc2(x)


# -----------------------------
# Training strategy definitions
# -----------------------------


@dataclass
class Strategy:
    name: str
    memory_mode: str  # none, random, curated
    soft_consolidation: bool = False
    anchor_lambda: float = 0.0
    distill_lambda: float = 0.0
    temperature: float = 2.0


STRATEGIES: List[Strategy] = [
    Strategy(
        name='Conventional CNN: no replay',
        memory_mode='none',
    ),
    Strategy(
        name='Conventional CNN: random replay',
        memory_mode='random',
    ),
    Strategy(
        name='Conventional CNN: curated replay',
        memory_mode='curated',
    ),
    Strategy(
        name='Memory-loop: curated + soft consolidation',
        memory_mode='curated',
        soft_consolidation=True,
    ),
    Strategy(
        name='Memory-loop: curated + soft consolidation + anchor/distill',
        memory_mode='curated',
        soft_consolidation=True,
        anchor_lambda=5.0,
        distill_lambda=0.7,
        temperature=2.0,
    ),
]


def make_optimizer(
    model: SmallCNN,
    base_lr: float,
    soft_consolidation: bool,
) -> torch.optim.Optimizer:
    """
    Same model parameters. Different phase-2 learning schedule.

    Conventional:
        all layers use base_lr.

    Soft consolidation:
        conv1 slows strongly, conv2 slows moderately, fc layers stay plastic.
        This is not a hard freeze; early visual machinery can still move.
    """
    if not soft_consolidation:
        lr_conv1 = base_lr
        lr_conv2 = base_lr
        lr_fc1 = base_lr
        lr_fc2 = base_lr
    else:
        lr_conv1 = base_lr * 0.05
        lr_conv2 = base_lr * 0.20
        lr_fc1 = base_lr
        lr_fc2 = base_lr

    return torch.optim.Adam([
        {'name': 'conv1', 'params': model.conv1.parameters(), 'lr': lr_conv1},
        {'name': 'conv2', 'params': model.conv2.parameters(), 'lr': lr_conv2},
        {'name': 'fc1', 'params': model.fc1.parameters(), 'lr': lr_fc1},
        {'name': 'fc2', 'params': model.fc2.parameters(), 'lr': lr_fc2},
    ])


# -----------------------------
# Phase 1 loss masking
# -----------------------------


def mask_logits_to_digits(logits: torch.Tensor, allowed_digits: Optional[Sequence[int]]) -> torch.Tensor:
    if allowed_digits is None:
        return logits
    masked = torch.full_like(logits, -1e9)
    idx = torch.tensor(list(allowed_digits), dtype=torch.long, device=logits.device)
    masked[:, idx] = logits[:, idx]
    return masked


# -----------------------------
# Evaluation
# -----------------------------


@torch.no_grad()
def accuracy(model: nn.Module, loader: DataLoader, device: str) -> float:
    model.eval()
    correct = 0
    total = 0
    for x, y in loader:
        x = x.to(device)
        y = y.to(device)
        logits = model(x)
        pred = logits.argmax(dim=1)
        correct += int((pred == y).sum().item())
        total += int(y.numel())
    return correct / max(1, total)


# -----------------------------
# Phase 1 training
# -----------------------------


def train_phase1(
    model: SmallCNN,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: str,
    old_digits: Sequence[int],
    epochs: int,
    test_old_loader: DataLoader,
    quiet: bool,
) -> None:
    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0
        total_seen = 0

        for x, y in loader:
            x = x.to(device)
            y = y.to(device)

            optimizer.zero_grad(set_to_none=True)
            logits = model(x)
            logits = mask_logits_to_digits(logits, old_digits)
            loss = F.cross_entropy(logits, y)
            loss.backward()
            optimizer.step()

            total_loss += float(loss.item()) * x.size(0)
            total_seen += x.size(0)

        if not quiet:
            old_acc = accuracy(model, test_old_loader, device)
            print(f"Phase 1 epoch {epoch:02d} | loss {total_loss / max(1, total_seen):.4f} | old_acc {old_acc:.4f}")


# -----------------------------
# Curated memory selection
# -----------------------------


@torch.no_grad()
def collect_old_features(
    model: SmallCNN,
    train_old_subset: Subset,
    batch_size: int,
    device: str,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    Returns:
        rel_indices: indices into train_old_subset
        labels: labels
        features: fc1 embeddings
        correct_probs: model probability assigned to the true label
    """
    loader = DataLoader(train_old_subset, batch_size=batch_size, shuffle=False)
    model.eval()

    all_rel_indices: List[torch.Tensor] = []
    all_labels: List[torch.Tensor] = []
    all_feats: List[torch.Tensor] = []
    all_probs: List[torch.Tensor] = []

    offset = 0
    for x, y in loader:
        batch_n = x.size(0)
        rel_idx = torch.arange(offset, offset + batch_n, dtype=torch.long)
        offset += batch_n

        x = x.to(device)
        y_dev = y.to(device)
        feats = model.features(x)
        logits = model.fc2(feats)
        probs = F.softmax(logits, dim=1)
        true_probs = probs.gather(1, y_dev.view(-1, 1)).squeeze(1)

        all_rel_indices.append(rel_idx.cpu())
        all_labels.append(y.long().cpu())
        all_feats.append(feats.cpu())
        all_probs.append(true_probs.cpu())

    return (
        torch.cat(all_rel_indices, dim=0),
        torch.cat(all_labels, dim=0),
        torch.cat(all_feats, dim=0),
        torch.cat(all_probs, dim=0),
    )


def split_budget_by_class(total_budget: int, classes: Sequence[int]) -> Dict[int, int]:
    classes = list(classes)
    if total_budget <= 0:
        return {c: 0 for c in classes}
    base = total_budget // len(classes)
    rem = total_budget % len(classes)
    out = {}
    for i, c in enumerate(classes):
        out[int(c)] = base + (1 if i < rem else 0)
    return out


def select_random_memory_indices(
    train_old_subset: Subset,
    budget: int,
    seed: int,
) -> List[int]:
    if budget <= 0:
        return []
    rng = random.Random(seed)
    budget = min(budget, len(train_old_subset))
    return rng.sample(range(len(train_old_subset)), budget)


def select_curated_memory_indices(
    model: SmallCNN,
    train_old_subset: Subset,
    old_digits: Sequence[int],
    budget: int,
    batch_size: int,
    device: str,
    seed: int,
    hard_fraction: float = 0.40,
) -> List[int]:
    """
    Model-chosen memory loop.

    Balanced per old digit. Within each digit, keep two kinds of examples:
      1. Representative prototypes: closest to that class's feature centroid.
      2. Hard boundary examples: lowest true-label confidence.

    This is a simple proxy for a system deciding what belongs in the memory loop:
    remember the central concept and the fragile edge cases.
    """
    if budget <= 0:
        return []

    budget = min(budget, len(train_old_subset))
    rel_indices, labels, feats, true_probs = collect_old_features(
        model=model,
        train_old_subset=train_old_subset,
        batch_size=batch_size,
        device=device,
    )

    rng = random.Random(seed)
    class_budgets = split_budget_by_class(budget, old_digits)
    selected: List[int] = []

    for digit in old_digits:
        digit = int(digit)
        k = class_budgets[digit]
        if k <= 0:
            continue

        mask = labels == digit
        class_rel = rel_indices[mask]
        class_feats = feats[mask]
        class_probs = true_probs[mask]

        if len(class_rel) <= k:
            selected.extend([int(i) for i in class_rel.tolist()])
            continue

        # Representative examples: close to centroid in feature space.
        centroid = class_feats.mean(dim=0, keepdim=True)
        dists = torch.sum((class_feats - centroid) ** 2, dim=1)

        n_hard = int(round(k * hard_fraction))
        n_rep = k - n_hard

        chosen_local = set()

        if n_rep > 0:
            rep_order = torch.argsort(dists, descending=False).tolist()
            for j in rep_order:
                if len(chosen_local) >= n_rep:
                    break
                chosen_local.add(int(j))

        if n_hard > 0:
            # Hard = lowest correct probability, excluding already selected reps.
            hard_order = torch.argsort(class_probs, descending=False).tolist()
            for j in hard_order:
                if len(chosen_local) >= k:
                    break
                chosen_local.add(int(j))

        # If duplicates left us short, fill randomly from remaining class members.
        if len(chosen_local) < k:
            remaining = [j for j in range(len(class_rel)) if j not in chosen_local]
            rng.shuffle(remaining)
            for j in remaining:
                if len(chosen_local) >= k:
                    break
                chosen_local.add(int(j))

        selected.extend([int(class_rel[j].item()) for j in chosen_local])

    if len(selected) > budget:
        rng.shuffle(selected)
        selected = selected[:budget]

    return selected


# -----------------------------
# Replay loader construction
# -----------------------------


def replay_budget_from_fraction(n_new: int, replay_fraction: float, n_old: int) -> int:
    """
    replay_fraction means old replay / total phase-2 examples.
    Example: if replay_fraction=0.20, phase 2 is 80% new and 20% old.
    """
    if replay_fraction <= 0:
        return 0
    if replay_fraction >= 1:
        raise ValueError('replay_fraction must be < 1.0')
    budget = int((replay_fraction / (1.0 - replay_fraction)) * n_new)
    return min(max(1, budget), n_old)


def make_phase2_loader(
    train_new_subset: Subset,
    train_old_subset: Subset,
    memory_indices: Sequence[int],
    batch_size: int,
    seed: int,
) -> DataLoader:
    new_marked = MarkedDataset(train_new_subset, source_flag=0)

    if len(memory_indices) > 0:
        replay_subset = Subset(train_old_subset, list(memory_indices))
        replay_marked = MarkedDataset(replay_subset, source_flag=1)
        dataset = ConcatDataset([new_marked, replay_marked])
    else:
        dataset = new_marked

    generator = torch.Generator()
    generator.manual_seed(seed)
    return DataLoader(dataset, batch_size=batch_size, shuffle=True, generator=generator)


# -----------------------------
# Phase 2 special losses
# -----------------------------


def normalized_anchor_loss(
    model: SmallCNN,
    anchor_state: Dict[str, torch.Tensor],
    device: str,
) -> torch.Tensor:
    """
    L2 anchor to the phase-1 solution.
    Normalized per tensor so the coefficient is easier to tune.
    """
    loss = torch.tensor(0.0, device=device)
    for name, param in model.named_parameters():
        old = anchor_state[name].to(device)
        loss = loss + torch.mean((param - old) ** 2)
    return loss


def distillation_loss(
    student_logits: torch.Tensor,
    teacher_logits: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    T = temperature
    student_log_probs = F.log_softmax(student_logits / T, dim=1)
    teacher_probs = F.softmax(teacher_logits / T, dim=1)
    return F.kl_div(student_log_probs, teacher_probs, reduction='batchmean') * (T * T)


# -----------------------------
# Phase 2 training
# -----------------------------


def train_phase2(
    model: SmallCNN,
    teacher: Optional[SmallCNN],
    phase2_loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: str,
    epochs: int,
    strategy: Strategy,
    anchor_state: Optional[Dict[str, torch.Tensor]],
    test_old_loader: DataLoader,
    quiet: bool,
) -> None:
    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0
        total_ce = 0.0
        total_anchor = 0.0
        total_distill = 0.0
        total_seen = 0

        for x, y, source in phase2_loader:
            x = x.to(device)
            y = y.to(device)
            source = source.to(device)

            optimizer.zero_grad(set_to_none=True)
            logits = model(x)
            ce = F.cross_entropy(logits, y)
            loss = ce

            anchor = torch.tensor(0.0, device=device)
            if strategy.anchor_lambda > 0 and anchor_state is not None:
                anchor = normalized_anchor_loss(model, anchor_state, device)
                loss = loss + strategy.anchor_lambda * anchor

            distill = torch.tensor(0.0, device=device)
            if strategy.distill_lambda > 0 and teacher is not None:
                replay_mask = source == 1
                if int(replay_mask.sum().item()) > 0:
                    with torch.no_grad():
                        teacher_logits = teacher(x[replay_mask])
                    student_logits = logits[replay_mask]
                    distill = distillation_loss(student_logits, teacher_logits, strategy.temperature)
                    loss = loss + strategy.distill_lambda * distill

            loss.backward()
            optimizer.step()

            n = x.size(0)
            total_loss += float(loss.item()) * n
            total_ce += float(ce.item()) * n
            total_anchor += float(anchor.item()) * n
            total_distill += float(distill.item()) * n
            total_seen += n

        if not quiet:
            old_acc = accuracy(model, test_old_loader, device)
            print(
                f"Phase 2 epoch {epoch:02d} "
                f"| loss {total_loss / max(1, total_seen):.4f} "
                f"| ce {total_ce / max(1, total_seen):.4f} "
                f"| anchor {total_anchor / max(1, total_seen):.6f} "
                f"| distill {total_distill / max(1, total_seen):.4f} "
                f"| old_acc {old_acc:.4f}"
            )


# -----------------------------
# Experiment runner
# -----------------------------


def run_strategy_from_same_phase1(
    strategy: Strategy,
    replay_fraction: float,
    seed: int,
    phase1_state: Dict[str, torch.Tensor],
    train_old_subset: Subset,
    train_new_subset: Subset,
    old_digits: Sequence[int],
    test_old_loader: DataLoader,
    test_new_loader: DataLoader,
    test_all_loader: DataLoader,
    batch_size: int,
    phase2_epochs: int,
    base_lr: float,
    device: str,
    quiet: bool,
) -> Dict[str, object]:
    n_new = len(train_new_subset)
    budget = replay_budget_from_fraction(n_new, replay_fraction, len(train_old_subset))

    # Every phase-2 condition starts from the exact same phase-1 state.
    model = SmallCNN().to(device)
    model.load_state_dict(copy.deepcopy(phase1_state))

    teacher = None
    if strategy.distill_lambda > 0:
        teacher = SmallCNN().to(device)
        teacher.load_state_dict(copy.deepcopy(phase1_state))
        teacher.eval()
        for p in teacher.parameters():
            p.requires_grad_(False)

    if strategy.memory_mode == 'none' or replay_fraction <= 0:
        memory_indices: List[int] = []
    elif strategy.memory_mode == 'random':
        memory_indices = select_random_memory_indices(
            train_old_subset=train_old_subset,
            budget=budget,
            seed=seed + 1000,
        )
    elif strategy.memory_mode == 'curated':
        memory_indices = select_curated_memory_indices(
            model=model,
            train_old_subset=train_old_subset,
            old_digits=old_digits,
            budget=budget,
            batch_size=batch_size,
            device=device,
            seed=seed + 2000,
        )
    else:
        raise ValueError(f'Unknown memory_mode: {strategy.memory_mode}')

    phase2_loader = make_phase2_loader(
        train_new_subset=train_new_subset,
        train_old_subset=train_old_subset,
        memory_indices=memory_indices,
        batch_size=batch_size,
        seed=seed + 3000,
    )

    optimizer = make_optimizer(
        model=model,
        base_lr=base_lr,
        soft_consolidation=strategy.soft_consolidation,
    )

    if not quiet:
        print('=' * 110)
        print(f"{strategy.name} | replay={pct(replay_fraction)} | budget={len(memory_indices)}")
        print('=' * 110)

    old_before = accuracy(model, test_old_loader, device)
    new_before = accuracy(model, test_new_loader, device)
    all_before = accuracy(model, test_all_loader, device)

    train_phase2(
        model=model,
        teacher=teacher,
        phase2_loader=phase2_loader,
        optimizer=optimizer,
        device=device,
        epochs=phase2_epochs,
        strategy=strategy,
        anchor_state=phase1_state,
        test_old_loader=test_old_loader,
        quiet=quiet,
    )

    old_after = accuracy(model, test_old_loader, device)
    new_after = accuracy(model, test_new_loader, device)
    all_after = accuracy(model, test_all_loader, device)
    forgetting = old_before - old_after

    # Useful but simple score: value final global performance and punish forgetting.
    score = all_after - forgetting

    if not quiet:
        print(
            f"Result | Old P2={old_after:.4f} | New P2={new_after:.4f} | "
            f"All P2={all_after:.4f} | Forget={forgetting:.4f} | Score={score:.4f}"
        )
        print()

    return {
        'seed': seed,
        'strategy': strategy.name,
        'replay_fraction': replay_fraction,
        'memory_mode': strategy.memory_mode,
        'memory_budget': len(memory_indices),
        'soft_consolidation': strategy.soft_consolidation,
        'anchor_lambda': strategy.anchor_lambda,
        'distill_lambda': strategy.distill_lambda,
        'old_acc_phase1': old_before,
        'new_acc_phase1': new_before,
        'all_acc_phase1': all_before,
        'old_acc_phase2': old_after,
        'new_acc_phase2': new_after,
        'all_acc_phase2': all_after,
        'forgetting': forgetting,
        'score': score,
    }


def summarize(results: List[Dict[str, object]]) -> None:
    print('\nFINAL RESULTS')
    print('=' * 170)
    header = (
        f"{'Seed':>5s} "
        f"{'Replay':>8s} "
        f"{'Strategy':58s} "
        f"{'Budget':>7s} "
        f"{'Old P1':>8s} "
        f"{'New P1':>8s} "
        f"{'All P1':>8s} "
        f"{'Old P2':>8s} "
        f"{'New P2':>8s} "
        f"{'All P2':>8s} "
        f"{'Forget':>8s} "
        f"{'Score':>8s}"
    )
    print(header)
    print('-' * 170)

    rows = sorted(results, key=lambda r: (int(r['seed']), float(r['replay_fraction']), str(r['strategy'])))
    for r in rows:
        print(
            f"{int(r['seed']):5d} "
            f"{pct(float(r['replay_fraction'])):>8s} "
            f"{str(r['strategy']):58s} "
            f"{int(r['memory_budget']):7d} "
            f"{fmt(float(r['old_acc_phase1'])):>8s} "
            f"{fmt(float(r['new_acc_phase1'])):>8s} "
            f"{fmt(float(r['all_acc_phase1'])):>8s} "
            f"{fmt(float(r['old_acc_phase2'])):>8s} "
            f"{fmt(float(r['new_acc_phase2'])):>8s} "
            f"{fmt(float(r['all_acc_phase2'])):>8s} "
            f"{fmt(float(r['forgetting'])):>8s} "
            f"{fmt(float(r['score'])):>8s}"
        )

    print('\nBEST BY REPLAY FRACTION')
    print('=' * 170)
    seeds = sorted(set(int(r['seed']) for r in results))
    replay_vals = sorted(set(float(r['replay_fraction']) for r in results))

    for replay in replay_vals:
        subset = [r for r in results if float(r['replay_fraction']) == replay]
        # If multiple seeds, average each strategy.
        by_strategy: Dict[str, List[Dict[str, object]]] = {}
        for r in subset:
            by_strategy.setdefault(str(r['strategy']), []).append(r)

        summaries = []
        for strat, rows in by_strategy.items():
            avg = lambda key: sum(float(x[key]) for x in rows) / len(rows)
            summaries.append({
                'strategy': strat,
                'n': len(rows),
                'old_p2': avg('old_acc_phase2'),
                'new_p2': avg('new_acc_phase2'),
                'all_p2': avg('all_acc_phase2'),
                'forget': avg('forgetting'),
                'score': avg('score'),
            })
        summaries.sort(key=lambda x: (x['score'], x['all_p2'], -x['forget']), reverse=True)
        best = summaries[0]
        print(
            f"Replay {pct(replay)} | best avg over {best['n']} seed(s): "
            f"{best['strategy']} | Old P2={best['old_p2']:.4f} | "
            f"New P2={best['new_p2']:.4f} | All P2={best['all_p2']:.4f} | "
            f"Forget={best['forget']:.4f} | Score={best['score']:.4f}"
        )


def save_csv(results: List[Dict[str, object]], path: str) -> None:
    if not results:
        return
    fieldnames = list(results[0].keys())
    with open(path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', type=str, default='./data')
    parser.add_argument('--batch-size', type=int, default=128)
    parser.add_argument('--phase1-epochs', type=int, default=3)
    parser.add_argument('--phase2-epochs', type=int, default=3)
    parser.add_argument('--base-lr', type=float, default=1e-3)
    parser.add_argument('--held-out', type=str, default='3,6,9')
    parser.add_argument('--replay-fractions', type=str, default='0,0.02,0.05,0.10,0.20')
    parser.add_argument('--seeds', type=str, default='42')
    parser.add_argument('--csv', type=str, default='mnist_memory_loop_results.csv')
    parser.add_argument('--quiet', action='store_true')
    args = parser.parse_args()

    held_out_digits = parse_int_list(args.held_out)
    old_digits = [d for d in range(10) if d not in held_out_digits]
    replay_fractions = parse_float_list(args.replay_fractions)
    seeds = parse_int_list(args.seeds)

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Device:           {device}")
    print(f"Old digits:       {old_digits}")
    print(f"Held-out digits:  {held_out_digits}")
    print(f"Replay fractions: {replay_fractions}")
    print(f"Seeds:            {seeds}")
    print(f"CNN architecture: identical for every strategy")
    print()

    loaders = make_loaders(
        data_dir=args.data_dir,
        batch_size=args.batch_size,
        old_digits=old_digits,
        held_out_digits=held_out_digits,
    )
    (
        train_old_loader,
        _train_new_loader,
        test_old_loader,
        test_new_loader,
        test_all_loader,
        train_old_subset,
        train_new_subset,
    ) = loaders

    results: List[Dict[str, object]] = []

    for seed in seeds:
        print('\n' + '#' * 110)
        print(f"PHASE 1: train one conventional CNN on old digits only | seed={seed}")
        print('#' * 110)
        set_seed(seed)
        phase1_model = SmallCNN().to(device)
        phase1_optimizer = make_optimizer(
            model=phase1_model,
            base_lr=args.base_lr,
            soft_consolidation=False,
        )
        train_phase1(
            model=phase1_model,
            loader=train_old_loader,
            optimizer=phase1_optimizer,
            device=device,
            old_digits=old_digits,
            epochs=args.phase1_epochs,
            test_old_loader=test_old_loader,
            quiet=args.quiet,
        )

        phase1_old = accuracy(phase1_model, test_old_loader, device)
        phase1_new = accuracy(phase1_model, test_new_loader, device)
        phase1_all = accuracy(phase1_model, test_all_loader, device)
        print(f"Phase 1 saved state | old={phase1_old:.4f} | new={phase1_new:.4f} | all={phase1_all:.4f}")

        phase1_state = copy.deepcopy(phase1_model.state_dict())

        for replay_fraction in replay_fractions:
            for strategy in STRATEGIES:
                # No-replay condition is identical regardless of replay_fraction.
                # Still keep it in the table at each fraction for easy comparison.
                result = run_strategy_from_same_phase1(
                    strategy=strategy,
                    replay_fraction=replay_fraction,
                    seed=seed,
                    phase1_state=phase1_state,
                    train_old_subset=train_old_subset,
                    train_new_subset=train_new_subset,
                    old_digits=old_digits,
                    test_old_loader=test_old_loader,
                    test_new_loader=test_new_loader,
                    test_all_loader=test_all_loader,
                    batch_size=args.batch_size,
                    phase2_epochs=args.phase2_epochs,
                    base_lr=args.base_lr,
                    device=device,
                    quiet=args.quiet,
                )
                results.append(result)

    summarize(results)
    save_csv(results, args.csv)
    print(f"\nSaved results to: {args.csv}")


if __name__ == '__main__':
    main()

```


---

## requirements.txt

```
torch

```


---

## run_cli_demo.bat

```bat
@echo off
cd /d "%~dp0"
python micro_lifelong_llm.py --corpus-dir corpus --steps-per-phase 300 --memory-per-phase 300 --generate-every-phase --prompt "Memory is"
pause

```


---

## run_gui.bat

```bat
@echo off
cd /d "%~dp0"
python lifelong_gui.py
pause

```


---

## symbols_density_distill_sweep.py

```python
# symbols_density_distill_sweep.py
#
# Combined digits + alphabet continual-learning experiment.
#
# Dataset:
#   MNIST digits 0-9 + EMNIST Letters A-Z = 36 classes.
#
# Purpose:
#   Follow-up after the surprising combined-symbol result where class-balanced
#   random replay beat strong distillation at very tiny replay budgets.
#
# This script asks:
#   1) Was distillation simply too strong for sparse replay buffers?
#   2) Does weak/medium distillation start helping once memory density improves?
#   3) Can pure-diverse or boundary-diverse replay beat class-balanced random
#      under a fair, fixed architecture?
#
# Run:
#   python symbols_density_distill_sweep.py
#
# Faster smoke test:
#   python symbols_density_distill_sweep.py --phase1-epochs 1 --phase2-epochs 1 --seeds 42 --replay-fractions 0,0.01 --max-train-per-class 1000 --max-test-per-class 500
#
# Longer confirmatory run:
#   python symbols_density_distill_sweep.py --seeds 42,43,44 --replay-fractions 0,0.005,0.01,0.02,0.05,0.10,0.20,0.35 --phase1-epochs 3 --phase2-epochs 3

import argparse
import csv
import math
import random
import hashlib
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import ConcatDataset, DataLoader, Dataset, Subset
from torchvision import datasets, transforms
from torchvision.transforms import functional as TF


# -----------------------------
# Symbol map
# -----------------------------

DIGIT_NAMES = [str(i) for i in range(10)]
LETTER_NAMES = [chr(ord("A") + i) for i in range(26)]
CLASS_NAMES = DIGIT_NAMES + LETTER_NAMES
N_CLASSES = 36

DEFAULT_HELD_OUT = ["3", "6", "9", "C", "F", "J", "Q", "V", "X", "Y", "Z"]


def symbol_to_class_id(symbol: str) -> int:
    symbol = symbol.strip().upper()
    if symbol.isdigit():
        n = int(symbol)
        if 0 <= n <= 9:
            return n
    if len(symbol) == 1 and "A" <= symbol <= "Z":
        return 10 + ord(symbol) - ord("A")
    raise ValueError(f"Unknown symbol: {symbol}")


def class_id_to_symbol(cid: int) -> str:
    return CLASS_NAMES[cid]


def parse_symbols(text: str) -> List[int]:
    return [symbol_to_class_id(x) for x in text.split(",") if x.strip()]


def symbols_string(class_ids: Sequence[int]) -> str:
    return ",".join(class_id_to_symbol(i) for i in class_ids)


# -----------------------------
# Utilities
# -----------------------------


def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def stable_hash_int(text: str) -> int:
    # Python's built-in hash is intentionally randomized between processes.
    # Use this for reproducible condition seeds.
    return int(hashlib.md5(text.encode("utf-8")).hexdigest()[:8], 16)


def parse_float_list(text: str) -> List[float]:
    vals = []
    for part in text.split(","):
        part = part.strip()
        if not part:
            continue
        val = float(part)
        if val < 0.0 or val >= 1.0:
            raise ValueError("Replay fractions must be >= 0 and < 1")
        vals.append(val)
    return vals


def parse_int_list(text: str) -> List[int]:
    return [int(x.strip()) for x in text.split(",") if x.strip()]


def pct(x: float) -> str:
    return f"{100.0 * x:5.2f}%"


def harmonic_mean(a: float, b: float) -> float:
    if a <= 0 or b <= 0:
        return 0.0
    return 2.0 * a * b / (a + b)


# -----------------------------
# Dataset wrappers
# -----------------------------


class LabelOffsetDataset(Dataset):
    """Wrap a dataset and remap labels."""

    def __init__(self, dataset: Dataset, label_fn, name: str):
        self.dataset = dataset
        self.label_fn = label_fn
        self.name = name

        # Build labels once so we can filter quickly.
        labels = []
        for i in range(len(dataset)):
            _x, y = dataset[i]
            labels.append(int(label_fn(int(y))))
        self.targets = torch.tensor(labels, dtype=torch.long)

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int):
        x, y = self.dataset[idx]
        return x, int(self.label_fn(int(y)))


class CombinedLabeledDataset(Dataset):
    """Concat-like dataset with a unified targets vector."""

    def __init__(self, datasets_: Sequence[Dataset]):
        self.datasets = list(datasets_)
        self.cumulative_sizes = []
        total = 0
        targets = []
        for ds in self.datasets:
            total += len(ds)
            self.cumulative_sizes.append(total)
            if hasattr(ds, "targets"):
                targets.extend([int(x) for x in ds.targets])
            else:
                for i in range(len(ds)):
                    _x, y = ds[i]
                    targets.append(int(y))
        self.targets = torch.tensor(targets, dtype=torch.long)

    def __len__(self) -> int:
        return self.cumulative_sizes[-1] if self.cumulative_sizes else 0

    def __getitem__(self, idx: int):
        if idx < 0:
            idx += len(self)
        ds_idx = 0
        while idx >= self.cumulative_sizes[ds_idx]:
            ds_idx += 1
        prev = 0 if ds_idx == 0 else self.cumulative_sizes[ds_idx - 1]
        return self.datasets[ds_idx][idx - prev]


class FlaggedDataset(Dataset):
    """Wraps a dataset and returns x, y, is_old_replay."""

    def __init__(self, dataset: Dataset, is_old_replay: int):
        self.dataset = dataset
        self.is_old_replay = int(is_old_replay)

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int):
        x, y = self.dataset[idx]
        return x, int(y), self.is_old_replay


class NewPlusReplayDataset(Dataset):
    def __init__(self, new_subset: Dataset, replay_subset: Optional[Dataset]):
        parts: List[Dataset] = [FlaggedDataset(new_subset, 0)]
        if replay_subset is not None and len(replay_subset) > 0:
            parts.append(FlaggedDataset(replay_subset, 1))
        self.dataset = ConcatDataset(parts)

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int):
        return self.dataset[idx]


class FeatureSubset(Dataset):
    """Subset that also preserves a .targets vector."""

    def __init__(self, base: Dataset, indices: Sequence[int]):
        self.base = base
        self.indices = list(indices)
        if hasattr(base, "targets"):
            self.targets = torch.tensor([int(base.targets[i]) for i in self.indices], dtype=torch.long)
        else:
            labels = []
            for i in self.indices:
                _x, y = base[i]
                labels.append(int(y))
            self.targets = torch.tensor(labels, dtype=torch.long)

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, idx: int):
        return self.base[self.indices[idx]]


# -----------------------------
# Data creation
# -----------------------------


def emnist_orientation_fix(img):
    # EMNIST images are commonly stored rotated/transposed relative to MNIST.
    # This transform makes letters visually upright for standard display/training.
    return TF.hflip(TF.rotate(img, -90))


def make_combined_dataset(
    data_dir: str,
    train: bool,
    fix_emnist_orientation: bool = True,
) -> CombinedLabeledDataset:
    mnist_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])

    emnist_transforms = []
    if fix_emnist_orientation:
        emnist_transforms.append(transforms.Lambda(emnist_orientation_fix))
    emnist_transforms.extend([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])
    emnist_transform = transforms.Compose(emnist_transforms)

    mnist = datasets.MNIST(root=data_dir, train=train, download=True, transform=mnist_transform)
    # EMNIST Letters labels are 1..26. Map to 10..35.
    emnist_letters = datasets.EMNIST(
        root=data_dir,
        split="letters",
        train=train,
        download=True,
        transform=emnist_transform,
    )

    mnist_wrapped = LabelOffsetDataset(mnist, lambda y: y, "MNIST")
    emnist_wrapped = LabelOffsetDataset(emnist_letters, lambda y: 10 + (y - 1), "EMNIST-Letters")

    return CombinedLabeledDataset([mnist_wrapped, emnist_wrapped])


def class_filtered_indices(dataset: Dataset, allowed_classes: Sequence[int]) -> List[int]:
    allowed = set(int(c) for c in allowed_classes)
    labels = dataset.targets if hasattr(dataset, "targets") else None
    if labels is not None:
        return [i for i, y in enumerate(labels) if int(y) in allowed]
    out = []
    for i in range(len(dataset)):
        _x, y = dataset[i]
        if int(y) in allowed:
            out.append(i)
    return out


def cap_per_class_indices(
    dataset: Dataset,
    indices: Sequence[int],
    max_per_class: Optional[int],
    seed: int,
) -> List[int]:
    if max_per_class is None or max_per_class <= 0:
        return list(indices)

    rng = random.Random(seed)
    by_class: Dict[int, List[int]] = {}
    targets = dataset.targets
    for idx in indices:
        y = int(targets[idx])
        by_class.setdefault(y, []).append(int(idx))

    capped: List[int] = []
    for c, vals in sorted(by_class.items()):
        vals = list(vals)
        rng.shuffle(vals)
        capped.extend(vals[:max_per_class])
    rng.shuffle(capped)
    return capped


def make_data_splits(
    data_dir: str,
    old_classes: List[int],
    new_classes: List[int],
    batch_size: int,
    seed: int,
    max_train_per_class: Optional[int],
    max_test_per_class: Optional[int],
    fix_emnist_orientation: bool,
):
    train_full = make_combined_dataset(data_dir, train=True, fix_emnist_orientation=fix_emnist_orientation)
    test_full = make_combined_dataset(data_dir, train=False, fix_emnist_orientation=fix_emnist_orientation)

    train_old_indices = class_filtered_indices(train_full, old_classes)
    train_new_indices = class_filtered_indices(train_full, new_classes)
    test_old_indices = class_filtered_indices(test_full, old_classes)
    test_new_indices = class_filtered_indices(test_full, new_classes)

    train_old_indices = cap_per_class_indices(train_full, train_old_indices, max_train_per_class, seed + 1)
    train_new_indices = cap_per_class_indices(train_full, train_new_indices, max_train_per_class, seed + 2)
    test_old_indices = cap_per_class_indices(test_full, test_old_indices, max_test_per_class, seed + 3)
    test_new_indices = cap_per_class_indices(test_full, test_new_indices, max_test_per_class, seed + 4)

    train_old = FeatureSubset(train_full, train_old_indices)
    train_new = FeatureSubset(train_full, train_new_indices)
    test_old = FeatureSubset(test_full, test_old_indices)
    test_new = FeatureSubset(test_full, test_new_indices)

    train_old_loader = DataLoader(train_old, batch_size=batch_size, shuffle=True)
    test_old_loader = DataLoader(test_old, batch_size=batch_size, shuffle=False)
    test_new_loader = DataLoader(test_new, batch_size=batch_size, shuffle=False)
    test_all_loader = DataLoader(
        FeatureSubset(test_full, test_old_indices + test_new_indices),
        batch_size=batch_size,
        shuffle=False,
    )

    return {
        "train_full": train_full,
        "test_full": test_full,
        "train_old": train_old,
        "train_new": train_new,
        "test_old": test_old,
        "test_new": test_new,
        "train_old_loader": train_old_loader,
        "test_old_loader": test_old_loader,
        "test_new_loader": test_new_loader,
        "test_all_loader": test_all_loader,
    }


# -----------------------------
# Model
# -----------------------------


class SmallCNN36(nn.Module):
    def __init__(self, n_classes: int = N_CLASSES):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, n_classes)

    def features(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = torch.flatten(x, 1)
        x = F.relu(self.fc1(x))
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(self.features(x))


def make_optimizer(model: SmallCNN36, lr: float = 1e-3, soft: bool = False):
    if soft:
        return torch.optim.Adam([
            {"name": "conv1", "params": model.conv1.parameters(), "lr": lr * 0.25},
            {"name": "conv2", "params": model.conv2.parameters(), "lr": lr * 0.50},
            {"name": "fc1", "params": model.fc1.parameters(), "lr": lr},
            {"name": "fc2", "params": model.fc2.parameters(), "lr": lr},
        ])
    return torch.optim.Adam(model.parameters(), lr=lr)


# -----------------------------
# Evaluation / training
# -----------------------------


def mask_logits(logits: torch.Tensor, allowed_classes: Optional[Sequence[int]]) -> torch.Tensor:
    if allowed_classes is None:
        return logits
    out = torch.full_like(logits, -1e9)
    idx = torch.tensor(list(allowed_classes), dtype=torch.long, device=logits.device)
    out[:, idx] = logits[:, idx]
    return out


@torch.no_grad()
def accuracy(model: nn.Module, loader: DataLoader, device: str) -> float:
    model.eval()
    correct = 0
    total = 0
    for batch in loader:
        if len(batch) == 3:
            x, y, _flag = batch
        else:
            x, y = batch
        x = x.to(device)
        y = y.to(device)
        pred = model(x).argmax(dim=1)
        correct += int((pred == y).sum().item())
        total += int(y.numel())
    return correct / max(1, total)


def train_phase1(
    model: SmallCNN36,
    loader: DataLoader,
    optimizer,
    device: str,
    old_classes: Sequence[int],
    epochs: int,
    test_old_loader: DataLoader,
):
    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0
        total_seen = 0
        for x, y in loader:
            x = x.to(device)
            y = y.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = mask_logits(model(x), old_classes)
            loss = F.cross_entropy(logits, y)
            loss.backward()
            optimizer.step()
            total_loss += float(loss.item()) * x.size(0)
            total_seen += x.size(0)
        old_acc = accuracy(model, test_old_loader, device)
        print(f"Phase 1 epoch {epoch:02d} | loss {total_loss / max(1, total_seen):.4f} | old_acc {old_acc:.4f}")


def anchor_penalty(model: nn.Module, old_state: Dict[str, torch.Tensor]) -> torch.Tensor:
    total = None
    count = 0
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        old = old_state[name].to(p.device)
        val = (p - old).pow(2).mean()
        total = val if total is None else total + val
        count += 1
    if total is None:
        return torch.tensor(0.0, device=next(model.parameters()).device)
    return total / max(1, count)


def distill_loss_on_old_examples(
    student_logits: torch.Tensor,
    teacher_logits: torch.Tensor,
    old_classes_tensor: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    s = student_logits[:, old_classes_tensor] / temperature
    t = teacher_logits[:, old_classes_tensor] / temperature
    return F.kl_div(
        F.log_softmax(s, dim=1),
        F.softmax(t, dim=1),
        reduction="batchmean",
    ) * (temperature ** 2)


def train_phase2(
    model: SmallCNN36,
    teacher: SmallCNN36,
    loader: DataLoader,
    optimizer,
    device: str,
    epochs: int,
    old_state: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    use_anchor: bool,
    use_distill: bool,
    anchor_lambda: float,
    distill_lambda: float,
    temperature: float,
    test_old_loader: DataLoader,
    quiet: bool = False,
):
    teacher.eval()
    old_classes_tensor = torch.tensor(list(old_classes), dtype=torch.long, device=device)

    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = total_ce = total_anchor = total_distill = 0.0
        total_seen = 0

        for x, y, is_old in loader:
            x = x.to(device)
            y = y.to(device)
            is_old = is_old.to(device).bool()
            optimizer.zero_grad(set_to_none=True)

            logits = model(x)
            ce = F.cross_entropy(logits, y)

            a = torch.tensor(0.0, device=device)
            if use_anchor:
                a = anchor_penalty(model, old_state)

            d = torch.tensor(0.0, device=device)
            if use_distill and is_old.any():
                with torch.no_grad():
                    teacher_logits = teacher(x[is_old])
                d = distill_loss_on_old_examples(
                    logits[is_old],
                    teacher_logits,
                    old_classes_tensor,
                    temperature,
                )

            loss = ce + anchor_lambda * a + distill_lambda * d
            loss.backward()
            optimizer.step()

            n = x.size(0)
            total_loss += float(loss.item()) * n
            total_ce += float(ce.item()) * n
            total_anchor += float(a.item()) * n
            total_distill += float(d.item()) * n
            total_seen += n

        old_acc = accuracy(model, test_old_loader, device)
        if not quiet:
            print(
                f"Phase 2 epoch {epoch:02d} | "
                f"loss {total_loss / max(1, total_seen):.4f} | "
                f"ce {total_ce / max(1, total_seen):.4f} | "
                f"anchor {total_anchor / max(1, total_seen):.6f} | "
                f"distill {total_distill / max(1, total_seen):.4f} | "
                f"old_acc {old_acc:.4f}"
            )


# -----------------------------
# Memory selection
# -----------------------------


@torch.no_grad()
def collect_old_model_stats(
    model: SmallCNN36,
    train_old: Dataset,
    old_classes: Sequence[int],
    batch_size: int,
    device: str,
) -> Dict[str, torch.Tensor]:
    loader = DataLoader(train_old, batch_size=batch_size, shuffle=False)
    model.eval()

    all_features = []
    all_logits = []
    all_labels = []

    for x, y in loader:
        x = x.to(device)
        feats = model.features(x)
        logits = model.fc2(feats)
        all_features.append(feats.cpu())
        all_logits.append(logits.cpu())
        all_labels.append(torch.tensor(y, dtype=torch.long))

    features = torch.cat(all_features, dim=0)
    logits = torch.cat(all_logits, dim=0)
    labels = torch.cat(all_labels, dim=0)

    old_idx = torch.tensor(list(old_classes), dtype=torch.long)
    old_logits = logits[:, old_idx]
    probs = F.softmax(old_logits, dim=1)
    top2 = torch.topk(probs, k=min(2, probs.size(1)), dim=1).values
    if top2.size(1) == 1:
        margin = torch.ones(top2.size(0))
    else:
        margin = top2[:, 0] - top2[:, 1]
    confidence = top2[:, 0]
    entropy = -(probs * (probs.clamp_min(1e-12).log())).sum(dim=1)

    centers: Dict[int, torch.Tensor] = {}
    distances = torch.zeros(len(train_old))
    for c in old_classes:
        mask = labels == int(c)
        if mask.any():
            center = features[mask].mean(dim=0)
            centers[int(c)] = center
            distances[mask] = torch.norm(features[mask] - center, dim=1)

    return {
        "features": features,
        "labels": labels,
        "logits": logits,
        "margin": margin,
        "confidence": confidence,
        "entropy": entropy,
        "distance": distances,
    }


def budget_from_fraction(n_new: int, replay_fraction: float) -> int:
    if replay_fraction <= 0:
        return 0
    return int((replay_fraction / (1.0 - replay_fraction)) * n_new)


def allocate_budget_by_class(labels: torch.Tensor, old_classes: Sequence[int], budget: int) -> Dict[int, int]:
    if budget <= 0:
        return {int(c): 0 for c in old_classes}
    present = [int(c) for c in old_classes if int((labels == int(c)).sum().item()) > 0]
    if not present:
        return {}
    base = budget // len(present)
    rem = budget % len(present)
    alloc = {}
    for i, c in enumerate(present):
        alloc[c] = base + (1 if i < rem else 0)
    return alloc


def balanced_random_indices(labels: torch.Tensor, old_classes: Sequence[int], budget: int, seed: int) -> List[int]:
    rng = random.Random(seed)
    alloc = allocate_budget_by_class(labels, old_classes, budget)
    selected: List[int] = []
    for c, k in alloc.items():
        idx = torch.where(labels == c)[0].tolist()
        rng.shuffle(idx)
        selected.extend(idx[:min(k, len(idx))])
    rng.shuffle(selected)
    return selected


def sorted_take_evenly(indices: List[int], scores: torch.Tensor, k: int, reverse: bool = False) -> List[int]:
    if k <= 0 or not indices:
        return []
    if len(indices) <= k:
        return list(indices)
    idx_sorted = sorted(indices, key=lambda i: float(scores[i]), reverse=reverse)
    if k == 1:
        return [idx_sorted[len(idx_sorted) // 2]]
    picks = []
    for j in range(k):
        pos = round(j * (len(idx_sorted) - 1) / (k - 1))
        picks.append(idx_sorted[pos])
    return picks


def boundary_diverse_indices(
    stats: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    budget: int,
    seed: int,
    boundary_frac: float = 0.50,
    diverse_frac: float = 0.35,
    prototype_frac: float = 0.15,
) -> List[int]:
    """
    Stress-test selector.

    Per class, select a mix of:
      - low-margin examples: decision-boundary memories
      - diverse examples: evenly spread by embedding distance from class center
      - prototype examples: near class centers

    This is deliberately stronger than the earlier naive curated replay.
    """
    rng = random.Random(seed)
    labels = stats["labels"]
    margin = stats["margin"]
    distance = stats["distance"]
    alloc = allocate_budget_by_class(labels, old_classes, budget)
    selected: List[int] = []

    for c, k in alloc.items():
        if k <= 0:
            continue
        class_idx = torch.where(labels == c)[0].tolist()
        if len(class_idx) <= k:
            selected.extend(class_idx)
            continue

        rng.shuffle(class_idx)
        n_boundary = int(round(k * boundary_frac))
        n_diverse = int(round(k * diverse_frac))
        n_proto = k - n_boundary - n_diverse
        if n_proto < 0:
            n_proto = 0

        # 1) Low margin = ambiguous/boundary examples.
        boundary = sorted(class_idx, key=lambda i: float(margin[i]))[:n_boundary]
        used = set(boundary)
        remaining = [i for i in class_idx if i not in used]

        # 2) Diversity by selecting evenly across center-distance spectrum.
        diverse = sorted_take_evenly(remaining, distance, n_diverse, reverse=False)
        used.update(diverse)
        remaining = [i for i in remaining if i not in used]

        # 3) Prototypes near class center.
        proto = sorted(remaining, key=lambda i: float(distance[i]))[:n_proto]

        picked = boundary + diverse + proto
        if len(picked) < k:
            rest = [i for i in class_idx if i not in set(picked)]
            rng.shuffle(rest)
            picked.extend(rest[: k - len(picked)])
        selected.extend(picked[:k])

    rng.shuffle(selected)
    return selected


def pure_diverse_indices(
    stats: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    budget: int,
    seed: int,
) -> List[int]:
    labels = stats["labels"]
    distance = stats["distance"]
    alloc = allocate_budget_by_class(labels, old_classes, budget)
    rng = random.Random(seed)
    selected: List[int] = []
    for c, k in alloc.items():
        idx = torch.where(labels == c)[0].tolist()
        rng.shuffle(idx)
        selected.extend(sorted_take_evenly(idx, distance, k, reverse=False))
    rng.shuffle(selected)
    return selected


def make_replay_subset(
    train_old: Dataset,
    stats: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    budget: int,
    selector: str,
    seed: int,
) -> Optional[Dataset]:
    if budget <= 0 or selector == "none":
        return None
    labels = stats["labels"] if stats is not None else train_old.targets

    if selector == "random":
        idx = balanced_random_indices(labels, old_classes, budget, seed)
    elif selector == "diverse":
        idx = pure_diverse_indices(stats, old_classes, budget, seed)
    elif selector == "boundary_diverse":
        idx = boundary_diverse_indices(stats, old_classes, budget, seed)
    else:
        raise ValueError(f"Unknown selector: {selector}")

    return FeatureSubset(train_old, idx)


# -----------------------------
# Strategies
# -----------------------------


@dataclass
class Strategy:
    name: str
    selector: str
    use_anchor: bool = False
    use_distill: bool = False
    soft: bool = False
    distill_lambda: float = 0.0
    anchor_lambda: float = 0.0


# Lean diagnostic set.
#
# Distillation is deliberately swept from weak to strong.
# The prior combined-symbol run used strong distillation and it often hurt
# at 0.5-2% replay. This run tests whether lower distillation weights recover
# the MNIST/EMNIST benefit.
STRATEGIES = [
    Strategy("No replay", "none"),

    # Strong fair baselines.
    Strategy("Balanced random replay", "random"),
    Strategy("Pure diverse replay", "diverse"),
    Strategy("Boundary-diverse replay", "boundary_diverse"),

    # Distillation-strength sweep for the current leading baseline.
    Strategy("Balanced random + distill 0.05", "random", use_distill=True, distill_lambda=0.05),
    Strategy("Balanced random + distill 0.15", "random", use_distill=True, distill_lambda=0.15),
    Strategy("Balanced random + distill 0.35", "random", use_distill=True, distill_lambda=0.35),
    Strategy("Balanced random + distill 0.70", "random", use_distill=True, distill_lambda=0.70),

    # Does diversity help when paired with a gentler old-self constraint?
    Strategy("Pure diverse + distill 0.15", "diverse", use_distill=True, distill_lambda=0.15),
    Strategy("Boundary-diverse + distill 0.15", "boundary_diverse", use_distill=True, distill_lambda=0.15),
    Strategy("Boundary-diverse + distill 0.35", "boundary_diverse", use_distill=True, distill_lambda=0.35),

    # Does soft consolidation rescue distillation in the sparse regime?
    Strategy("Boundary-diverse + soft + distill 0.15", "boundary_diverse", use_distill=True, soft=True, distill_lambda=0.15),

    # A weak anchor/distill version, much less rigid than the earlier strong anchor/distill.
    Strategy("Boundary-diverse + soft + anchor/distill 0.15", "boundary_diverse", use_anchor=True, use_distill=True, soft=True, distill_lambda=0.15, anchor_lambda=1.0),
]


def select_strategies(names_text: Optional[str]) -> List[Strategy]:
    if not names_text:
        return STRATEGIES
    wanted = {x.strip().lower() for x in names_text.split(",") if x.strip()}
    out = [s for s in STRATEGIES if s.name.lower() in wanted]
    if not out:
        raise ValueError("No strategies matched --strategies. Use exact strategy names, comma-separated.")
    return out


# -----------------------------
# Experiment
# -----------------------------


def run_one_condition(
    strategy: Strategy,
    replay_fraction: float,
    seed: int,
    data,
    old_classes: Sequence[int],
    new_classes: Sequence[int],
    phase1_state: Dict[str, torch.Tensor],
    old_state_cpu: Dict[str, torch.Tensor],
    stats,
    old_acc_phase1: float,
    new_acc_phase1: float,
    all_acc_phase1: float,
    args,
    device: str,
) -> Dict[str, object]:
    condition_seed = seed + int(replay_fraction * 1_000_000) + stable_hash_int(strategy.name) % 100_000
    set_seed(condition_seed)

    model = SmallCNN36().to(device)
    model.load_state_dict(phase1_state)

    teacher = SmallCNN36().to(device)
    teacher.load_state_dict(phase1_state)
    teacher.eval()
    for p in teacher.parameters():
        p.requires_grad = False

    budget = budget_from_fraction(len(data["train_new"]), replay_fraction)
    replay_subset = make_replay_subset(
        train_old=data["train_old"],
        stats=stats,
        old_classes=old_classes,
        budget=budget,
        selector=strategy.selector,
        seed=condition_seed + 17,
    )

    phase2_dataset = NewPlusReplayDataset(data["train_new"], replay_subset)
    generator = torch.Generator()
    generator.manual_seed(condition_seed + 23)
    phase2_loader = DataLoader(
        phase2_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        generator=generator,
    )

    optimizer = make_optimizer(model, lr=args.lr, soft=strategy.soft)

    if not args.quiet:
        print("=" * 148)
        print(f"Seed={seed} | Replay={pct(replay_fraction)} | {strategy.name} | budget={budget} | d={strategy.distill_lambda:.2f} | a={strategy.anchor_lambda:.2f}")
        print("=" * 148)

    train_phase2(
        model=model,
        teacher=teacher,
        loader=phase2_loader,
        optimizer=optimizer,
        device=device,
        epochs=args.phase2_epochs,
        old_state=old_state_cpu,
        old_classes=old_classes,
        use_anchor=strategy.use_anchor,
        use_distill=strategy.use_distill,
        anchor_lambda=(strategy.anchor_lambda if strategy.use_anchor else 0.0),
        distill_lambda=(strategy.distill_lambda if strategy.use_distill else 0.0),
        temperature=args.temperature,
        test_old_loader=data["test_old_loader"],
        quiet=args.quiet,
    )

    old_acc_phase2 = accuracy(model, data["test_old_loader"], device)
    new_acc_phase2 = accuracy(model, data["test_new_loader"], device)
    all_acc_phase2 = accuracy(model, data["test_all_loader"], device)
    forgetting = old_acc_phase1 - old_acc_phase2
    h = harmonic_mean(old_acc_phase2, new_acc_phase2)
    stability_score = all_acc_phase2 - forgetting

    result = {
        "seed": seed,
        "strategy": strategy.name,
        "selector": strategy.selector,
        "use_anchor": strategy.use_anchor,
        "use_distill": strategy.use_distill,
        "soft": strategy.soft,
        "distill_lambda": strategy.distill_lambda if strategy.use_distill else 0.0,
        "anchor_lambda": strategy.anchor_lambda if strategy.use_anchor else 0.0,
        "replay_fraction": replay_fraction,
        "budget": budget,
        "old_acc_phase1": old_acc_phase1,
        "new_acc_phase1": new_acc_phase1,
        "all_acc_phase1": all_acc_phase1,
        "old_acc_phase2": old_acc_phase2,
        "new_acc_phase2": new_acc_phase2,
        "all_acc_phase2": all_acc_phase2,
        "forgetting": forgetting,
        "harmonic_old_new": h,
        "stability_score": stability_score,
    }

    if not args.quiet:
        print(
            f"Result | Old P2={old_acc_phase2:.4f} | New P2={new_acc_phase2:.4f} | "
            f"All P2={all_acc_phase2:.4f} | Forget={forgetting:.4f} | "
            f"Score={stability_score:.4f} | H(old,new)={h:.4f}\n"
        )

    return result


def aggregate_results(results: List[Dict[str, object]]) -> List[Dict[str, object]]:
    keys = sorted(set((r["replay_fraction"], r["strategy"]) for r in results))
    out = []
    metrics = [
        "old_acc_phase2",
        "new_acc_phase2",
        "all_acc_phase2",
        "forgetting",
        "harmonic_old_new",
        "stability_score",
    ]
    for frac, strategy in keys:
        rows = [r for r in results if r["replay_fraction"] == frac and r["strategy"] == strategy]
        rec = {"replay_fraction": frac, "strategy": strategy, "n": len(rows)}
        for m in metrics:
            vals = [float(r[m]) for r in rows]
            mean = sum(vals) / len(vals)
            if len(vals) > 1:
                var = sum((x - mean) ** 2 for x in vals) / (len(vals) - 1)
                sd = math.sqrt(var)
            else:
                sd = 0.0
            rec[m + "_mean"] = mean
            rec[m + "_sd"] = sd
        out.append(rec)
    return out


def print_summary(results: List[Dict[str, object]]) -> None:
    agg = aggregate_results(results)

    print("\n\nFINAL AGGREGATE TABLE")
    print("=" * 170)
    print(
        f"{'Replay':>8s} {'Strategy':48s} {'Old P2':>9s} {'New P2':>9s} "
        f"{'All P2':>9s} {'Forget':>9s} {'H':>9s} {'Score':>9s} {'n':>4s}"
    )
    print("-" * 170)
    for r in sorted(agg, key=lambda x: (float(x["replay_fraction"]), str(x["strategy"]))):
        print(
            f"{pct(float(r['replay_fraction'])):>8s} "
            f"{str(r['strategy']):48s} "
            f"{float(r['old_acc_phase2_mean']):9.4f} "
            f"{float(r['new_acc_phase2_mean']):9.4f} "
            f"{float(r['all_acc_phase2_mean']):9.4f} "
            f"{float(r['forgetting_mean']):9.4f} "
            f"{float(r['harmonic_old_new_mean']):9.4f} "
            f"{float(r['stability_score_mean']):9.4f} "
            f"{int(r['n']):4d}"
        )

    print("\n\nBEST BY REPLAY FRACTION")
    print("=" * 170)
    print("Sorted by harmonic mean of old/new accuracy, then stability_score.")
    for frac in sorted(set(float(r["replay_fraction"]) for r in results)):
        rows = [r for r in agg if float(r["replay_fraction"]) == frac]
        rows = sorted(rows, key=lambda x: (float(x["harmonic_old_new_mean"]), float(x["stability_score_mean"])), reverse=True)
        b = rows[0]
        print(
            f"Replay {pct(frac)} | best: {b['strategy']} | "
            f"Old={float(b['old_acc_phase2_mean']):.4f} | "
            f"New={float(b['new_acc_phase2_mean']):.4f} | "
            f"All={float(b['all_acc_phase2_mean']):.4f} | "
            f"Forget={float(b['forgetting_mean']):.4f} | "
            f"H={float(b['harmonic_old_new_mean']):.4f} | "
            f"Score={float(b['stability_score_mean']):.4f}"
        )


def save_csv(path: str, rows: List[Dict[str, object]]) -> None:
    if not rows:
        return
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def save_agg_csv(path: str, rows: List[Dict[str, object]]) -> None:
    agg = aggregate_results(rows)
    if not agg:
        return
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(agg[0].keys()))
        writer.writeheader()
        writer.writerows(agg)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=str, default="./data")
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--phase1-epochs", type=int, default=3)
    parser.add_argument("--phase2-epochs", type=int, default=3)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--anchor-lambda", type=float, default=5.0, help="Legacy/global value; strategies in this script use strategy-specific anchor weights.")
    parser.add_argument("--distill-lambda", type=float, default=0.7, help="Legacy/global value; strategies in this script use strategy-specific distill weights.")
    parser.add_argument("--temperature", type=float, default=2.0)
    parser.add_argument("--held-out", type=str, default=",".join(DEFAULT_HELD_OUT))
    parser.add_argument("--replay-fractions", type=str, default="0,0.005,0.01,0.02,0.05,0.10,0.20,0.35")
    parser.add_argument("--seeds", type=str, default="42")
    parser.add_argument("--max-train-per-class", type=int, default=0, help="0 = no cap")
    parser.add_argument("--max-test-per-class", type=int, default=0, help="0 = no cap")
    parser.add_argument("--no-emnist-orientation-fix", action="store_true")
    parser.add_argument("--strategies", type=str, default=None, help="Optional comma-separated exact strategy names")
    parser.add_argument("--csv", type=str, default="symbols_density_sweep_results.csv")
    parser.add_argument("--agg-csv", type=str, default="symbols_density_sweep_aggregate.csv")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"

    held_out = parse_symbols(args.held_out)
    all_classes = list(range(N_CLASSES))
    new_classes = sorted(set(held_out))
    old_classes = [c for c in all_classes if c not in set(new_classes)]
    replay_fractions = parse_float_list(args.replay_fractions)
    seeds = parse_int_list(args.seeds)
    strategies = select_strategies(args.strategies)

    max_train_per_class = args.max_train_per_class if args.max_train_per_class > 0 else None
    max_test_per_class = args.max_test_per_class if args.max_test_per_class > 0 else None

    print(f"Device:                  {device}")
    print(f"Classes:                 digits 0-9 + letters A-Z = {N_CLASSES}")
    print(f"Old symbols:             {symbols_string(old_classes)}")
    print(f"Held-out symbols:        {symbols_string(new_classes)}")
    print(f"Old class count:         {len(old_classes)}")
    print(f"Held-out class count:    {len(new_classes)}")
    print(f"Replay fractions:        {replay_fractions}")
    print(f"Seeds:                   {seeds}")
    print(f"Phase 1 epochs:          {args.phase1_epochs}")
    print(f"Phase 2 epochs:          {args.phase2_epochs}")
    print(f"Strategies:              {len(strategies)}")
    print("Dataset:                 MNIST digits + EMNIST Letters")
    print("Replay baselines:        class-balanced random, pure diverse, boundary-diverse")
    print("Diagnostic axis:         distillation weight sweep / memory density transition")
    print()

    all_results: List[Dict[str, object]] = []

    for seed in seeds:
        set_seed(seed)
        data = make_data_splits(
            data_dir=args.data_dir,
            old_classes=old_classes,
            new_classes=new_classes,
            batch_size=args.batch_size,
            seed=seed,
            max_train_per_class=max_train_per_class,
            max_test_per_class=max_test_per_class,
            fix_emnist_orientation=not args.no_emnist_orientation_fix,
        )
        print(f"Train old examples:      {len(data['train_old'])}")
        print(f"Train new examples:      {len(data['train_new'])}")
        print(f"Test old examples:       {len(data['test_old'])}")
        print(f"Test new examples:       {len(data['test_new'])}")
        print()

        print("#" * 120)
        print(f"PHASE 1: train one conventional CNN on old symbols only | seed={seed}")
        print("#" * 120)

        model = SmallCNN36().to(device)
        opt = make_optimizer(model, lr=args.lr, soft=False)
        train_phase1(
            model=model,
            loader=data["train_old_loader"],
            optimizer=opt,
            device=device,
            old_classes=old_classes,
            epochs=args.phase1_epochs,
            test_old_loader=data["test_old_loader"],
        )

        old_acc_phase1 = accuracy(model, data["test_old_loader"], device)
        new_acc_phase1 = accuracy(model, data["test_new_loader"], device)
        all_acc_phase1 = accuracy(model, data["test_all_loader"], device)

        print(
            f"Phase 1 saved state | old={old_acc_phase1:.4f} | "
            f"new={new_acc_phase1:.4f} | all={all_acc_phase1:.4f}"
        )

        phase1_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        old_state_cpu = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

        print("Collecting old-model feature/logit statistics for replay selection...")
        stats = collect_old_model_stats(
            model=model,
            train_old=data["train_old"],
            old_classes=old_classes,
            batch_size=args.batch_size,
            device=device,
        )
        print("Stats collected.")

        for replay_fraction in replay_fractions:
            for strategy in strategies:
                result = run_one_condition(
                    strategy=strategy,
                    replay_fraction=replay_fraction,
                    seed=seed,
                    data=data,
                    old_classes=old_classes,
                    new_classes=new_classes,
                    phase1_state=phase1_state,
                    old_state_cpu=old_state_cpu,
                    stats=stats,
                    old_acc_phase1=old_acc_phase1,
                    new_acc_phase1=new_acc_phase1,
                    all_acc_phase1=all_acc_phase1,
                    args=args,
                    device=device,
                )
                all_results.append(result)
                save_csv(args.csv, all_results)
                save_agg_csv(args.agg_csv, all_results)

    print_summary(all_results)
    save_csv(args.csv, all_results)
    save_agg_csv(args.agg_csv, all_results)
    print(f"\nSaved per-run results to: {args.csv}")
    print(f"Saved aggregate results to: {args.agg_csv}")


if __name__ == "__main__":
    main()

```


---

## symbols_micro_replay_diverse.py

```python
# symbols_micro_replay_diverse.py
#
# Combined digits + alphabet continual-learning experiment.
#
# Dataset:
#   MNIST digits 0-9 + EMNIST Letters A-Z = 36 classes.
#
# Phase 1:
#   Train on old symbols only.
#
# Phase 2:
#   Train on held-out new symbols, with tiny old-symbol replay.
#
# Goal:
#   Stress-test whether diverse/boundary-aware replay can beat strong
#   class-balanced random replay, and whether distillation remains the key
#   ingredient for preserving old knowledge.
#
# Run:
#   python symbols_micro_replay_diverse.py
#
# Faster smoke test:
#   python symbols_micro_replay_diverse.py --phase1-epochs 1 --phase2-epochs 1 --seeds 42 --replay-fractions 0,0.01 --max-train-per-class 1000 --max-test-per-class 500
#
# Longer confirmatory run:
#   python symbols_micro_replay_diverse.py --seeds 42,43,44 --replay-fractions 0,0.005,0.01,0.02,0.05,0.10,0.20 --phase1-epochs 3 --phase2-epochs 3

import argparse
import csv
import math
import random
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import ConcatDataset, DataLoader, Dataset, Subset
from torchvision import datasets, transforms
from torchvision.transforms import functional as TF


# -----------------------------
# Symbol map
# -----------------------------

DIGIT_NAMES = [str(i) for i in range(10)]
LETTER_NAMES = [chr(ord("A") + i) for i in range(26)]
CLASS_NAMES = DIGIT_NAMES + LETTER_NAMES
N_CLASSES = 36

DEFAULT_HELD_OUT = ["3", "6", "9", "C", "F", "J", "Q", "V", "X", "Y", "Z"]


def symbol_to_class_id(symbol: str) -> int:
    symbol = symbol.strip().upper()
    if symbol.isdigit():
        n = int(symbol)
        if 0 <= n <= 9:
            return n
    if len(symbol) == 1 and "A" <= symbol <= "Z":
        return 10 + ord(symbol) - ord("A")
    raise ValueError(f"Unknown symbol: {symbol}")


def class_id_to_symbol(cid: int) -> str:
    return CLASS_NAMES[cid]


def parse_symbols(text: str) -> List[int]:
    return [symbol_to_class_id(x) for x in text.split(",") if x.strip()]


def symbols_string(class_ids: Sequence[int]) -> str:
    return ",".join(class_id_to_symbol(i) for i in class_ids)


# -----------------------------
# Utilities
# -----------------------------


def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_float_list(text: str) -> List[float]:
    vals = []
    for part in text.split(","):
        part = part.strip()
        if not part:
            continue
        val = float(part)
        if val < 0.0 or val >= 1.0:
            raise ValueError("Replay fractions must be >= 0 and < 1")
        vals.append(val)
    return vals


def parse_int_list(text: str) -> List[int]:
    return [int(x.strip()) for x in text.split(",") if x.strip()]


def pct(x: float) -> str:
    return f"{100.0 * x:5.2f}%"


def harmonic_mean(a: float, b: float) -> float:
    if a <= 0 or b <= 0:
        return 0.0
    return 2.0 * a * b / (a + b)


# -----------------------------
# Dataset wrappers
# -----------------------------


class LabelOffsetDataset(Dataset):
    """Wrap a dataset and remap labels."""

    def __init__(self, dataset: Dataset, label_fn, name: str):
        self.dataset = dataset
        self.label_fn = label_fn
        self.name = name

        # Build labels once so we can filter quickly.
        labels = []
        for i in range(len(dataset)):
            _x, y = dataset[i]
            labels.append(int(label_fn(int(y))))
        self.targets = torch.tensor(labels, dtype=torch.long)

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int):
        x, y = self.dataset[idx]
        return x, int(self.label_fn(int(y)))


class CombinedLabeledDataset(Dataset):
    """Concat-like dataset with a unified targets vector."""

    def __init__(self, datasets_: Sequence[Dataset]):
        self.datasets = list(datasets_)
        self.cumulative_sizes = []
        total = 0
        targets = []
        for ds in self.datasets:
            total += len(ds)
            self.cumulative_sizes.append(total)
            if hasattr(ds, "targets"):
                targets.extend([int(x) for x in ds.targets])
            else:
                for i in range(len(ds)):
                    _x, y = ds[i]
                    targets.append(int(y))
        self.targets = torch.tensor(targets, dtype=torch.long)

    def __len__(self) -> int:
        return self.cumulative_sizes[-1] if self.cumulative_sizes else 0

    def __getitem__(self, idx: int):
        if idx < 0:
            idx += len(self)
        ds_idx = 0
        while idx >= self.cumulative_sizes[ds_idx]:
            ds_idx += 1
        prev = 0 if ds_idx == 0 else self.cumulative_sizes[ds_idx - 1]
        return self.datasets[ds_idx][idx - prev]


class FlaggedDataset(Dataset):
    """Wraps a dataset and returns x, y, is_old_replay."""

    def __init__(self, dataset: Dataset, is_old_replay: int):
        self.dataset = dataset
        self.is_old_replay = int(is_old_replay)

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int):
        x, y = self.dataset[idx]
        return x, int(y), self.is_old_replay


class NewPlusReplayDataset(Dataset):
    def __init__(self, new_subset: Dataset, replay_subset: Optional[Dataset]):
        parts: List[Dataset] = [FlaggedDataset(new_subset, 0)]
        if replay_subset is not None and len(replay_subset) > 0:
            parts.append(FlaggedDataset(replay_subset, 1))
        self.dataset = ConcatDataset(parts)

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int):
        return self.dataset[idx]


class FeatureSubset(Dataset):
    """Subset that also preserves a .targets vector."""

    def __init__(self, base: Dataset, indices: Sequence[int]):
        self.base = base
        self.indices = list(indices)
        if hasattr(base, "targets"):
            self.targets = torch.tensor([int(base.targets[i]) for i in self.indices], dtype=torch.long)
        else:
            labels = []
            for i in self.indices:
                _x, y = base[i]
                labels.append(int(y))
            self.targets = torch.tensor(labels, dtype=torch.long)

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, idx: int):
        return self.base[self.indices[idx]]


# -----------------------------
# Data creation
# -----------------------------


def emnist_orientation_fix(img):
    # EMNIST images are commonly stored rotated/transposed relative to MNIST.
    # This transform makes letters visually upright for standard display/training.
    return TF.hflip(TF.rotate(img, -90))


def make_combined_dataset(
    data_dir: str,
    train: bool,
    fix_emnist_orientation: bool = True,
) -> CombinedLabeledDataset:
    mnist_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])

    emnist_transforms = []
    if fix_emnist_orientation:
        emnist_transforms.append(transforms.Lambda(emnist_orientation_fix))
    emnist_transforms.extend([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])
    emnist_transform = transforms.Compose(emnist_transforms)

    mnist = datasets.MNIST(root=data_dir, train=train, download=True, transform=mnist_transform)
    # EMNIST Letters labels are 1..26. Map to 10..35.
    emnist_letters = datasets.EMNIST(
        root=data_dir,
        split="letters",
        train=train,
        download=True,
        transform=emnist_transform,
    )

    mnist_wrapped = LabelOffsetDataset(mnist, lambda y: y, "MNIST")
    emnist_wrapped = LabelOffsetDataset(emnist_letters, lambda y: 10 + (y - 1), "EMNIST-Letters")

    return CombinedLabeledDataset([mnist_wrapped, emnist_wrapped])


def class_filtered_indices(dataset: Dataset, allowed_classes: Sequence[int]) -> List[int]:
    allowed = set(int(c) for c in allowed_classes)
    labels = dataset.targets if hasattr(dataset, "targets") else None
    if labels is not None:
        return [i for i, y in enumerate(labels) if int(y) in allowed]
    out = []
    for i in range(len(dataset)):
        _x, y = dataset[i]
        if int(y) in allowed:
            out.append(i)
    return out


def cap_per_class_indices(
    dataset: Dataset,
    indices: Sequence[int],
    max_per_class: Optional[int],
    seed: int,
) -> List[int]:
    if max_per_class is None or max_per_class <= 0:
        return list(indices)

    rng = random.Random(seed)
    by_class: Dict[int, List[int]] = {}
    targets = dataset.targets
    for idx in indices:
        y = int(targets[idx])
        by_class.setdefault(y, []).append(int(idx))

    capped: List[int] = []
    for c, vals in sorted(by_class.items()):
        vals = list(vals)
        rng.shuffle(vals)
        capped.extend(vals[:max_per_class])
    rng.shuffle(capped)
    return capped


def make_data_splits(
    data_dir: str,
    old_classes: List[int],
    new_classes: List[int],
    batch_size: int,
    seed: int,
    max_train_per_class: Optional[int],
    max_test_per_class: Optional[int],
    fix_emnist_orientation: bool,
):
    train_full = make_combined_dataset(data_dir, train=True, fix_emnist_orientation=fix_emnist_orientation)
    test_full = make_combined_dataset(data_dir, train=False, fix_emnist_orientation=fix_emnist_orientation)

    train_old_indices = class_filtered_indices(train_full, old_classes)
    train_new_indices = class_filtered_indices(train_full, new_classes)
    test_old_indices = class_filtered_indices(test_full, old_classes)
    test_new_indices = class_filtered_indices(test_full, new_classes)

    train_old_indices = cap_per_class_indices(train_full, train_old_indices, max_train_per_class, seed + 1)
    train_new_indices = cap_per_class_indices(train_full, train_new_indices, max_train_per_class, seed + 2)
    test_old_indices = cap_per_class_indices(test_full, test_old_indices, max_test_per_class, seed + 3)
    test_new_indices = cap_per_class_indices(test_full, test_new_indices, max_test_per_class, seed + 4)

    train_old = FeatureSubset(train_full, train_old_indices)
    train_new = FeatureSubset(train_full, train_new_indices)
    test_old = FeatureSubset(test_full, test_old_indices)
    test_new = FeatureSubset(test_full, test_new_indices)

    train_old_loader = DataLoader(train_old, batch_size=batch_size, shuffle=True)
    test_old_loader = DataLoader(test_old, batch_size=batch_size, shuffle=False)
    test_new_loader = DataLoader(test_new, batch_size=batch_size, shuffle=False)
    test_all_loader = DataLoader(
        FeatureSubset(test_full, test_old_indices + test_new_indices),
        batch_size=batch_size,
        shuffle=False,
    )

    return {
        "train_full": train_full,
        "test_full": test_full,
        "train_old": train_old,
        "train_new": train_new,
        "test_old": test_old,
        "test_new": test_new,
        "train_old_loader": train_old_loader,
        "test_old_loader": test_old_loader,
        "test_new_loader": test_new_loader,
        "test_all_loader": test_all_loader,
    }


# -----------------------------
# Model
# -----------------------------


class SmallCNN36(nn.Module):
    def __init__(self, n_classes: int = N_CLASSES):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, n_classes)

    def features(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = torch.flatten(x, 1)
        x = F.relu(self.fc1(x))
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(self.features(x))


def make_optimizer(model: SmallCNN36, lr: float = 1e-3, soft: bool = False):
    if soft:
        return torch.optim.Adam([
            {"name": "conv1", "params": model.conv1.parameters(), "lr": lr * 0.25},
            {"name": "conv2", "params": model.conv2.parameters(), "lr": lr * 0.50},
            {"name": "fc1", "params": model.fc1.parameters(), "lr": lr},
            {"name": "fc2", "params": model.fc2.parameters(), "lr": lr},
        ])
    return torch.optim.Adam(model.parameters(), lr=lr)


# -----------------------------
# Evaluation / training
# -----------------------------


def mask_logits(logits: torch.Tensor, allowed_classes: Optional[Sequence[int]]) -> torch.Tensor:
    if allowed_classes is None:
        return logits
    out = torch.full_like(logits, -1e9)
    idx = torch.tensor(list(allowed_classes), dtype=torch.long, device=logits.device)
    out[:, idx] = logits[:, idx]
    return out


@torch.no_grad()
def accuracy(model: nn.Module, loader: DataLoader, device: str) -> float:
    model.eval()
    correct = 0
    total = 0
    for batch in loader:
        if len(batch) == 3:
            x, y, _flag = batch
        else:
            x, y = batch
        x = x.to(device)
        y = y.to(device)
        pred = model(x).argmax(dim=1)
        correct += int((pred == y).sum().item())
        total += int(y.numel())
    return correct / max(1, total)


def train_phase1(
    model: SmallCNN36,
    loader: DataLoader,
    optimizer,
    device: str,
    old_classes: Sequence[int],
    epochs: int,
    test_old_loader: DataLoader,
):
    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0
        total_seen = 0
        for x, y in loader:
            x = x.to(device)
            y = y.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = mask_logits(model(x), old_classes)
            loss = F.cross_entropy(logits, y)
            loss.backward()
            optimizer.step()
            total_loss += float(loss.item()) * x.size(0)
            total_seen += x.size(0)
        old_acc = accuracy(model, test_old_loader, device)
        print(f"Phase 1 epoch {epoch:02d} | loss {total_loss / max(1, total_seen):.4f} | old_acc {old_acc:.4f}")


def anchor_penalty(model: nn.Module, old_state: Dict[str, torch.Tensor]) -> torch.Tensor:
    total = None
    count = 0
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        old = old_state[name].to(p.device)
        val = (p - old).pow(2).mean()
        total = val if total is None else total + val
        count += 1
    if total is None:
        return torch.tensor(0.0, device=next(model.parameters()).device)
    return total / max(1, count)


def distill_loss_on_old_examples(
    student_logits: torch.Tensor,
    teacher_logits: torch.Tensor,
    old_classes_tensor: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    s = student_logits[:, old_classes_tensor] / temperature
    t = teacher_logits[:, old_classes_tensor] / temperature
    return F.kl_div(
        F.log_softmax(s, dim=1),
        F.softmax(t, dim=1),
        reduction="batchmean",
    ) * (temperature ** 2)


def train_phase2(
    model: SmallCNN36,
    teacher: SmallCNN36,
    loader: DataLoader,
    optimizer,
    device: str,
    epochs: int,
    old_state: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    use_anchor: bool,
    use_distill: bool,
    anchor_lambda: float,
    distill_lambda: float,
    temperature: float,
    test_old_loader: DataLoader,
    quiet: bool = False,
):
    teacher.eval()
    old_classes_tensor = torch.tensor(list(old_classes), dtype=torch.long, device=device)

    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = total_ce = total_anchor = total_distill = 0.0
        total_seen = 0

        for x, y, is_old in loader:
            x = x.to(device)
            y = y.to(device)
            is_old = is_old.to(device).bool()
            optimizer.zero_grad(set_to_none=True)

            logits = model(x)
            ce = F.cross_entropy(logits, y)

            a = torch.tensor(0.0, device=device)
            if use_anchor:
                a = anchor_penalty(model, old_state)

            d = torch.tensor(0.0, device=device)
            if use_distill and is_old.any():
                with torch.no_grad():
                    teacher_logits = teacher(x[is_old])
                d = distill_loss_on_old_examples(
                    logits[is_old],
                    teacher_logits,
                    old_classes_tensor,
                    temperature,
                )

            loss = ce + anchor_lambda * a + distill_lambda * d
            loss.backward()
            optimizer.step()

            n = x.size(0)
            total_loss += float(loss.item()) * n
            total_ce += float(ce.item()) * n
            total_anchor += float(a.item()) * n
            total_distill += float(d.item()) * n
            total_seen += n

        old_acc = accuracy(model, test_old_loader, device)
        if not quiet:
            print(
                f"Phase 2 epoch {epoch:02d} | "
                f"loss {total_loss / max(1, total_seen):.4f} | "
                f"ce {total_ce / max(1, total_seen):.4f} | "
                f"anchor {total_anchor / max(1, total_seen):.6f} | "
                f"distill {total_distill / max(1, total_seen):.4f} | "
                f"old_acc {old_acc:.4f}"
            )


# -----------------------------
# Memory selection
# -----------------------------


@torch.no_grad()
def collect_old_model_stats(
    model: SmallCNN36,
    train_old: Dataset,
    old_classes: Sequence[int],
    batch_size: int,
    device: str,
) -> Dict[str, torch.Tensor]:
    loader = DataLoader(train_old, batch_size=batch_size, shuffle=False)
    model.eval()

    all_features = []
    all_logits = []
    all_labels = []

    for x, y in loader:
        x = x.to(device)
        feats = model.features(x)
        logits = model.fc2(feats)
        all_features.append(feats.cpu())
        all_logits.append(logits.cpu())
        all_labels.append(torch.tensor(y, dtype=torch.long))

    features = torch.cat(all_features, dim=0)
    logits = torch.cat(all_logits, dim=0)
    labels = torch.cat(all_labels, dim=0)

    old_idx = torch.tensor(list(old_classes), dtype=torch.long)
    old_logits = logits[:, old_idx]
    probs = F.softmax(old_logits, dim=1)
    top2 = torch.topk(probs, k=min(2, probs.size(1)), dim=1).values
    if top2.size(1) == 1:
        margin = torch.ones(top2.size(0))
    else:
        margin = top2[:, 0] - top2[:, 1]
    confidence = top2[:, 0]
    entropy = -(probs * (probs.clamp_min(1e-12).log())).sum(dim=1)

    centers: Dict[int, torch.Tensor] = {}
    distances = torch.zeros(len(train_old))
    for c in old_classes:
        mask = labels == int(c)
        if mask.any():
            center = features[mask].mean(dim=0)
            centers[int(c)] = center
            distances[mask] = torch.norm(features[mask] - center, dim=1)

    return {
        "features": features,
        "labels": labels,
        "logits": logits,
        "margin": margin,
        "confidence": confidence,
        "entropy": entropy,
        "distance": distances,
    }


def budget_from_fraction(n_new: int, replay_fraction: float) -> int:
    if replay_fraction <= 0:
        return 0
    return int((replay_fraction / (1.0 - replay_fraction)) * n_new)


def allocate_budget_by_class(labels: torch.Tensor, old_classes: Sequence[int], budget: int) -> Dict[int, int]:
    if budget <= 0:
        return {int(c): 0 for c in old_classes}
    present = [int(c) for c in old_classes if int((labels == int(c)).sum().item()) > 0]
    if not present:
        return {}
    base = budget // len(present)
    rem = budget % len(present)
    alloc = {}
    for i, c in enumerate(present):
        alloc[c] = base + (1 if i < rem else 0)
    return alloc


def balanced_random_indices(labels: torch.Tensor, old_classes: Sequence[int], budget: int, seed: int) -> List[int]:
    rng = random.Random(seed)
    alloc = allocate_budget_by_class(labels, old_classes, budget)
    selected: List[int] = []
    for c, k in alloc.items():
        idx = torch.where(labels == c)[0].tolist()
        rng.shuffle(idx)
        selected.extend(idx[:min(k, len(idx))])
    rng.shuffle(selected)
    return selected


def sorted_take_evenly(indices: List[int], scores: torch.Tensor, k: int, reverse: bool = False) -> List[int]:
    if k <= 0 or not indices:
        return []
    if len(indices) <= k:
        return list(indices)
    idx_sorted = sorted(indices, key=lambda i: float(scores[i]), reverse=reverse)
    if k == 1:
        return [idx_sorted[len(idx_sorted) // 2]]
    picks = []
    for j in range(k):
        pos = round(j * (len(idx_sorted) - 1) / (k - 1))
        picks.append(idx_sorted[pos])
    return picks


def boundary_diverse_indices(
    stats: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    budget: int,
    seed: int,
    boundary_frac: float = 0.50,
    diverse_frac: float = 0.35,
    prototype_frac: float = 0.15,
) -> List[int]:
    """
    Stress-test selector.

    Per class, select a mix of:
      - low-margin examples: decision-boundary memories
      - diverse examples: evenly spread by embedding distance from class center
      - prototype examples: near class centers

    This is deliberately stronger than the earlier naive curated replay.
    """
    rng = random.Random(seed)
    labels = stats["labels"]
    margin = stats["margin"]
    distance = stats["distance"]
    alloc = allocate_budget_by_class(labels, old_classes, budget)
    selected: List[int] = []

    for c, k in alloc.items():
        if k <= 0:
            continue
        class_idx = torch.where(labels == c)[0].tolist()
        if len(class_idx) <= k:
            selected.extend(class_idx)
            continue

        rng.shuffle(class_idx)
        n_boundary = int(round(k * boundary_frac))
        n_diverse = int(round(k * diverse_frac))
        n_proto = k - n_boundary - n_diverse
        if n_proto < 0:
            n_proto = 0

        # 1) Low margin = ambiguous/boundary examples.
        boundary = sorted(class_idx, key=lambda i: float(margin[i]))[:n_boundary]
        used = set(boundary)
        remaining = [i for i in class_idx if i not in used]

        # 2) Diversity by selecting evenly across center-distance spectrum.
        diverse = sorted_take_evenly(remaining, distance, n_diverse, reverse=False)
        used.update(diverse)
        remaining = [i for i in remaining if i not in used]

        # 3) Prototypes near class center.
        proto = sorted(remaining, key=lambda i: float(distance[i]))[:n_proto]

        picked = boundary + diverse + proto
        if len(picked) < k:
            rest = [i for i in class_idx if i not in set(picked)]
            rng.shuffle(rest)
            picked.extend(rest[: k - len(picked)])
        selected.extend(picked[:k])

    rng.shuffle(selected)
    return selected


def pure_diverse_indices(
    stats: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    budget: int,
    seed: int,
) -> List[int]:
    labels = stats["labels"]
    distance = stats["distance"]
    alloc = allocate_budget_by_class(labels, old_classes, budget)
    rng = random.Random(seed)
    selected: List[int] = []
    for c, k in alloc.items():
        idx = torch.where(labels == c)[0].tolist()
        rng.shuffle(idx)
        selected.extend(sorted_take_evenly(idx, distance, k, reverse=False))
    rng.shuffle(selected)
    return selected


def make_replay_subset(
    train_old: Dataset,
    stats: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    budget: int,
    selector: str,
    seed: int,
) -> Optional[Dataset]:
    if budget <= 0 or selector == "none":
        return None
    labels = stats["labels"] if stats is not None else train_old.targets

    if selector == "random":
        idx = balanced_random_indices(labels, old_classes, budget, seed)
    elif selector == "diverse":
        idx = pure_diverse_indices(stats, old_classes, budget, seed)
    elif selector == "boundary_diverse":
        idx = boundary_diverse_indices(stats, old_classes, budget, seed)
    else:
        raise ValueError(f"Unknown selector: {selector}")

    return FeatureSubset(train_old, idx)


# -----------------------------
# Strategies
# -----------------------------


@dataclass
class Strategy:
    name: str
    selector: str
    use_anchor: bool = False
    use_distill: bool = False
    soft: bool = False


STRATEGIES = [
    Strategy("No replay", "none"),
    Strategy("Balanced random replay", "random"),
    Strategy("Pure diverse replay", "diverse"),
    Strategy("Boundary-diverse replay", "boundary_diverse"),
    Strategy("Balanced random + anchor", "random", use_anchor=True),
    Strategy("Boundary-diverse + anchor", "boundary_diverse", use_anchor=True),
    Strategy("Balanced random + distill", "random", use_distill=True),
    Strategy("Pure diverse + distill", "diverse", use_distill=True),
    Strategy("Boundary-diverse + distill", "boundary_diverse", use_distill=True),
    Strategy("Balanced random + anchor/distill", "random", use_anchor=True, use_distill=True),
    Strategy("Boundary-diverse + anchor/distill", "boundary_diverse", use_anchor=True, use_distill=True),
    Strategy("Balanced random + soft + anchor/distill", "random", use_anchor=True, use_distill=True, soft=True),
    Strategy("Boundary-diverse + soft + anchor/distill", "boundary_diverse", use_anchor=True, use_distill=True, soft=True),
]


def select_strategies(names_text: Optional[str]) -> List[Strategy]:
    if not names_text:
        return STRATEGIES
    wanted = {x.strip().lower() for x in names_text.split(",") if x.strip()}
    out = [s for s in STRATEGIES if s.name.lower() in wanted]
    if not out:
        raise ValueError("No strategies matched --strategies. Use exact strategy names, comma-separated.")
    return out


# -----------------------------
# Experiment
# -----------------------------


def run_one_condition(
    strategy: Strategy,
    replay_fraction: float,
    seed: int,
    data,
    old_classes: Sequence[int],
    new_classes: Sequence[int],
    phase1_state: Dict[str, torch.Tensor],
    old_state_cpu: Dict[str, torch.Tensor],
    stats,
    old_acc_phase1: float,
    new_acc_phase1: float,
    all_acc_phase1: float,
    args,
    device: str,
) -> Dict[str, object]:
    condition_seed = seed + int(replay_fraction * 1_000_000) + abs(hash(strategy.name)) % 100_000
    set_seed(condition_seed)

    model = SmallCNN36().to(device)
    model.load_state_dict(phase1_state)

    teacher = SmallCNN36().to(device)
    teacher.load_state_dict(phase1_state)
    teacher.eval()
    for p in teacher.parameters():
        p.requires_grad = False

    budget = budget_from_fraction(len(data["train_new"]), replay_fraction)
    replay_subset = make_replay_subset(
        train_old=data["train_old"],
        stats=stats,
        old_classes=old_classes,
        budget=budget,
        selector=strategy.selector,
        seed=condition_seed + 17,
    )

    phase2_dataset = NewPlusReplayDataset(data["train_new"], replay_subset)
    generator = torch.Generator()
    generator.manual_seed(condition_seed + 23)
    phase2_loader = DataLoader(
        phase2_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        generator=generator,
    )

    optimizer = make_optimizer(model, lr=args.lr, soft=strategy.soft)

    if not args.quiet:
        print("=" * 148)
        print(f"Seed={seed} | Replay={pct(replay_fraction)} | {strategy.name} | budget={budget}")
        print("=" * 148)

    train_phase2(
        model=model,
        teacher=teacher,
        loader=phase2_loader,
        optimizer=optimizer,
        device=device,
        epochs=args.phase2_epochs,
        old_state=old_state_cpu,
        old_classes=old_classes,
        use_anchor=strategy.use_anchor,
        use_distill=strategy.use_distill,
        anchor_lambda=args.anchor_lambda,
        distill_lambda=args.distill_lambda,
        temperature=args.temperature,
        test_old_loader=data["test_old_loader"],
        quiet=args.quiet,
    )

    old_acc_phase2 = accuracy(model, data["test_old_loader"], device)
    new_acc_phase2 = accuracy(model, data["test_new_loader"], device)
    all_acc_phase2 = accuracy(model, data["test_all_loader"], device)
    forgetting = old_acc_phase1 - old_acc_phase2
    h = harmonic_mean(old_acc_phase2, new_acc_phase2)
    stability_score = all_acc_phase2 - forgetting

    result = {
        "seed": seed,
        "strategy": strategy.name,
        "selector": strategy.selector,
        "use_anchor": strategy.use_anchor,
        "use_distill": strategy.use_distill,
        "soft": strategy.soft,
        "replay_fraction": replay_fraction,
        "budget": budget,
        "old_acc_phase1": old_acc_phase1,
        "new_acc_phase1": new_acc_phase1,
        "all_acc_phase1": all_acc_phase1,
        "old_acc_phase2": old_acc_phase2,
        "new_acc_phase2": new_acc_phase2,
        "all_acc_phase2": all_acc_phase2,
        "forgetting": forgetting,
        "harmonic_old_new": h,
        "stability_score": stability_score,
    }

    if not args.quiet:
        print(
            f"Result | Old P2={old_acc_phase2:.4f} | New P2={new_acc_phase2:.4f} | "
            f"All P2={all_acc_phase2:.4f} | Forget={forgetting:.4f} | "
            f"Score={stability_score:.4f} | H(old,new)={h:.4f}\n"
        )

    return result


def aggregate_results(results: List[Dict[str, object]]) -> List[Dict[str, object]]:
    keys = sorted(set((r["replay_fraction"], r["strategy"]) for r in results))
    out = []
    metrics = [
        "old_acc_phase2",
        "new_acc_phase2",
        "all_acc_phase2",
        "forgetting",
        "harmonic_old_new",
        "stability_score",
    ]
    for frac, strategy in keys:
        rows = [r for r in results if r["replay_fraction"] == frac and r["strategy"] == strategy]
        rec = {"replay_fraction": frac, "strategy": strategy, "n": len(rows)}
        for m in metrics:
            vals = [float(r[m]) for r in rows]
            mean = sum(vals) / len(vals)
            if len(vals) > 1:
                var = sum((x - mean) ** 2 for x in vals) / (len(vals) - 1)
                sd = math.sqrt(var)
            else:
                sd = 0.0
            rec[m + "_mean"] = mean
            rec[m + "_sd"] = sd
        out.append(rec)
    return out


def print_summary(results: List[Dict[str, object]]) -> None:
    agg = aggregate_results(results)

    print("\n\nFINAL AGGREGATE TABLE")
    print("=" * 170)
    print(
        f"{'Replay':>8s} {'Strategy':48s} {'Old P2':>9s} {'New P2':>9s} "
        f"{'All P2':>9s} {'Forget':>9s} {'H':>9s} {'Score':>9s} {'n':>4s}"
    )
    print("-" * 170)
    for r in sorted(agg, key=lambda x: (float(x["replay_fraction"]), str(x["strategy"]))):
        print(
            f"{pct(float(r['replay_fraction'])):>8s} "
            f"{str(r['strategy']):48s} "
            f"{float(r['old_acc_phase2_mean']):9.4f} "
            f"{float(r['new_acc_phase2_mean']):9.4f} "
            f"{float(r['all_acc_phase2_mean']):9.4f} "
            f"{float(r['forgetting_mean']):9.4f} "
            f"{float(r['harmonic_old_new_mean']):9.4f} "
            f"{float(r['stability_score_mean']):9.4f} "
            f"{int(r['n']):4d}"
        )

    print("\n\nBEST BY REPLAY FRACTION")
    print("=" * 170)
    print("Sorted by harmonic mean of old/new accuracy, then stability_score.")
    for frac in sorted(set(float(r["replay_fraction"]) for r in results)):
        rows = [r for r in agg if float(r["replay_fraction"]) == frac]
        rows = sorted(rows, key=lambda x: (float(x["harmonic_old_new_mean"]), float(x["stability_score_mean"])), reverse=True)
        b = rows[0]
        print(
            f"Replay {pct(frac)} | best: {b['strategy']} | "
            f"Old={float(b['old_acc_phase2_mean']):.4f} | "
            f"New={float(b['new_acc_phase2_mean']):.4f} | "
            f"All={float(b['all_acc_phase2_mean']):.4f} | "
            f"Forget={float(b['forgetting_mean']):.4f} | "
            f"H={float(b['harmonic_old_new_mean']):.4f} | "
            f"Score={float(b['stability_score_mean']):.4f}"
        )


def save_csv(path: str, rows: List[Dict[str, object]]) -> None:
    if not rows:
        return
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def save_agg_csv(path: str, rows: List[Dict[str, object]]) -> None:
    agg = aggregate_results(rows)
    if not agg:
        return
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(agg[0].keys()))
        writer.writeheader()
        writer.writerows(agg)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=str, default="./data")
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--phase1-epochs", type=int, default=3)
    parser.add_argument("--phase2-epochs", type=int, default=3)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--anchor-lambda", type=float, default=5.0)
    parser.add_argument("--distill-lambda", type=float, default=0.7)
    parser.add_argument("--temperature", type=float, default=2.0)
    parser.add_argument("--held-out", type=str, default=",".join(DEFAULT_HELD_OUT))
    parser.add_argument("--replay-fractions", type=str, default="0,0.005,0.01,0.02,0.05,0.10,0.20")
    parser.add_argument("--seeds", type=str, default="42")
    parser.add_argument("--max-train-per-class", type=int, default=0, help="0 = no cap")
    parser.add_argument("--max-test-per-class", type=int, default=0, help="0 = no cap")
    parser.add_argument("--no-emnist-orientation-fix", action="store_true")
    parser.add_argument("--strategies", type=str, default=None, help="Optional comma-separated exact strategy names")
    parser.add_argument("--csv", type=str, default="symbols_micro_replay_results.csv")
    parser.add_argument("--agg-csv", type=str, default="symbols_micro_replay_aggregate.csv")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"

    held_out = parse_symbols(args.held_out)
    all_classes = list(range(N_CLASSES))
    new_classes = sorted(set(held_out))
    old_classes = [c for c in all_classes if c not in set(new_classes)]
    replay_fractions = parse_float_list(args.replay_fractions)
    seeds = parse_int_list(args.seeds)
    strategies = select_strategies(args.strategies)

    max_train_per_class = args.max_train_per_class if args.max_train_per_class > 0 else None
    max_test_per_class = args.max_test_per_class if args.max_test_per_class > 0 else None

    print(f"Device:                  {device}")
    print(f"Classes:                 digits 0-9 + letters A-Z = {N_CLASSES}")
    print(f"Old symbols:             {symbols_string(old_classes)}")
    print(f"Held-out symbols:        {symbols_string(new_classes)}")
    print(f"Old class count:         {len(old_classes)}")
    print(f"Held-out class count:    {len(new_classes)}")
    print(f"Replay fractions:        {replay_fractions}")
    print(f"Seeds:                   {seeds}")
    print(f"Phase 1 epochs:          {args.phase1_epochs}")
    print(f"Phase 2 epochs:          {args.phase2_epochs}")
    print(f"Strategies:              {len(strategies)}")
    print("Dataset:                 MNIST digits + EMNIST Letters")
    print("Replay baselines:        class-balanced random, pure diverse, boundary-diverse")
    print()

    all_results: List[Dict[str, object]] = []

    for seed in seeds:
        set_seed(seed)
        data = make_data_splits(
            data_dir=args.data_dir,
            old_classes=old_classes,
            new_classes=new_classes,
            batch_size=args.batch_size,
            seed=seed,
            max_train_per_class=max_train_per_class,
            max_test_per_class=max_test_per_class,
            fix_emnist_orientation=not args.no_emnist_orientation_fix,
        )
        print(f"Train old examples:      {len(data['train_old'])}")
        print(f"Train new examples:      {len(data['train_new'])}")
        print(f"Test old examples:       {len(data['test_old'])}")
        print(f"Test new examples:       {len(data['test_new'])}")
        print()

        print("#" * 120)
        print(f"PHASE 1: train one conventional CNN on old symbols only | seed={seed}")
        print("#" * 120)

        model = SmallCNN36().to(device)
        opt = make_optimizer(model, lr=args.lr, soft=False)
        train_phase1(
            model=model,
            loader=data["train_old_loader"],
            optimizer=opt,
            device=device,
            old_classes=old_classes,
            epochs=args.phase1_epochs,
            test_old_loader=data["test_old_loader"],
        )

        old_acc_phase1 = accuracy(model, data["test_old_loader"], device)
        new_acc_phase1 = accuracy(model, data["test_new_loader"], device)
        all_acc_phase1 = accuracy(model, data["test_all_loader"], device)

        print(
            f"Phase 1 saved state | old={old_acc_phase1:.4f} | "
            f"new={new_acc_phase1:.4f} | all={all_acc_phase1:.4f}"
        )

        phase1_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        old_state_cpu = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

        print("Collecting old-model feature/logit statistics for replay selection...")
        stats = collect_old_model_stats(
            model=model,
            train_old=data["train_old"],
            old_classes=old_classes,
            batch_size=args.batch_size,
            device=device,
        )
        print("Stats collected.")

        for replay_fraction in replay_fractions:
            for strategy in strategies:
                result = run_one_condition(
                    strategy=strategy,
                    replay_fraction=replay_fraction,
                    seed=seed,
                    data=data,
                    old_classes=old_classes,
                    new_classes=new_classes,
                    phase1_state=phase1_state,
                    old_state_cpu=old_state_cpu,
                    stats=stats,
                    old_acc_phase1=old_acc_phase1,
                    new_acc_phase1=new_acc_phase1,
                    all_acc_phase1=all_acc_phase1,
                    args=args,
                    device=device,
                )
                all_results.append(result)
                save_csv(args.csv, all_results)
                save_agg_csv(args.agg_csv, all_results)

    print_summary(all_results)
    save_csv(args.csv, all_results)
    save_agg_csv(args.agg_csv, all_results)
    print(f"\nSaved per-run results to: {args.csv}")
    print(f"Saved aggregate results to: {args.agg_csv}")


if __name__ == "__main__":
    main()

```


---

## symbols_paper_core_run.py

```python
# symbols_paper_core_run.py
#
# Combined digits + alphabet continual-learning experiment.
#
# Dataset:
#   MNIST digits 0-9 + EMNIST Letters A-Z = 36 classes.
#
# Purpose:
#   Paper-core confirmatory run after the exploratory combined-symbol experiments.
#
# This script focuses on the publishable question:
#   How do replay density and distillation strength interact in a 36-class
#   class-incremental symbol task?
#
# It intentionally drops exploratory arms and keeps only:
#   - no replay
#   - class-balanced random replay
#   - pure-diverse replay
#   - boundary-diverse replay
#   - class-balanced random + distillation strength sweep
#   - boundary-diverse + soft consolidation + weak anchor/distill
#
# Run:
#   python symbols_paper_core_run.py
#
# Smoke test:
#   python symbols_paper_core_run.py --phase1-epochs 1 --phase2-epochs 1 --seeds 42 --replay-fractions 0,0.01 --max-train-per-class 1000 --max-test-per-class 500
#
# Full paper-core run:
#   python symbols_paper_core_run.py --seeds 42,43,44 --replay-fractions 0,0.005,0.01,0.02,0.05,0.10,0.20,0.35 --phase1-epochs 3 --phase2-epochs 3

import argparse
import csv
import math
import random
import hashlib
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import ConcatDataset, DataLoader, Dataset, Subset
from torchvision import datasets, transforms
from torchvision.transforms import functional as TF


# -----------------------------
# Symbol map
# -----------------------------

DIGIT_NAMES = [str(i) for i in range(10)]
LETTER_NAMES = [chr(ord("A") + i) for i in range(26)]
CLASS_NAMES = DIGIT_NAMES + LETTER_NAMES
N_CLASSES = 36

DEFAULT_HELD_OUT = ["3", "6", "9", "C", "F", "J", "Q", "V", "X", "Y", "Z"]


def symbol_to_class_id(symbol: str) -> int:
    symbol = symbol.strip().upper()
    if symbol.isdigit():
        n = int(symbol)
        if 0 <= n <= 9:
            return n
    if len(symbol) == 1 and "A" <= symbol <= "Z":
        return 10 + ord(symbol) - ord("A")
    raise ValueError(f"Unknown symbol: {symbol}")


def class_id_to_symbol(cid: int) -> str:
    return CLASS_NAMES[cid]


def parse_symbols(text: str) -> List[int]:
    return [symbol_to_class_id(x) for x in text.split(",") if x.strip()]


def symbols_string(class_ids: Sequence[int]) -> str:
    return ",".join(class_id_to_symbol(i) for i in class_ids)


# -----------------------------
# Utilities
# -----------------------------


def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def stable_hash_int(text: str) -> int:
    # Python's built-in hash is intentionally randomized between processes.
    # Use this for reproducible condition seeds.
    return int(hashlib.md5(text.encode("utf-8")).hexdigest()[:8], 16)


def parse_float_list(text: str) -> List[float]:
    vals = []
    for part in text.split(","):
        part = part.strip()
        if not part:
            continue
        val = float(part)
        if val < 0.0 or val >= 1.0:
            raise ValueError("Replay fractions must be >= 0 and < 1")
        vals.append(val)
    return vals


def parse_int_list(text: str) -> List[int]:
    return [int(x.strip()) for x in text.split(",") if x.strip()]


def pct(x: float) -> str:
    return f"{100.0 * x:5.2f}%"


def harmonic_mean(a: float, b: float) -> float:
    if a <= 0 or b <= 0:
        return 0.0
    return 2.0 * a * b / (a + b)


# -----------------------------
# Dataset wrappers
# -----------------------------


class LabelOffsetDataset(Dataset):
    """Wrap a dataset and remap labels."""

    def __init__(self, dataset: Dataset, label_fn, name: str):
        self.dataset = dataset
        self.label_fn = label_fn
        self.name = name

        # Build labels once so we can filter quickly.
        labels = []
        for i in range(len(dataset)):
            _x, y = dataset[i]
            labels.append(int(label_fn(int(y))))
        self.targets = torch.tensor(labels, dtype=torch.long)

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int):
        x, y = self.dataset[idx]
        return x, int(self.label_fn(int(y)))


class CombinedLabeledDataset(Dataset):
    """Concat-like dataset with a unified targets vector."""

    def __init__(self, datasets_: Sequence[Dataset]):
        self.datasets = list(datasets_)
        self.cumulative_sizes = []
        total = 0
        targets = []
        for ds in self.datasets:
            total += len(ds)
            self.cumulative_sizes.append(total)
            if hasattr(ds, "targets"):
                targets.extend([int(x) for x in ds.targets])
            else:
                for i in range(len(ds)):
                    _x, y = ds[i]
                    targets.append(int(y))
        self.targets = torch.tensor(targets, dtype=torch.long)

    def __len__(self) -> int:
        return self.cumulative_sizes[-1] if self.cumulative_sizes else 0

    def __getitem__(self, idx: int):
        if idx < 0:
            idx += len(self)
        ds_idx = 0
        while idx >= self.cumulative_sizes[ds_idx]:
            ds_idx += 1
        prev = 0 if ds_idx == 0 else self.cumulative_sizes[ds_idx - 1]
        return self.datasets[ds_idx][idx - prev]


class FlaggedDataset(Dataset):
    """Wraps a dataset and returns x, y, is_old_replay."""

    def __init__(self, dataset: Dataset, is_old_replay: int):
        self.dataset = dataset
        self.is_old_replay = int(is_old_replay)

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int):
        x, y = self.dataset[idx]
        return x, int(y), self.is_old_replay


class NewPlusReplayDataset(Dataset):
    def __init__(self, new_subset: Dataset, replay_subset: Optional[Dataset]):
        parts: List[Dataset] = [FlaggedDataset(new_subset, 0)]
        if replay_subset is not None and len(replay_subset) > 0:
            parts.append(FlaggedDataset(replay_subset, 1))
        self.dataset = ConcatDataset(parts)

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int):
        return self.dataset[idx]


class FeatureSubset(Dataset):
    """Subset that also preserves a .targets vector."""

    def __init__(self, base: Dataset, indices: Sequence[int]):
        self.base = base
        self.indices = list(indices)
        if hasattr(base, "targets"):
            self.targets = torch.tensor([int(base.targets[i]) for i in self.indices], dtype=torch.long)
        else:
            labels = []
            for i in self.indices:
                _x, y = base[i]
                labels.append(int(y))
            self.targets = torch.tensor(labels, dtype=torch.long)

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, idx: int):
        return self.base[self.indices[idx]]


# -----------------------------
# Data creation
# -----------------------------


def emnist_orientation_fix(img):
    # EMNIST images are commonly stored rotated/transposed relative to MNIST.
    # This transform makes letters visually upright for standard display/training.
    return TF.hflip(TF.rotate(img, -90))


def make_combined_dataset(
    data_dir: str,
    train: bool,
    fix_emnist_orientation: bool = True,
) -> CombinedLabeledDataset:
    mnist_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])

    emnist_transforms = []
    if fix_emnist_orientation:
        emnist_transforms.append(transforms.Lambda(emnist_orientation_fix))
    emnist_transforms.extend([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])
    emnist_transform = transforms.Compose(emnist_transforms)

    mnist = datasets.MNIST(root=data_dir, train=train, download=True, transform=mnist_transform)
    # EMNIST Letters labels are 1..26. Map to 10..35.
    emnist_letters = datasets.EMNIST(
        root=data_dir,
        split="letters",
        train=train,
        download=True,
        transform=emnist_transform,
    )

    mnist_wrapped = LabelOffsetDataset(mnist, lambda y: y, "MNIST")
    emnist_wrapped = LabelOffsetDataset(emnist_letters, lambda y: 10 + (y - 1), "EMNIST-Letters")

    return CombinedLabeledDataset([mnist_wrapped, emnist_wrapped])


def class_filtered_indices(dataset: Dataset, allowed_classes: Sequence[int]) -> List[int]:
    allowed = set(int(c) for c in allowed_classes)
    labels = dataset.targets if hasattr(dataset, "targets") else None
    if labels is not None:
        return [i for i, y in enumerate(labels) if int(y) in allowed]
    out = []
    for i in range(len(dataset)):
        _x, y = dataset[i]
        if int(y) in allowed:
            out.append(i)
    return out


def cap_per_class_indices(
    dataset: Dataset,
    indices: Sequence[int],
    max_per_class: Optional[int],
    seed: int,
) -> List[int]:
    if max_per_class is None or max_per_class <= 0:
        return list(indices)

    rng = random.Random(seed)
    by_class: Dict[int, List[int]] = {}
    targets = dataset.targets
    for idx in indices:
        y = int(targets[idx])
        by_class.setdefault(y, []).append(int(idx))

    capped: List[int] = []
    for c, vals in sorted(by_class.items()):
        vals = list(vals)
        rng.shuffle(vals)
        capped.extend(vals[:max_per_class])
    rng.shuffle(capped)
    return capped


def make_data_splits(
    data_dir: str,
    old_classes: List[int],
    new_classes: List[int],
    batch_size: int,
    seed: int,
    max_train_per_class: Optional[int],
    max_test_per_class: Optional[int],
    fix_emnist_orientation: bool,
):
    train_full = make_combined_dataset(data_dir, train=True, fix_emnist_orientation=fix_emnist_orientation)
    test_full = make_combined_dataset(data_dir, train=False, fix_emnist_orientation=fix_emnist_orientation)

    train_old_indices = class_filtered_indices(train_full, old_classes)
    train_new_indices = class_filtered_indices(train_full, new_classes)
    test_old_indices = class_filtered_indices(test_full, old_classes)
    test_new_indices = class_filtered_indices(test_full, new_classes)

    train_old_indices = cap_per_class_indices(train_full, train_old_indices, max_train_per_class, seed + 1)
    train_new_indices = cap_per_class_indices(train_full, train_new_indices, max_train_per_class, seed + 2)
    test_old_indices = cap_per_class_indices(test_full, test_old_indices, max_test_per_class, seed + 3)
    test_new_indices = cap_per_class_indices(test_full, test_new_indices, max_test_per_class, seed + 4)

    train_old = FeatureSubset(train_full, train_old_indices)
    train_new = FeatureSubset(train_full, train_new_indices)
    test_old = FeatureSubset(test_full, test_old_indices)
    test_new = FeatureSubset(test_full, test_new_indices)

    train_old_loader = DataLoader(train_old, batch_size=batch_size, shuffle=True)
    test_old_loader = DataLoader(test_old, batch_size=batch_size, shuffle=False)
    test_new_loader = DataLoader(test_new, batch_size=batch_size, shuffle=False)
    test_all_loader = DataLoader(
        FeatureSubset(test_full, test_old_indices + test_new_indices),
        batch_size=batch_size,
        shuffle=False,
    )

    return {
        "train_full": train_full,
        "test_full": test_full,
        "train_old": train_old,
        "train_new": train_new,
        "test_old": test_old,
        "test_new": test_new,
        "train_old_loader": train_old_loader,
        "test_old_loader": test_old_loader,
        "test_new_loader": test_new_loader,
        "test_all_loader": test_all_loader,
    }


# -----------------------------
# Model
# -----------------------------


class SmallCNN36(nn.Module):
    def __init__(self, n_classes: int = N_CLASSES):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, n_classes)

    def features(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = torch.flatten(x, 1)
        x = F.relu(self.fc1(x))
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(self.features(x))


def make_optimizer(model: SmallCNN36, lr: float = 1e-3, soft: bool = False):
    if soft:
        return torch.optim.Adam([
            {"name": "conv1", "params": model.conv1.parameters(), "lr": lr * 0.25},
            {"name": "conv2", "params": model.conv2.parameters(), "lr": lr * 0.50},
            {"name": "fc1", "params": model.fc1.parameters(), "lr": lr},
            {"name": "fc2", "params": model.fc2.parameters(), "lr": lr},
        ])
    return torch.optim.Adam(model.parameters(), lr=lr)


# -----------------------------
# Evaluation / training
# -----------------------------


def mask_logits(logits: torch.Tensor, allowed_classes: Optional[Sequence[int]]) -> torch.Tensor:
    if allowed_classes is None:
        return logits
    out = torch.full_like(logits, -1e9)
    idx = torch.tensor(list(allowed_classes), dtype=torch.long, device=logits.device)
    out[:, idx] = logits[:, idx]
    return out


@torch.no_grad()
def accuracy(model: nn.Module, loader: DataLoader, device: str) -> float:
    model.eval()
    correct = 0
    total = 0
    for batch in loader:
        if len(batch) == 3:
            x, y, _flag = batch
        else:
            x, y = batch
        x = x.to(device)
        y = y.to(device)
        pred = model(x).argmax(dim=1)
        correct += int((pred == y).sum().item())
        total += int(y.numel())
    return correct / max(1, total)


def train_phase1(
    model: SmallCNN36,
    loader: DataLoader,
    optimizer,
    device: str,
    old_classes: Sequence[int],
    epochs: int,
    test_old_loader: DataLoader,
):
    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0
        total_seen = 0
        for x, y in loader:
            x = x.to(device)
            y = y.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = mask_logits(model(x), old_classes)
            loss = F.cross_entropy(logits, y)
            loss.backward()
            optimizer.step()
            total_loss += float(loss.item()) * x.size(0)
            total_seen += x.size(0)
        old_acc = accuracy(model, test_old_loader, device)
        print(f"Phase 1 epoch {epoch:02d} | loss {total_loss / max(1, total_seen):.4f} | old_acc {old_acc:.4f}")


def anchor_penalty(model: nn.Module, old_state: Dict[str, torch.Tensor]) -> torch.Tensor:
    total = None
    count = 0
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        old = old_state[name].to(p.device)
        val = (p - old).pow(2).mean()
        total = val if total is None else total + val
        count += 1
    if total is None:
        return torch.tensor(0.0, device=next(model.parameters()).device)
    return total / max(1, count)


def distill_loss_on_old_examples(
    student_logits: torch.Tensor,
    teacher_logits: torch.Tensor,
    old_classes_tensor: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    s = student_logits[:, old_classes_tensor] / temperature
    t = teacher_logits[:, old_classes_tensor] / temperature
    return F.kl_div(
        F.log_softmax(s, dim=1),
        F.softmax(t, dim=1),
        reduction="batchmean",
    ) * (temperature ** 2)


def train_phase2(
    model: SmallCNN36,
    teacher: SmallCNN36,
    loader: DataLoader,
    optimizer,
    device: str,
    epochs: int,
    old_state: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    use_anchor: bool,
    use_distill: bool,
    anchor_lambda: float,
    distill_lambda: float,
    temperature: float,
    test_old_loader: DataLoader,
    quiet: bool = False,
):
    teacher.eval()
    old_classes_tensor = torch.tensor(list(old_classes), dtype=torch.long, device=device)

    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = total_ce = total_anchor = total_distill = 0.0
        total_seen = 0

        for x, y, is_old in loader:
            x = x.to(device)
            y = y.to(device)
            is_old = is_old.to(device).bool()
            optimizer.zero_grad(set_to_none=True)

            logits = model(x)
            ce = F.cross_entropy(logits, y)

            a = torch.tensor(0.0, device=device)
            if use_anchor:
                a = anchor_penalty(model, old_state)

            d = torch.tensor(0.0, device=device)
            if use_distill and is_old.any():
                with torch.no_grad():
                    teacher_logits = teacher(x[is_old])
                d = distill_loss_on_old_examples(
                    logits[is_old],
                    teacher_logits,
                    old_classes_tensor,
                    temperature,
                )

            loss = ce + anchor_lambda * a + distill_lambda * d
            loss.backward()
            optimizer.step()

            n = x.size(0)
            total_loss += float(loss.item()) * n
            total_ce += float(ce.item()) * n
            total_anchor += float(a.item()) * n
            total_distill += float(d.item()) * n
            total_seen += n

        old_acc = accuracy(model, test_old_loader, device)
        if not quiet:
            print(
                f"Phase 2 epoch {epoch:02d} | "
                f"loss {total_loss / max(1, total_seen):.4f} | "
                f"ce {total_ce / max(1, total_seen):.4f} | "
                f"anchor {total_anchor / max(1, total_seen):.6f} | "
                f"distill {total_distill / max(1, total_seen):.4f} | "
                f"old_acc {old_acc:.4f}"
            )


# -----------------------------
# Memory selection
# -----------------------------


@torch.no_grad()
def collect_old_model_stats(
    model: SmallCNN36,
    train_old: Dataset,
    old_classes: Sequence[int],
    batch_size: int,
    device: str,
) -> Dict[str, torch.Tensor]:
    loader = DataLoader(train_old, batch_size=batch_size, shuffle=False)
    model.eval()

    all_features = []
    all_logits = []
    all_labels = []

    for x, y in loader:
        x = x.to(device)
        feats = model.features(x)
        logits = model.fc2(feats)
        all_features.append(feats.cpu())
        all_logits.append(logits.cpu())
        all_labels.append(torch.tensor(y, dtype=torch.long))

    features = torch.cat(all_features, dim=0)
    logits = torch.cat(all_logits, dim=0)
    labels = torch.cat(all_labels, dim=0)

    old_idx = torch.tensor(list(old_classes), dtype=torch.long)
    old_logits = logits[:, old_idx]
    probs = F.softmax(old_logits, dim=1)
    top2 = torch.topk(probs, k=min(2, probs.size(1)), dim=1).values
    if top2.size(1) == 1:
        margin = torch.ones(top2.size(0))
    else:
        margin = top2[:, 0] - top2[:, 1]
    confidence = top2[:, 0]
    entropy = -(probs * (probs.clamp_min(1e-12).log())).sum(dim=1)

    centers: Dict[int, torch.Tensor] = {}
    distances = torch.zeros(len(train_old))
    for c in old_classes:
        mask = labels == int(c)
        if mask.any():
            center = features[mask].mean(dim=0)
            centers[int(c)] = center
            distances[mask] = torch.norm(features[mask] - center, dim=1)

    return {
        "features": features,
        "labels": labels,
        "logits": logits,
        "margin": margin,
        "confidence": confidence,
        "entropy": entropy,
        "distance": distances,
    }


def budget_from_fraction(n_new: int, replay_fraction: float) -> int:
    if replay_fraction <= 0:
        return 0
    return int((replay_fraction / (1.0 - replay_fraction)) * n_new)


def allocate_budget_by_class(labels: torch.Tensor, old_classes: Sequence[int], budget: int) -> Dict[int, int]:
    if budget <= 0:
        return {int(c): 0 for c in old_classes}
    present = [int(c) for c in old_classes if int((labels == int(c)).sum().item()) > 0]
    if not present:
        return {}
    base = budget // len(present)
    rem = budget % len(present)
    alloc = {}
    for i, c in enumerate(present):
        alloc[c] = base + (1 if i < rem else 0)
    return alloc


def balanced_random_indices(labels: torch.Tensor, old_classes: Sequence[int], budget: int, seed: int) -> List[int]:
    rng = random.Random(seed)
    alloc = allocate_budget_by_class(labels, old_classes, budget)
    selected: List[int] = []
    for c, k in alloc.items():
        idx = torch.where(labels == c)[0].tolist()
        rng.shuffle(idx)
        selected.extend(idx[:min(k, len(idx))])
    rng.shuffle(selected)
    return selected


def sorted_take_evenly(indices: List[int], scores: torch.Tensor, k: int, reverse: bool = False) -> List[int]:
    if k <= 0 or not indices:
        return []
    if len(indices) <= k:
        return list(indices)
    idx_sorted = sorted(indices, key=lambda i: float(scores[i]), reverse=reverse)
    if k == 1:
        return [idx_sorted[len(idx_sorted) // 2]]
    picks = []
    for j in range(k):
        pos = round(j * (len(idx_sorted) - 1) / (k - 1))
        picks.append(idx_sorted[pos])
    return picks


def boundary_diverse_indices(
    stats: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    budget: int,
    seed: int,
    boundary_frac: float = 0.50,
    diverse_frac: float = 0.35,
    prototype_frac: float = 0.15,
) -> List[int]:
    """
    Stress-test selector.

    Per class, select a mix of:
      - low-margin examples: decision-boundary memories
      - diverse examples: evenly spread by embedding distance from class center
      - prototype examples: near class centers

    This is deliberately stronger than the earlier naive curated replay.
    """
    rng = random.Random(seed)
    labels = stats["labels"]
    margin = stats["margin"]
    distance = stats["distance"]
    alloc = allocate_budget_by_class(labels, old_classes, budget)
    selected: List[int] = []

    for c, k in alloc.items():
        if k <= 0:
            continue
        class_idx = torch.where(labels == c)[0].tolist()
        if len(class_idx) <= k:
            selected.extend(class_idx)
            continue

        rng.shuffle(class_idx)
        n_boundary = int(round(k * boundary_frac))
        n_diverse = int(round(k * diverse_frac))
        n_proto = k - n_boundary - n_diverse
        if n_proto < 0:
            n_proto = 0

        # 1) Low margin = ambiguous/boundary examples.
        boundary = sorted(class_idx, key=lambda i: float(margin[i]))[:n_boundary]
        used = set(boundary)
        remaining = [i for i in class_idx if i not in used]

        # 2) Diversity by selecting evenly across center-distance spectrum.
        diverse = sorted_take_evenly(remaining, distance, n_diverse, reverse=False)
        used.update(diverse)
        remaining = [i for i in remaining if i not in used]

        # 3) Prototypes near class center.
        proto = sorted(remaining, key=lambda i: float(distance[i]))[:n_proto]

        picked = boundary + diverse + proto
        if len(picked) < k:
            rest = [i for i in class_idx if i not in set(picked)]
            rng.shuffle(rest)
            picked.extend(rest[: k - len(picked)])
        selected.extend(picked[:k])

    rng.shuffle(selected)
    return selected


def pure_diverse_indices(
    stats: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    budget: int,
    seed: int,
) -> List[int]:
    labels = stats["labels"]
    distance = stats["distance"]
    alloc = allocate_budget_by_class(labels, old_classes, budget)
    rng = random.Random(seed)
    selected: List[int] = []
    for c, k in alloc.items():
        idx = torch.where(labels == c)[0].tolist()
        rng.shuffle(idx)
        selected.extend(sorted_take_evenly(idx, distance, k, reverse=False))
    rng.shuffle(selected)
    return selected


def make_replay_subset(
    train_old: Dataset,
    stats: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    budget: int,
    selector: str,
    seed: int,
) -> Optional[Dataset]:
    if budget <= 0 or selector == "none":
        return None
    labels = stats["labels"] if stats is not None else train_old.targets

    if selector == "random":
        idx = balanced_random_indices(labels, old_classes, budget, seed)
    elif selector == "diverse":
        idx = pure_diverse_indices(stats, old_classes, budget, seed)
    elif selector == "boundary_diverse":
        idx = boundary_diverse_indices(stats, old_classes, budget, seed)
    else:
        raise ValueError(f"Unknown selector: {selector}")

    return FeatureSubset(train_old, idx)


# -----------------------------
# Strategies
# -----------------------------


@dataclass
class Strategy:
    name: str
    selector: str
    use_anchor: bool = False
    use_distill: bool = False
    soft: bool = False
    distill_lambda: float = 0.0
    anchor_lambda: float = 0.0


# Lean diagnostic set.
#
# Distillation is deliberately swept from weak to strong.
# The prior combined-symbol run used strong distillation and it often hurt
# at 0.5-2% replay. This run tests whether lower distillation weights recover
# the MNIST/EMNIST benefit.
STRATEGIES = [
    # Baseline: shows catastrophic forgetting.
    Strategy("No replay", "none"),

    # Strong fair replay baselines.
    Strategy("Balanced random replay", "random"),
    Strategy("Pure diverse replay", "diverse"),
    Strategy("Boundary-diverse replay", "boundary_diverse"),

    # Dose curve for the main candidate mechanism.
    # 0.05 was the first setting that helped at ~2% replay in the exploratory run.
    # 0.70 is deliberately strong and often hurts in sparse memory.
    Strategy("Balanced random + distill 0.05", "random", use_distill=True, distill_lambda=0.05),
    Strategy("Balanced random + distill 0.15", "random", use_distill=True, distill_lambda=0.15),
    Strategy("Balanced random + distill 0.35", "random", use_distill=True, distill_lambda=0.35),
    Strategy("Balanced random + distill 0.70", "random", use_distill=True, distill_lambda=0.70),

    # A single memory-loop challenger: boundary-aware selection plus soft consolidation
    # and a weak old-self tether. This tests whether a more structured memory loop
    # beats the strong random-replay baseline without exploding the condition count.
    Strategy(
        "Boundary-diverse + soft + anchor/distill 0.15",
        "boundary_diverse",
        use_anchor=True,
        use_distill=True,
        soft=True,
        distill_lambda=0.15,
        anchor_lambda=1.0,
    ),
]

def select_strategies(names_text: Optional[str]) -> List[Strategy]:
    if not names_text:
        return STRATEGIES
    wanted = {x.strip().lower() for x in names_text.split(",") if x.strip()}
    out = [s for s in STRATEGIES if s.name.lower() in wanted]
    if not out:
        raise ValueError("No strategies matched --strategies. Use exact strategy names, comma-separated.")
    return out


# -----------------------------
# Experiment
# -----------------------------


def run_one_condition(
    strategy: Strategy,
    replay_fraction: float,
    seed: int,
    data,
    old_classes: Sequence[int],
    new_classes: Sequence[int],
    phase1_state: Dict[str, torch.Tensor],
    old_state_cpu: Dict[str, torch.Tensor],
    stats,
    old_acc_phase1: float,
    new_acc_phase1: float,
    all_acc_phase1: float,
    args,
    device: str,
) -> Dict[str, object]:
    condition_seed = seed + int(replay_fraction * 1_000_000) + stable_hash_int(strategy.name) % 100_000
    set_seed(condition_seed)

    model = SmallCNN36().to(device)
    model.load_state_dict(phase1_state)

    teacher = SmallCNN36().to(device)
    teacher.load_state_dict(phase1_state)
    teacher.eval()
    for p in teacher.parameters():
        p.requires_grad = False

    budget = budget_from_fraction(len(data["train_new"]), replay_fraction)
    replay_subset = make_replay_subset(
        train_old=data["train_old"],
        stats=stats,
        old_classes=old_classes,
        budget=budget,
        selector=strategy.selector,
        seed=condition_seed + 17,
    )

    phase2_dataset = NewPlusReplayDataset(data["train_new"], replay_subset)
    generator = torch.Generator()
    generator.manual_seed(condition_seed + 23)
    phase2_loader = DataLoader(
        phase2_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        generator=generator,
    )

    optimizer = make_optimizer(model, lr=args.lr, soft=strategy.soft)

    if not args.quiet:
        print("=" * 148)
        print(f"Seed={seed} | Replay={pct(replay_fraction)} | {strategy.name} | budget={budget} | d={strategy.distill_lambda:.2f} | a={strategy.anchor_lambda:.2f}")
        print("=" * 148)

    train_phase2(
        model=model,
        teacher=teacher,
        loader=phase2_loader,
        optimizer=optimizer,
        device=device,
        epochs=args.phase2_epochs,
        old_state=old_state_cpu,
        old_classes=old_classes,
        use_anchor=strategy.use_anchor,
        use_distill=strategy.use_distill,
        anchor_lambda=(strategy.anchor_lambda if strategy.use_anchor else 0.0),
        distill_lambda=(strategy.distill_lambda if strategy.use_distill else 0.0),
        temperature=args.temperature,
        test_old_loader=data["test_old_loader"],
        quiet=args.quiet,
    )

    old_acc_phase2 = accuracy(model, data["test_old_loader"], device)
    new_acc_phase2 = accuracy(model, data["test_new_loader"], device)
    all_acc_phase2 = accuracy(model, data["test_all_loader"], device)
    forgetting = old_acc_phase1 - old_acc_phase2
    h = harmonic_mean(old_acc_phase2, new_acc_phase2)
    stability_score = all_acc_phase2 - forgetting

    result = {
        "seed": seed,
        "strategy": strategy.name,
        "selector": strategy.selector,
        "use_anchor": strategy.use_anchor,
        "use_distill": strategy.use_distill,
        "soft": strategy.soft,
        "distill_lambda": strategy.distill_lambda if strategy.use_distill else 0.0,
        "anchor_lambda": strategy.anchor_lambda if strategy.use_anchor else 0.0,
        "replay_fraction": replay_fraction,
        "budget": budget,
        "old_acc_phase1": old_acc_phase1,
        "new_acc_phase1": new_acc_phase1,
        "all_acc_phase1": all_acc_phase1,
        "old_acc_phase2": old_acc_phase2,
        "new_acc_phase2": new_acc_phase2,
        "all_acc_phase2": all_acc_phase2,
        "forgetting": forgetting,
        "harmonic_old_new": h,
        "stability_score": stability_score,
    }

    if not args.quiet:
        print(
            f"Result | Old P2={old_acc_phase2:.4f} | New P2={new_acc_phase2:.4f} | "
            f"All P2={all_acc_phase2:.4f} | Forget={forgetting:.4f} | "
            f"Score={stability_score:.4f} | H(old,new)={h:.4f}\n"
        )

    return result


def aggregate_results(results: List[Dict[str, object]]) -> List[Dict[str, object]]:
    keys = sorted(set((r["replay_fraction"], r["strategy"]) for r in results))
    out = []
    metrics = [
        "old_acc_phase2",
        "new_acc_phase2",
        "all_acc_phase2",
        "forgetting",
        "harmonic_old_new",
        "stability_score",
    ]
    for frac, strategy in keys:
        rows = [r for r in results if r["replay_fraction"] == frac and r["strategy"] == strategy]
        rec = {"replay_fraction": frac, "strategy": strategy, "n": len(rows)}
        for m in metrics:
            vals = [float(r[m]) for r in rows]
            mean = sum(vals) / len(vals)
            if len(vals) > 1:
                var = sum((x - mean) ** 2 for x in vals) / (len(vals) - 1)
                sd = math.sqrt(var)
            else:
                sd = 0.0
            rec[m + "_mean"] = mean
            rec[m + "_sd"] = sd
        out.append(rec)
    return out


def print_summary(results: List[Dict[str, object]]) -> None:
    agg = aggregate_results(results)

    print("\n\nFINAL AGGREGATE TABLE")
    print("=" * 170)
    print(
        f"{'Replay':>8s} {'Strategy':48s} {'Old P2':>9s} {'New P2':>9s} "
        f"{'All P2':>9s} {'Forget':>9s} {'H':>9s} {'Score':>9s} {'n':>4s}"
    )
    print("-" * 170)
    for r in sorted(agg, key=lambda x: (float(x["replay_fraction"]), str(x["strategy"]))):
        print(
            f"{pct(float(r['replay_fraction'])):>8s} "
            f"{str(r['strategy']):48s} "
            f"{float(r['old_acc_phase2_mean']):9.4f} "
            f"{float(r['new_acc_phase2_mean']):9.4f} "
            f"{float(r['all_acc_phase2_mean']):9.4f} "
            f"{float(r['forgetting_mean']):9.4f} "
            f"{float(r['harmonic_old_new_mean']):9.4f} "
            f"{float(r['stability_score_mean']):9.4f} "
            f"{int(r['n']):4d}"
        )

    print("\n\nBEST BY REPLAY FRACTION")
    print("=" * 170)
    print("Sorted by harmonic mean of old/new accuracy, then stability_score.")
    for frac in sorted(set(float(r["replay_fraction"]) for r in results)):
        rows = [r for r in agg if float(r["replay_fraction"]) == frac]
        rows = sorted(rows, key=lambda x: (float(x["harmonic_old_new_mean"]), float(x["stability_score_mean"])), reverse=True)
        b = rows[0]
        print(
            f"Replay {pct(frac)} | best: {b['strategy']} | "
            f"Old={float(b['old_acc_phase2_mean']):.4f} | "
            f"New={float(b['new_acc_phase2_mean']):.4f} | "
            f"All={float(b['all_acc_phase2_mean']):.4f} | "
            f"Forget={float(b['forgetting_mean']):.4f} | "
            f"H={float(b['harmonic_old_new_mean']):.4f} | "
            f"Score={float(b['stability_score_mean']):.4f}"
        )


def save_csv(path: str, rows: List[Dict[str, object]]) -> None:
    if not rows:
        return
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def save_agg_csv(path: str, rows: List[Dict[str, object]]) -> None:
    agg = aggregate_results(rows)
    if not agg:
        return
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(agg[0].keys()))
        writer.writeheader()
        writer.writerows(agg)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=str, default="./data")
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--phase1-epochs", type=int, default=3)
    parser.add_argument("--phase2-epochs", type=int, default=3)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--anchor-lambda", type=float, default=5.0, help="Legacy/global value; strategies in this script use strategy-specific anchor weights.")
    parser.add_argument("--distill-lambda", type=float, default=0.7, help="Legacy/global value; strategies in this script use strategy-specific distill weights.")
    parser.add_argument("--temperature", type=float, default=2.0)
    parser.add_argument("--held-out", type=str, default=",".join(DEFAULT_HELD_OUT))
    parser.add_argument("--replay-fractions", type=str, default="0,0.005,0.01,0.02,0.05,0.10,0.20,0.35")
    parser.add_argument("--seeds", type=str, default="42,43,44")
    parser.add_argument("--max-train-per-class", type=int, default=0, help="0 = no cap")
    parser.add_argument("--max-test-per-class", type=int, default=0, help="0 = no cap")
    parser.add_argument("--no-emnist-orientation-fix", action="store_true")
    parser.add_argument("--strategies", type=str, default=None, help="Optional comma-separated exact strategy names")
    parser.add_argument("--csv", type=str, default="symbols_paper_core_results.csv")
    parser.add_argument("--agg-csv", type=str, default="symbols_paper_core_aggregate.csv")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"

    held_out = parse_symbols(args.held_out)
    all_classes = list(range(N_CLASSES))
    new_classes = sorted(set(held_out))
    old_classes = [c for c in all_classes if c not in set(new_classes)]
    replay_fractions = parse_float_list(args.replay_fractions)
    seeds = parse_int_list(args.seeds)
    strategies = select_strategies(args.strategies)

    max_train_per_class = args.max_train_per_class if args.max_train_per_class > 0 else None
    max_test_per_class = args.max_test_per_class if args.max_test_per_class > 0 else None

    print(f"Device:                  {device}")
    print(f"Classes:                 digits 0-9 + letters A-Z = {N_CLASSES}")
    print(f"Old symbols:             {symbols_string(old_classes)}")
    print(f"Held-out symbols:        {symbols_string(new_classes)}")
    print(f"Old class count:         {len(old_classes)}")
    print(f"Held-out class count:    {len(new_classes)}")
    print(f"Replay fractions:        {replay_fractions}")
    print(f"Seeds:                   {seeds}")
    print(f"Phase 1 epochs:          {args.phase1_epochs}")
    print(f"Phase 2 epochs:          {args.phase2_epochs}")
    print(f"Strategies:              {len(strategies)}")
    print("Dataset:                 MNIST digits + EMNIST Letters")
    print("Replay baselines:        class-balanced random, pure diverse, boundary-diverse")
    print("Diagnostic axis:         paper-core density/distillation transition")
    print()

    all_results: List[Dict[str, object]] = []

    for seed in seeds:
        set_seed(seed)
        data = make_data_splits(
            data_dir=args.data_dir,
            old_classes=old_classes,
            new_classes=new_classes,
            batch_size=args.batch_size,
            seed=seed,
            max_train_per_class=max_train_per_class,
            max_test_per_class=max_test_per_class,
            fix_emnist_orientation=not args.no_emnist_orientation_fix,
        )
        print(f"Train old examples:      {len(data['train_old'])}")
        print(f"Train new examples:      {len(data['train_new'])}")
        print(f"Test old examples:       {len(data['test_old'])}")
        print(f"Test new examples:       {len(data['test_new'])}")
        print()

        print("#" * 120)
        print(f"PHASE 1: train one conventional CNN on old symbols only | seed={seed}")
        print("#" * 120)

        model = SmallCNN36().to(device)
        opt = make_optimizer(model, lr=args.lr, soft=False)
        train_phase1(
            model=model,
            loader=data["train_old_loader"],
            optimizer=opt,
            device=device,
            old_classes=old_classes,
            epochs=args.phase1_epochs,
            test_old_loader=data["test_old_loader"],
        )

        old_acc_phase1 = accuracy(model, data["test_old_loader"], device)
        new_acc_phase1 = accuracy(model, data["test_new_loader"], device)
        all_acc_phase1 = accuracy(model, data["test_all_loader"], device)

        print(
            f"Phase 1 saved state | old={old_acc_phase1:.4f} | "
            f"new={new_acc_phase1:.4f} | all={all_acc_phase1:.4f}"
        )

        phase1_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        old_state_cpu = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

        print("Collecting old-model feature/logit statistics for replay selection...")
        stats = collect_old_model_stats(
            model=model,
            train_old=data["train_old"],
            old_classes=old_classes,
            batch_size=args.batch_size,
            device=device,
        )
        print("Stats collected.")

        for replay_fraction in replay_fractions:
            for strategy in strategies:
                result = run_one_condition(
                    strategy=strategy,
                    replay_fraction=replay_fraction,
                    seed=seed,
                    data=data,
                    old_classes=old_classes,
                    new_classes=new_classes,
                    phase1_state=phase1_state,
                    old_state_cpu=old_state_cpu,
                    stats=stats,
                    old_acc_phase1=old_acc_phase1,
                    new_acc_phase1=new_acc_phase1,
                    all_acc_phase1=all_acc_phase1,
                    args=args,
                    device=device,
                )
                all_results.append(result)
                save_csv(args.csv, all_results)
                save_agg_csv(args.agg_csv, all_results)

    print_summary(all_results)
    save_csv(args.csv, all_results)
    save_agg_csv(args.agg_csv, all_results)
    print(f"\nSaved per-run results to: {args.csv}")
    print(f"Saved aggregate results to: {args.agg_csv}")


if __name__ == "__main__":
    main()

```
