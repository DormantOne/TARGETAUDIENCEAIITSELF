# Replay Density and Lifelong Learning Bundle

This bundle contains a reproducibility manuscript and all programs used or produced during the experiment sequence.

## Contents

- `MANUSCRIPT.md` — full integrated write-up.
- `CODE_APPENDIX.md` — verbatim code listing of all included programs.
- `programs/` — runnable Python and Windows batch files.
- `corpus/` — staged text corpus for the tiny lifelong LLM GUI.
- `tables/` — derived aggregate CSV tables from the 36-symbol paper-core run.
- `logs/` — copied run logs/pasted console outputs.

## Recommended environment

Python 3.10+ with PyTorch and torchvision.

For the tiny LLM GUI:

```bash
pip install torch
python programs/lifelong_gui.py
```

For the core symbol paper run:

```bash
python programs/symbols_paper_core_run.py
```

The scripts download MNIST/EMNIST through torchvision as needed.

## Reproducing the central result

Run:

```bash
python programs/symbols_paper_core_run.py
```

Expected design:

- 36 total classes: MNIST digits 0-9 + EMNIST letters A-Z
- Old classes: 25 symbols
- Held-out classes: 11 symbols
- Seeds: 42, 43, 44
- Replay fractions: 0, 0.5, 1, 2, 5, 10, 20, 35 percent
- Strategies: 9 replay/distillation variants

The central result is a replay-density transition: balanced random replay wins at 0.5-1%, weak distillation wins at 2-10%, stronger distillation wins at 20%, and boundary-diverse replay wins at 35%.
