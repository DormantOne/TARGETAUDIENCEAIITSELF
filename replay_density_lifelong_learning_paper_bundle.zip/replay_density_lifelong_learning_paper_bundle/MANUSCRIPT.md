# Replay Density, Old-Self Preservation, and the First Toy Step Toward Lifelong Agent Learning

**A reproducible research note combining class-incremental symbol learning, replay-density experiments, and a laughably small lifelong language-model organism**

**Draft date:** 2026-06-27  
**Status:** reproducibility manuscript / workshop-style communication draft  
**Code:** included in `programs/` and reproduced verbatim in `CODE_APPENDIX.md`

---

## Abstract

Continual learning requires a model to acquire new competence without destroying older competence. This bundle reports a sequence of deliberately small experiments that begin with handwritten-symbol class-incremental learning and extend to a toy byte-level language model with replay, old-self distillation, and a graphical milestone interface. The empirical core is a 36-class digit-letter task combining MNIST digits and EMNIST letters. A convolutional network first learns 25 old symbols and then learns 11 held-out symbols under replay budgets from 0% to 35%. The best method changes with replay density. At 0.5–1% replay, class-balanced random replay performs best. At 2–10%, weak teacher-logit distillation over replay examples becomes best. At 20%, slightly stronger distillation is best. At 35%, boundary-diverse replay becomes best. This supports a replay-density transition: sparse memory favors coverage, intermediate memory favors old-output-geometry preservation, and dense memory permits structured exemplar selection. The same design principle is then instantiated in a toy lifelong byte-level transformer that learns through sequential text corpora while periodically replaying old chunks and producing milestone completions. The language model is not presented as useful or intelligent; it is a glass-box organism for studying memory loops. The final section sketches a future architecture of per-machine agent learners, shared corpus pools, and a still-undetermined agent-junction layer that may eventually support controlled collective learning without uncontrolled collapse into either forgetting or rigid imitation.

---

## 1. The central question

The question is simple enough to be dangerous:

> Can a model continue learning without forgetting what it previously learned?

In these experiments, the answer is:

> Yes in a narrow, controlled, first-step sense — but only when memory density and preservation force are matched.

A model trained sequentially without replay generally fails. It learns the new task but loses old competence. In the first MNIST split experiment, a regular CNN learned old digits with phase-1 old accuracy 0.9937, then after learning new digits without replay fell to old accuracy 0.0023 while new accuracy rose to 0.9976. This is catastrophic forgetting in its cleanest form.

The later experiments show that replay changes this. Replay alone helps. Replay plus distillation sometimes helps more. But the surprising result is conditional: distillation is not universally beneficial. It has a dose curve and a memory-density dependence.

---

## 2. Background and related work

This work sits in the continual-learning tradition. Catastrophic forgetting is the loss of old-task competence after sequential training on new data. Several broad strategies have been studied:

1. **Replay or rehearsal.** Store old examples and interleave them with new examples.
2. **Distillation.** Preserve old behavior by matching an older teacher model's output distribution.
3. **Parameter anchoring or regularization.** Penalize changes to weights believed to matter for prior tasks.
4. **Memory selection.** Choose which old examples are worth preserving under limited memory.

Learning without Forgetting used distillation-like output preservation to retain old-task capabilities while learning new tasks. Elastic Weight Consolidation protected weights important to previous tasks. Dark Experience Replay combined replay with logit matching and became a strong simple baseline for continual learning. EMNIST extends MNIST-style 28×28 handwriting recognition to letters and digit-letter variants, making it convenient for transparent symbol experiments.

This note does not claim novelty for replay, distillation, or anchoring. The contribution is narrower: a reproducible toy demonstration that the *best* preservation method depends on replay density.

---

## 3. Conceptual model: the three memory-density regimes

The experiments suggest three regimes.

### 3.1 Coverage-dominated memory

When the buffer is extremely sparse, the model barely has enough old examples to cover old classes. At this density, class-balanced random replay can beat distillation. The model's first need is not nuanced imitation of the old model; it is enough old-class evidence to avoid total collapse.

### 3.2 Geometry-preservation memory

Once the buffer is large enough to represent old classes coarsely, weak distillation begins to help. Distillation preserves more than labels. It preserves part of the teacher's output geometry: relative class confidence, uncertainty, and confusability structure.

### 3.3 Structure-selection memory

At higher memory density, there are enough old examples to choose structure within each old class. Boundary-diverse replay can become competitive or best, because the memory can now represent not only class coverage but also class shape and decision boundaries.

This is the paper's main thesis:

> Continual-learning methods should be evaluated across replay-density curves. A method that helps at 10% replay may hurt at 0.5% replay; a selector that is useless at 1% replay may become useful at 35% replay.

---

## 4. Experiment 1: MNIST old/new split and the failure of learning-rate layering alone

### 4.1 Design

Old digits: 0, 1, 2, 4, 5, 7, 8  
Held-out digits: 3, 6, 9

The first test compared a regular CNN with front-fast/back-slow and front-slow/back-fast learning-rate schedules. Phase 1 trained on old digits only. Phase 2 trained on new digits only.

### 4.2 Result

All variants catastrophically forgot old digits without replay. The regular CNN moved from old accuracy 0.9937 after phase 1 to old accuracy 0.0023 after phase 2, while new accuracy reached 0.9976. Learning-rate layering alone did not prevent forgetting.

### 4.3 Interpretation

The model was not unable to learn. It learned the new task very well. It failed because new learning overwrote functional access to the old task.

This established the first rule:

> Layer-speed tricks alone are not enough. The model needs memory.

---

## 5. Experiment 2: MNIST replay, anchor, and distillation

### 5.1 Design

The next MNIST experiment added replay, soft consolidation, anchor penalties, and old-teacher distillation. The best-performing memory-loop condition combined curated replay, soft consolidation, and anchor/distill.

### 5.2 Key result

In the MNIST memory-loop experiment, the curated + soft consolidation + anchor/distill condition achieved:

| Replay | Old P2 | New P2 | All P2 | Forget | Score |
|---:|---:|---:|---:|---:|---:|
| 2% | 0.9664 | 0.9825 | 0.9712 | 0.0258 | 0.9454 |
| 5% | 0.9759 | 0.9832 | 0.9781 | 0.0162 | 0.9619 |
| 10% | 0.9865 | 0.9835 | 0.9856 | 0.0057 | 0.9799 |
| 20% | 0.9906 | 0.9788 | 0.9871 | 0.0016 | 0.9855 |

### 5.3 Interpretation

MNIST suggested that tiny replay plus old-self preservation could largely prevent catastrophic forgetting. But MNIST is easy and may overstate the generality of the effect. We therefore moved to letters and mixed digit-letter symbols.

---

## 6. Experiment 3: EMNIST Letters

### 6.1 Design

Old letters: A, B, D, E, G, H, I, K, L, M, N, O, P, R, S, T, U, W  
Held-out letters: C, F, J, Q, V, X, Y, Z

The EMNIST run used a CNN with the same basic phase-1 / phase-2 structure. Phase 1 trained on 18 old letters; phase 2 trained on eight held-out letters with replay and preservation variants.

### 6.2 Key result

Phase 1 old-letter accuracy reached 0.9281. With no replay, old-letter accuracy collapsed to about 0.001 while new-letter accuracy reached about 0.982. At nonzero replay, replay plus distillation became useful. At 20% replay, random replay + soft + anchor/distill produced Old P2 0.9127, New P2 0.9241, All P2 0.9162, Forget 0.0153.

### 6.3 Interpretation

EMNIST Letters confirmed the general forgetting pattern and showed that old-self preservation could still help in a more difficult alphabetic task. However, the single-seed letter experiment also showed that naive curation could underperform random replay, suggesting that memory selection itself needed to be stressed.

---

## 7. Experiment 4: 36-class digit-letter replay-density transition

### 7.1 Dataset

The final symbol experiment combined MNIST digits 0–9 with EMNIST letters A–Z for 36 total classes.

Old symbols:

0, 1, 2, 4, 5, 7, 8, A, B, D, E, G, H, I, K, L, M, N, O, P, R, S, T, U, W

Held-out symbols:

3, 6, 9, C, F, J, Q, V, X, Y, Z

There were 25 old classes and 11 held-out classes. The paper-core run used three seeds, replay fractions 0%, 0.5%, 1%, 2%, 5%, 10%, 20%, and 35%, and nine strategies.

### 7.2 Replay budgets

Replay budget was defined as a percentage of the new-task training size. In absolute terms:

| Replay | Total replay examples | Approx samples per old class |
|---:|---:|---:|
| 0.5% | 283 | 11.3 |
| 1% | 569 | 22.8 |
| 2% | 1150 | 46.0 |
| 5% | 2968 | 118.7 |
| 10% | 6266 | 250.6 |
| 20% | 14099 | 564.0 |
| 35% | 30368 | 1214.7 |

This makes the term "sparse replay" concrete: at 0.5%, the model sees only about 11 old examples per old class.

### 7.3 Strategies

The core strategies were:

1. No replay
2. Class-balanced random replay
3. Pure diverse replay
4. Boundary-diverse replay
5. Balanced random + distill 0.05
6. Balanced random + distill 0.15
7. Balanced random + distill 0.35
8. Balanced random + distill 0.70
9. Boundary-diverse + soft + anchor/distill 0.15

### 7.4 Results

| Replay | Replay examples | Approx SPC | Best method | H | Second-best H | Delta H | Old | New | Forget |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0.50% | 283 | 11.3 | Balanced random replay | 0.6691 ± 0.0154 | 0.6600 ± 0.0467 | 0.0090 | 0.5068 ± 0.0175 | 0.9844 ± 0.0009 | 0.4454 ± 0.0151 |
| 1.00% | 569 | 22.8 | Balanced random replay | 0.7870 ± 0.0070 | 0.7586 ± 0.0177 | 0.0284 | 0.6559 ± 0.0098 | 0.9837 ± 0.0015 | 0.2964 ± 0.0072 |
| 2.00% | 1150 | 46.0 | Balanced random + distill 0.05 | 0.8417 ± 0.0081 | 0.8324 ± 0.0075 | 0.0093 | 0.7351 ± 0.0133 | 0.9846 ± 0.0017 | 0.2172 ± 0.0160 |
| 5.00% | 2968 | 118.7 | Balanced random + distill 0.05 | 0.8987 ± 0.0072 | 0.8977 ± 0.0119 | 0.0010 | 0.8274 ± 0.0115 | 0.9836 ± 0.0010 | 0.1249 ± 0.0159 |
| 10.00% | 6266 | 250.6 | Balanced random + distill 0.05 | 0.9236 ± 0.0010 | 0.9227 ± 0.0079 | 0.0009 | 0.8721 ± 0.0026 | 0.9816 ± 0.0012 | 0.0802 ± 0.0050 |
| 20.00% | 14099 | 564.0 | Balanced random + distill 0.15 | 0.9441 ± 0.0015 | 0.9433 ± 0.0027 | 0.0008 | 0.9155 ± 0.0040 | 0.9745 ± 0.0015 | 0.0367 ± 0.0071 |
| 35.00% | 30368 | 1214.7 | Boundary-diverse replay | 0.9509 ± 0.0019 | 0.9503 ± 0.0007 | 0.0005 | 0.9324 ± 0.0043 | 0.9700 ± 0.0014 | 0.0198 ± 0.0015 |

### 7.5 Interpretation

The result is the memory-density transition.

At 0.5–1%, balanced random replay is best. At 2–10%, balanced random + weak distillation 0.05 is best. At 20%, balanced random + distill 0.15 is best. At 35%, boundary-diverse replay is best.

Strong distillation does not simply improve retention. At low memory density, strong distillation can hurt. It appears to constrain the model around a sparse and incomplete memory sample.

---

## 8. Mathematical definitions

Let the frozen phase-1 teacher be \(f_T\), the phase-2 student be \(f_S\), and an old replay example be \((x_i, y_i)\). Let:

\[
z_i = h_T(x_i)
\]

where \(h_T\) is the penultimate feature embedding of the teacher. Let:

\[
p_i = \mathrm{softmax}(f_T(x_i))
\]

restricted to old classes. Define the top-two probability margin:

\[
m_i = p_i^{(1)} - p_i^{(2)}
\]

where \(p_i^{(1)}\) and \(p_i^{(2)}\) are the largest and second-largest old-class probabilities. Low margin means the old model considered the example near a decision boundary.

For class \(c\), define the class centroid:

\[
\mu_c = rac{1}{|D_c|}\sum_{x_i \in D_c} z_i
\]

and distance from centroid:

\[
d_i = \|z_i - \mu_c\|_2.
\]

### 8.1 Class-balanced random replay

For replay budget \(B\) and \(C_{old}\) old classes, allocate approximately \(B/C_{old}\) examples per old class and sample uniformly within class.

### 8.2 Pure diverse replay

Within each old class, compute \(d_i\) for all examples and sample across the distance spectrum so that the replay buffer covers feature-space variation rather than only class centers.

### 8.3 Boundary-diverse replay

Within each old class, allocate replay approximately as:

- 50% low-margin examples, using smallest \(m_i\)
- 35% feature-diverse examples, spanning \(d_i\)
- 15% prototypes, closest to \(\mu_c\)

The intention is to preserve both boundary cases and clean class anchors.

### 8.4 Distillation

For replay examples, the teacher logits over old classes are \(t_{old}\), and student logits over old classes are \(s_{old}\). With temperature \(T\), the distillation loss is:

\[
L_{distill} = T^2 \; \mathrm{KL}\left(\mathrm{softmax}(t_{old}/T) \;\|\; \mathrm{softmax}(s_{old}/T)ight).
\]

The total phase-2 loss is:

\[
L = L_{CE} + \lambda_d L_{distill} + \lambda_a L_{anchor}.
\]

When used, the anchor loss is:

\[
L_{anchor} = \sum_j \|	heta_j - 	heta_j^{(phase1)}\|_2^2.
\]

---

## 9. The toy lifelong language model

The symbol experiments were then translated into a tiny language-model organism. This is not a useful LLM. It is a laboratory animal.

The model is a byte-level transformer. It reads a sequence of `.txt` files as phases. After each phase, it stores replay chunks. During each new phase it trains on new chunks mixed with old replay chunks. It may also distill from a frozen old-self teacher on replay chunks.

The included GUI shows:

- live training loss
- replay memory size
- phase milestones
- evaluation loss on seen phases
- fixed-prompt completions after milestones

A representative milestone after five phases showed low evaluation losses on all seen phases and fixed-prompt completions that preserved anchors such as "The red key opens the moon gate" and "even plus even is even." The same output also showed limitations: arithmetic was not truly learned, and code completions were syntax-like but not semantically correct.

This is exactly the expected behavior of a tiny lifelong learner:

> It remembers old songs, learns new songs, blends them imperfectly, and fails when asked for reasoning beyond memorized structure.

---

## 10. Reproducibility

All programs are included in `programs/` and reproduced in `CODE_APPENDIX.md`. The main commands are:

### 10.1 MNIST replay baseline

```bash
python fastslow_full.py
```

### 10.2 MNIST memory-loop experiment

```bash
python mnist_memory_loop_compare.py
```

### 10.3 MNIST ablation

```bash
python mnist_ablation_next.py
```

### 10.4 EMNIST Letters ablation

```bash
python emnist_alphabet_ablation.py
```

### 10.5 Mixed 36-symbol diverse replay

```bash
python symbols_micro_replay_diverse.py
```

### 10.6 Distillation-density sweep

```bash
python symbols_density_distill_sweep.py
```

### 10.7 Paper-core 36-symbol run

```bash
python symbols_paper_core_run.py
```

### 10.8 Tiny lifelong LLM command-line run

```bash
python micro_lifelong_llm.py --make-demo-corpus --corpus-dir demo_corpus --steps-per-phase 400 --memory-per-phase 300 --generate-every-phase
```

### 10.9 Tiny lifelong LLM GUI

```bash
python lifelong_gui.py
```

or on Windows:

```bat
run_gui.bat
```

---

## 11. Limitations

The experiments are intentionally small. The main symbol experiment is single-transition class-incremental learning, not multi-step lifelong learning. The 36-symbol task is transparent and useful but not a natural-image benchmark. The language model is far too small to claim semantic reasoning. Evaluation of the toy LLM is partly on training-like text and should be expanded with held-out phase-specific corpora.

The strongest empirical claim is therefore modest:

> In a controlled symbol task, the best method for avoiding forgetting changes with replay density.

The strongest conceptual claim is broader but still speculative:

> Long-term learning systems likely need multiple memory mechanisms operating at different densities, timescales, and preservation strengths.

---

## 12. Future direction: per-machine learners, shared corpora, and an agent junction

The toy LLM suggests a future architecture that is neither one giant retrained model nor isolated chat memories.

### 12.1 Per-machine agent learners

Each machine or user environment could host a local agent learner. This learner would collect local experience, maintain local replay memory, evaluate its own forgetting, and tune preservation strength based on memory density.

This local learner would not necessarily update a frontier model directly. It might instead maintain:

- local episodic memory
- local semantic summaries
- local failure cases
- local task-specific adapters
- local replay buffers
- local model-evaluation probes

### 12.2 Shared corpus pools

Multiple local learners could contribute selected memories or distilled lessons to a shared corpus. The shared corpus would not be a raw dump of everything. It would need filters:

- privacy filters
- provenance tracking
- source quality scoring
- contradiction detection
- task relevance tagging
- temporal decay rules
- replay value estimates

The shared corpus becomes a public or institutional memory substrate.

### 12.3 The agent junction

Between local learners and the shared corpus there may need to be an agent junction: a still-undetermined coordination layer that decides what should be shared, what should remain local, what should be consolidated, and what should be rejected.

This agent junction is the beginning of a controlled hive mind, but the phrase must be handled carefully. The goal is not a swarm that blindly merges all experience. The goal is a memory-governed collective learner that can share useful structure without erasing local context, violating privacy, or amplifying falsehood.

The junction might perform:

- memory triage
- conflict arbitration
- replay scheduling
- local-to-global abstraction
- global-to-local curriculum delivery
- audit trails
- rollback and quarantine
- consensus only where consensus is justified

In this architecture, lifelong learning becomes a multi-level system:

```text
local agent experience
    → local replay and evaluation
        → candidate memory export
            → agent junction review
                → shared corpus consolidation
                    → curated replay back to local learners
                        → optional adapter/model update
```

The future question is not merely whether a model can remember. It is whether many learning agents can remember together without becoming brittle, delusional, or homogenized.

---

## 13. Conclusion

These experiments began with a simple failure: a CNN learned new digits and forgot old ones. Replay repaired part of the failure. Distillation repaired more, but only under the right memory density. In the final 36-symbol experiment, the best strategy changed across replay budgets: class-balanced random replay won at extreme sparsity, weak distillation won at intermediate density, and boundary-diverse replay won at high density.

The toy lifelong LLM translated this into a sequential text learner with replay, old-self distillation, and visible milestone completions. It is laughably small, but it is alive in the experimental sense: it learns in phases, remembers prior material through replay, and reveals both retention and failure.

The broader program is to build models and agents that can keep learning without becoming someone else.

---

## References

Li, Z., & Hoiem, D. Learning without Forgetting. ECCV, 2016.

Kirkpatrick, J., Pascanu, R., Rabinowitz, N., et al. Overcoming catastrophic forgetting in neural networks. Proceedings of the National Academy of Sciences, 2017.

Buzzega, P., Boschini, M., Porrello, A., Abati, D., & Calderara, S. Dark Experience for General Continual Learning: a Strong, Simple Baseline. NeurIPS, 2020.

Cohen, G., Afshar, S., Tapson, J., & van Schaik, A. EMNIST: Extending MNIST to handwritten letters. 2017.

---

## Footnotes

[^1]: **Catastrophic forgetting** means a model loses old-task competence after being trained on new data. In these experiments, it appears as near-zero old-class accuracy after phase 2 despite high new-class accuracy.

[^2]: **Replay** means mixing stored old examples into new training. This is the simplest artificial equivalent of rehearsal.

[^3]: **Distillation** means training the new model to imitate a frozen earlier model. It can preserve old output geometry, not just old hard labels.

[^4]: **Output geometry** means the pattern of relative confidence across classes. For example, an old model may know that O and Q are more confusable than O and T.

[^5]: **Memory density** is the amount of old evidence available per old class or per old distributional region. At 0.5% replay here, the model has only about 11 old examples per old class.

[^6]: **Agent junction** is a speculative coordination layer for future agent systems. It is not implemented here. It names the open problem of deciding what local learners should share, consolidate, reject, or replay.
