@echo off
cd /d "%~dp0"
python lifelong_gui.py
pause
