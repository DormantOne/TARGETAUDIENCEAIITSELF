#!/usr/bin/env python3
"""
lifelong_gui.py

Tkinter GUI for the toy byte-level lifelong LLM.

It trains a laughably small Transformer over a staged .txt corpus. Each .txt file
is one learning phase. The GUI shows live logs plus milestone completions on
fixed prompts so you can watch the model learn new text while being tested on
old anchors.
"""

from __future__ import annotations

import copy
import csv
import json
import math
import os
import queue
import random
import subprocess
import sys
import threading
import time
import traceback
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Dict, List

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
except Exception as exc:  # pragma: no cover
    raise SystemExit(f"Tkinter could not be loaded: {exc}")

try:
    import torch
    import torch.nn.functional as F
except Exception as exc:  # pragma: no cover
    torch = None
    TORCH_IMPORT_ERROR = exc
else:
    TORCH_IMPORT_ERROR = None

# Local core. This file is included in the ZIP.
try:
    import micro_lifelong_llm as core
except Exception as exc:  # pragma: no cover
    core = None
    CORE_IMPORT_ERROR = exc
else:
    CORE_IMPORT_ERROR = None


APP_DIR = Path(__file__).resolve().parent
DEFAULT_CORPUS = APP_DIR / "corpus"
DEFAULT_OUT = APP_DIR / "runs_gui_lifelong"


@dataclass
class GUIConfig:
    corpus_dir: Path
    out_dir: Path
    seed: int
    device_choice: str
    block_size: int
    n_embd: int
    n_head: int
    n_layer: int
    dropout: float
    steps_per_phase: int
    batch_size: int
    replay_batch: int
    lr: float
    weight_decay: float
    replay_ce_weight: float
    distill_weight: float
    temperature: float
    anchor_weight: float
    memory_per_phase: int
    memory_policy: str
    eval_batches: int
    print_every: int
    milestone_every: int
    gen_tokens: int
    prompts: List[str]
    max_chars_per_file: int | None


def open_folder(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    try:
        if sys.platform.startswith("win"):
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except Exception:
        pass


def put(q: queue.Queue, kind: str, text: str) -> None:
    q.put({"kind": kind, "text": text, "time": time.strftime("%H:%M:%S")})


def choose_device(choice: str):
    if choice == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(choice)


def make_args_from_config(cfg: GUIConfig) -> SimpleNamespace:
    # Shape matches the fields used by the core training functions.
    return SimpleNamespace(
        lr=cfg.lr,
        weight_decay=cfg.weight_decay,
        anchor_weight=cfg.anchor_weight,
        distill_weight=cfg.distill_weight,
        temperature=cfg.temperature,
        steps_per_phase=cfg.steps_per_phase,
        batch_size=cfg.batch_size,
        replay_batch=cfg.replay_batch,
        replay_ce_weight=cfg.replay_ce_weight,
        grad_clip=1.0,
        eval_batches=cfg.eval_batches,
        print_every=cfg.print_every,
        memory_per_phase=cfg.memory_per_phase,
        memory_policy=cfg.memory_policy,
    )


def auto_distill_lambda(distill_weight: float, memory_chunks: int, phase_index: int) -> float:
    """Same idea as the CLI: choose old-self pressure from memory density."""
    if distill_weight >= 0:
        return distill_weight
    spc_proxy = memory_chunks / max(1, phase_index) if phase_index > 0 else 0
    if spc_proxy < 200:
        return 0.0
    if spc_proxy < 900:
        return 0.05
    return 0.15


@torch.no_grad()
def evaluate_seen(model, phases, seen_until: int, device, batch_size: int, eval_batches: int) -> Dict[str, float]:
    out: Dict[str, float] = {}
    for i in range(seen_until + 1):
        loss = core.estimate_loss(
            model,
            phases[i]["chunks"],
            device,
            eval_batches=max(1, eval_batches),
            batch_size=max(1, batch_size),
        )
        out[f"phase_{i:02d}_{phases[i]['name']}_loss"] = loss
        out[f"phase_{i:02d}_{phases[i]['name']}_ppl"] = math.exp(min(loss, 20))
    return out


def render_eval(eval_dict: Dict[str, float]) -> str:
    lines = []
    for k in sorted(eval_dict.keys()):
        if k.endswith("_loss"):
            base = k[:-5]
            ppl = eval_dict.get(base + "_ppl", float("nan"))
            lines.append(f"  {base}: loss {eval_dict[k]:.4f} | ppl {ppl:.2f}")
    return "\n".join(lines)


def generate_milestone_text(model, prompts: List[str], device, gen_tokens: int) -> str:
    lines = []
    for prompt in prompts:
        prompt = prompt.strip()
        if not prompt:
            continue
        try:
            sample = model.generate(prompt, max_new_tokens=gen_tokens, temperature=0.85, top_k=60, device=str(device))
        except Exception as exc:
            sample = f"[generation failed: {exc}]"
        lines.append(f"PROMPT: {prompt}\n{sample}\n")
    return "\n".join(lines).strip()


def train_lifelong(cfg: GUIConfig, q: queue.Queue, stop_event: threading.Event) -> None:
    if torch is None:
        raise RuntimeError(f"PyTorch could not be imported: {TORCH_IMPORT_ERROR}")
    if core is None:
        raise RuntimeError(f"Core module could not be imported: {CORE_IMPORT_ERROR}")

    cfg.out_dir.mkdir(parents=True, exist_ok=True)
    (cfg.out_dir / "gui_config.json").write_text(json.dumps({
        k: str(v) if isinstance(v, Path) else v for k, v in cfg.__dict__.items()
    }, indent=2), encoding="utf-8")

    core.set_seed(cfg.seed)
    device = choose_device(cfg.device_choice)
    put(q, "log", f"Device: {device}")
    put(q, "log", f"Corpus: {cfg.corpus_dir}")
    put(q, "log", f"Output: {cfg.out_dir}")

    max_chars = cfg.max_chars_per_file if cfg.max_chars_per_file and cfg.max_chars_per_file > 0 else None
    phases = core.load_phases(cfg.corpus_dir, block_size=cfg.block_size, max_chars_per_file=max_chars)
    put(q, "milestone", "Loaded phases:\n" + "\n".join(
        f"  {ph['id']:02d}: {ph['name']} | chars={len(ph['text'])} | chunks={len(ph['chunks'])}"
        for ph in phases
    ))

    model = core.TinyGPT(
        block_size=cfg.block_size,
        n_embd=cfg.n_embd,
        n_head=cfg.n_head,
        n_layer=cfg.n_layer,
        dropout=cfg.dropout,
    ).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    put(q, "log", f"Model parameters: {n_params:,} ({n_params/1e6:.3f}M)")

    args = make_args_from_config(cfg)
    memory_by_phase: Dict[int, List[torch.Tensor]] = {}
    train_csv = cfg.out_dir / "training_log.csv"
    eval_csv = cfg.out_dir / "milestone_eval_log.csv"

    train_fields = [
        "phase", "phase_name", "step", "loss", "ce_current", "ce_replay",
        "distill", "lambda_distill", "anchor", "memory_chunks",
    ]
    eval_rows: List[Dict[str, object]] = []

    with train_csv.open("w", newline="", encoding="utf-8") as tf:
        tw = csv.DictWriter(tf, fieldnames=train_fields)
        tw.writeheader()

        for phase_index, phase in enumerate(phases):
            if stop_event.is_set():
                put(q, "log", "Training stopped by user.")
                break

            put(q, "milestone", "\n" + "#" * 72 + f"\nPHASE {phase_index}: learning {phase['name']}\n" + "#" * 72)
            old_teacher = None
            if phase_index > 0:
                old_teacher = copy.deepcopy(model).to(device)
                old_teacher.eval()
                for p in old_teacher.parameters():
                    p.requires_grad_(False)

            all_memory: List[torch.Tensor] = []
            for chunks in memory_by_phase.values():
                all_memory.extend(chunks)
            lambda_d = auto_distill_lambda(cfg.distill_weight, len(all_memory), phase_index)
            put(q, "log", f"Phase {phase_index}: replay memory={len(all_memory)} chunks | lambda_distill={lambda_d:.3f}")

            optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
            old_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()} if cfg.anchor_weight > 0 else None
            current_chunks = phase["chunks"]
            replay_available = len(all_memory) > 0 and cfg.replay_batch > 0

            for step in range(1, cfg.steps_per_phase + 1):
                if stop_event.is_set():
                    put(q, "log", "Training stopped by user.")
                    break

                model.train()
                optimizer.zero_grad(set_to_none=True)
                x_cur, y_cur = core.sample_batch(current_chunks, cfg.batch_size, device)
                logits_cur, ce_cur = model(x_cur, y_cur)
                loss = ce_cur
                ce_replay = torch.tensor(0.0, device=device)
                dloss = torch.tensor(0.0, device=device)
                aloss = torch.tensor(0.0, device=device)

                if replay_available:
                    x_rep, y_rep = core.sample_batch(all_memory, cfg.replay_batch, device)
                    logits_rep, ce_replay = model(x_rep, y_rep)
                    loss = loss + cfg.replay_ce_weight * ce_replay
                    if old_teacher is not None and lambda_d > 0:
                        with torch.no_grad():
                            teacher_logits, _ = old_teacher(x_rep)
                        dloss = core.distill_loss(logits_rep, teacher_logits, cfg.temperature)
                        loss = loss + lambda_d * dloss

                if old_state is not None and cfg.anchor_weight > 0:
                    aloss = core.anchor_loss(model, old_state, device)
                    loss = loss + cfg.anchor_weight * aloss

                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()

                if step == 1 or step % cfg.print_every == 0 or step == cfg.steps_per_phase:
                    row = {
                        "phase": phase_index,
                        "phase_name": phase["name"],
                        "step": step,
                        "loss": float(loss.item()),
                        "ce_current": float(ce_cur.item()),
                        "ce_replay": float(ce_replay.item()),
                        "distill": float(dloss.item()),
                        "lambda_distill": float(lambda_d),
                        "anchor": float(aloss.item()),
                        "memory_chunks": len(all_memory),
                    }
                    tw.writerow(row)
                    tf.flush()
                    put(
                        q,
                        "log",
                        f"phase {phase_index:02d} {phase['name']:<28} step {step:04d}/{cfg.steps_per_phase} "
                        f"loss {loss.item():.4f} ce_cur {ce_cur.item():.4f} ce_rep {ce_replay.item():.4f} "
                        f"distill {dloss.item():.4f} λd {lambda_d:.3f}",
                    )

                if step == cfg.steps_per_phase or (cfg.milestone_every > 0 and step % cfg.milestone_every == 0):
                    eval_dict = evaluate_seen(model, phases, phase_index, device, cfg.batch_size, cfg.eval_batches)
                    text = [
                        f"MILESTONE | phase {phase_index} {phase['name']} | step {step}/{cfg.steps_per_phase}",
                        "Evaluation on seen phases:",
                        render_eval(eval_dict),
                    ]
                    gen = generate_milestone_text(model, cfg.prompts, device, cfg.gen_tokens)
                    if gen:
                        text.extend(["", "Fixed-prompt completions:", gen])
                    put(q, "milestone", "\n".join(text))
                    eval_row = {"phase": phase_index, "phase_name": phase["name"], "step": step, **eval_dict}
                    eval_rows.append(eval_row)

            # After phase: store memory and save checkpoint.
            mem_cfg = core.MemoryConfig(memory_per_phase=cfg.memory_per_phase, policy=cfg.memory_policy)
            selected = core.select_memory_chunks(model, phase["chunks"], mem_cfg, device)
            memory_by_phase[phase_index] = selected
            total_mem = sum(len(v) for v in memory_by_phase.values())
            put(q, "milestone", f"Stored {len(selected)} chunks for phase {phase_index}; total memory now {total_mem} chunks.")

            torch.save({
                "model_state": model.state_dict(),
                "phase": phase_index,
                "phase_name": phase["name"],
                "memory_by_phase": memory_by_phase,
            }, cfg.out_dir / f"checkpoint_after_phase_{phase_index:02d}.pt")

    # Flexible eval CSV.
    if eval_rows:
        fields = sorted({k for row in eval_rows for k in row.keys()})
        with eval_csv.open("w", newline="", encoding="utf-8") as ef:
            ew = csv.DictWriter(ef, fieldnames=fields)
            ew.writeheader()
            for row in eval_rows:
                ew.writerow(row)

    torch.save({
        "model_state": model.state_dict(),
        "memory_by_phase": memory_by_phase,
        "phase_names": [p["name"] for p in phases],
    }, cfg.out_dir / "model_final.pt")
    put(q, "milestone", f"DONE. Saved outputs in:\n{cfg.out_dir}")


class LifelongGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Micro Lifelong LLM — Replay / Distillation Toy")
        self.geometry("1180x780")
        self.queue: queue.Queue = queue.Queue()
        self.stop_event = threading.Event()
        self.worker: threading.Thread | None = None
        self._build_ui()
        self.after(100, self._poll_queue)

        if TORCH_IMPORT_ERROR is not None:
            messagebox.showerror("PyTorch missing", f"PyTorch could not be imported. Install it first.\n\n{TORCH_IMPORT_ERROR}")
        if CORE_IMPORT_ERROR is not None:
            messagebox.showerror("Core import failed", f"micro_lifelong_llm.py could not be imported.\n\n{CORE_IMPORT_ERROR}")

    def _build_ui(self):
        root = ttk.Frame(self, padding=8)
        root.pack(fill="both", expand=True)

        controls = ttk.LabelFrame(root, text="Run controls", padding=8)
        controls.pack(fill="x", side="top")

        self.vars: Dict[str, tk.StringVar] = {}
        def add_entry(row, col, label, key, default, width=12):
            ttk.Label(controls, text=label).grid(row=row, column=col, sticky="w", padx=4, pady=3)
            var = tk.StringVar(value=str(default))
            self.vars[key] = var
            ttk.Entry(controls, textvariable=var, width=width).grid(row=row, column=col+1, sticky="we", padx=4, pady=3)
            return var

        # Row 0 paths
        add_entry(0, 0, "Corpus", "corpus_dir", DEFAULT_CORPUS, width=48)
        ttk.Button(controls, text="Browse", command=self._browse_corpus).grid(row=0, column=2, padx=4)
        add_entry(0, 3, "Output", "out_dir", DEFAULT_OUT, width=48)
        ttk.Button(controls, text="Open", command=self._open_out).grid(row=0, column=5, padx=4)

        # Row 1 model/run
        add_entry(1, 0, "Steps/phase", "steps_per_phase", 300)
        add_entry(1, 2, "Memory/phase", "memory_per_phase", 300)
        add_entry(1, 4, "Milestone every", "milestone_every", 100)
        add_entry(1, 6, "Seed", "seed", 42)

        # Row 2 batches/loss
        add_entry(2, 0, "Batch", "batch_size", 16)
        add_entry(2, 2, "Replay batch", "replay_batch", 16)
        add_entry(2, 4, "Distill weight", "distill_weight", -1.0)
        add_entry(2, 6, "Anchor", "anchor_weight", 0.0)

        # Row 3 architecture
        add_entry(3, 0, "Block", "block_size", 128)
        add_entry(3, 2, "Emb", "n_embd", 96)
        add_entry(3, 4, "Layers", "n_layer", 2)
        add_entry(3, 6, "Heads", "n_head", 4)

        # Row 4 learning
        add_entry(4, 0, "LR", "lr", 3e-4)
        add_entry(4, 2, "Eval batches", "eval_batches", 6)
        add_entry(4, 4, "Sample tokens", "gen_tokens", 180)
        add_entry(4, 6, "Max chars/file", "max_chars_per_file", 0)

        ttk.Label(controls, text="Device").grid(row=5, column=0, sticky="w", padx=4, pady=3)
        self.device_var = tk.StringVar(value="auto")
        ttk.Combobox(controls, textvariable=self.device_var, values=["auto", "cpu", "cuda"], width=10, state="readonly").grid(row=5, column=1, sticky="w", padx=4)

        ttk.Label(controls, text="Memory policy").grid(row=5, column=2, sticky="w", padx=4, pady=3)
        self.policy_var = tk.StringVar(value="auto")
        ttk.Combobox(controls, textvariable=self.policy_var, values=["auto", "balanced", "diverse", "hard", "hard_diverse"], width=14, state="readonly").grid(row=5, column=3, sticky="w", padx=4)

        self.start_btn = ttk.Button(controls, text="Start training", command=self._start)
        self.start_btn.grid(row=5, column=4, padx=4, pady=4, sticky="we")
        self.stop_btn = ttk.Button(controls, text="Stop", command=self._stop, state="disabled")
        self.stop_btn.grid(row=5, column=5, padx=4, pady=4, sticky="we")
        ttk.Button(controls, text="Open corpus", command=self._open_corpus).grid(row=5, column=6, padx=4, pady=4, sticky="we")

        # Prompt area and output panes
        lower = ttk.PanedWindow(root, orient="horizontal")
        lower.pack(fill="both", expand=True, pady=(8, 0))

        left = ttk.Frame(lower)
        right = ttk.Frame(lower)
        lower.add(left, weight=1)
        lower.add(right, weight=2)

        prompt_frame = ttk.LabelFrame(left, text="Fixed milestone prompts", padding=6)
        prompt_frame.pack(fill="both", expand=False)
        self.prompt_text = tk.Text(prompt_frame, height=12, wrap="word")
        self.prompt_text.pack(fill="both", expand=True)
        self.prompt_text.insert("1.0", "Memory is\nThe red key\nlow serum osmolality\ndef add_one\neven plus even\nthe quiet machine")

        help_frame = ttk.LabelFrame(left, text="What to watch", padding=6)
        help_frame.pack(fill="both", expand=True, pady=(8,0))
        self.help_text = tk.Text(help_frame, wrap="word", height=14)
        self.help_text.pack(fill="both", expand=True)
        self.help_text.insert("1.0", (
            "Milestones show losses on all phases seen so far and completions from fixed prompts.\n\n"
            "A good lifelong run should keep earlier phase losses from exploding after later phases.\n\n"
            "Use memory_per_phase=50, 300, and 1000 to test the same memory-density idea from the symbol experiments.\n\n"
            "distill_weight=-1 uses auto: little/no distillation when memory is tiny; weak distillation when memory is denser."
        ))
        self.help_text.config(state="disabled")

        nb = ttk.Notebook(right)
        nb.pack(fill="both", expand=True)
        log_frame = ttk.Frame(nb)
        mile_frame = ttk.Frame(nb)
        nb.add(mile_frame, text="Milestones / completions")
        nb.add(log_frame, text="Live training log")

        self.milestone_text = tk.Text(mile_frame, wrap="word")
        self.milestone_text.pack(fill="both", expand=True)
        self.log_text = tk.Text(log_frame, wrap="none")
        self.log_text.pack(fill="both", expand=True)

    def _browse_corpus(self):
        p = filedialog.askdirectory(initialdir=str(DEFAULT_CORPUS.parent), title="Select corpus folder")
        if p:
            self.vars["corpus_dir"].set(p)

    def _open_out(self):
        open_folder(Path(self.vars["out_dir"].get()))

    def _open_corpus(self):
        open_folder(Path(self.vars["corpus_dir"].get()))

    def _parse_config(self) -> GUIConfig:
        def get_int(k): return int(float(self.vars[k].get()))
        def get_float(k): return float(self.vars[k].get())
        prompts = [line.strip() for line in self.prompt_text.get("1.0", "end").splitlines() if line.strip()]
        return GUIConfig(
            corpus_dir=Path(self.vars["corpus_dir"].get()),
            out_dir=Path(self.vars["out_dir"].get()),
            seed=get_int("seed"),
            device_choice=self.device_var.get(),
            block_size=get_int("block_size"),
            n_embd=get_int("n_embd"),
            n_head=get_int("n_head"),
            n_layer=get_int("n_layer"),
            dropout=0.1,
            steps_per_phase=get_int("steps_per_phase"),
            batch_size=get_int("batch_size"),
            replay_batch=get_int("replay_batch"),
            lr=get_float("lr"),
            weight_decay=0.01,
            replay_ce_weight=1.0,
            distill_weight=get_float("distill_weight"),
            temperature=2.0,
            anchor_weight=get_float("anchor_weight"),
            memory_per_phase=get_int("memory_per_phase"),
            memory_policy=self.policy_var.get(),
            eval_batches=get_int("eval_batches"),
            print_every=50,
            milestone_every=get_int("milestone_every"),
            gen_tokens=get_int("gen_tokens"),
            prompts=prompts,
            max_chars_per_file=get_int("max_chars_per_file") or None,
        )

    def _start(self):
        if self.worker and self.worker.is_alive():
            return
        if TORCH_IMPORT_ERROR is not None:
            messagebox.showerror("PyTorch missing", "Install PyTorch first: pip install torch")
            return
        try:
            cfg = self._parse_config()
        except Exception as exc:
            messagebox.showerror("Bad setting", str(exc))
            return
        if not cfg.corpus_dir.exists():
            messagebox.showerror("Missing corpus", f"Corpus folder does not exist:\n{cfg.corpus_dir}")
            return
        self.stop_event.clear()
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.log_text.delete("1.0", "end")
        self.milestone_text.delete("1.0", "end")
        self.worker = threading.Thread(target=self._worker_wrapper, args=(cfg,), daemon=True)
        self.worker.start()

    def _worker_wrapper(self, cfg: GUIConfig):
        try:
            train_lifelong(cfg, self.queue, self.stop_event)
        except Exception:
            put(self.queue, "milestone", "ERROR:\n" + traceback.format_exc())
        finally:
            self.queue.put({"kind": "done", "text": "", "time": time.strftime("%H:%M:%S")})

    def _stop(self):
        self.stop_event.set()
        self.stop_btn.config(state="disabled")

    def _poll_queue(self):
        try:
            while True:
                msg = self.queue.get_nowait()
                kind = msg.get("kind")
                stamp = msg.get("time", "")
                text = msg.get("text", "")
                if kind == "log":
                    self.log_text.insert("end", f"[{stamp}] {text}\n")
                    self.log_text.see("end")
                elif kind == "milestone":
                    self.milestone_text.insert("end", f"\n[{stamp}] {text}\n")
                    self.milestone_text.see("end")
                elif kind == "done":
                    self.start_btn.config(state="normal")
                    self.stop_btn.config(state="disabled")
        except queue.Empty:
            pass
        self.after(100, self._poll_queue)


if __name__ == "__main__":
    app = LifelongGUI()
    app.mainloop()
