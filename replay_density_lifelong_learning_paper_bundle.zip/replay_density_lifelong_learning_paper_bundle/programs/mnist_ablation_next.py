# mnist_ablation_next.py
#
# Next ablation for the MNIST continual-learning memory-loop experiment.
#
# Goal:
#   Separate the ingredients that were bundled in the previous winning condition:
#       replay selection: none vs random vs curated
#       anchoring: off vs on
#       distillation: off vs on
#       soft consolidation: off vs on
#
# The CNN architecture is identical for every strategy.
# Phase 1 is trained ONCE per seed on the old digits, then the same saved Phase-1
# state is reloaded for every Phase-2 condition.
#
# Run:
#   pip install torch torchvision
#   python mnist_ablation_next.py
#
# Faster:
#   python mnist_ablation_next.py --phase1-epochs 2 --phase2-epochs 2 --replay-fractions 0,0.02,0.05
#
# More serious:
#   python mnist_ablation_next.py --seeds 42,43,44 --replay-fractions 0,0.01,0.02,0.05,0.10,0.20

import argparse
import csv
import copy
import math
import random
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import ConcatDataset, DataLoader, Dataset, Subset
from torchvision import datasets, transforms


# -----------------------------
# Configuration objects
# -----------------------------


@dataclass(frozen=True)
class Strategy:
    name: str
    replay_kind: str  # "none", "random", "curated"
    anchor_strength: float = 0.0
    distill_strength: float = 0.0
    soft_consolidation: bool = False


STRATEGIES: List[Strategy] = [
    # Basic controls
    Strategy("No replay", "none"),
    Strategy("Random replay", "random"),
    Strategy("Curated replay", "curated"),

    # Isolate anchoring alone
    Strategy("Random replay + anchor", "random", anchor_strength=5.0),
    Strategy("Curated replay + anchor", "curated", anchor_strength=5.0),

    # Isolate distillation alone
    Strategy("Random replay + distill", "random", distill_strength=0.70),
    Strategy("Curated replay + distill", "curated", distill_strength=0.70),

    # The likely important combination
    Strategy("Random replay + anchor/distill", "random", anchor_strength=5.0, distill_strength=0.70),
    Strategy("Curated replay + anchor/distill", "curated", anchor_strength=5.0, distill_strength=0.70),

    # Does soft consolidation add anything when anchor/distill is present?
    Strategy(
        "Random replay + soft + anchor/distill",
        "random",
        anchor_strength=5.0,
        distill_strength=0.70,
        soft_consolidation=True,
    ),
    Strategy(
        "Curated replay + soft + anchor/distill",
        "curated",
        anchor_strength=5.0,
        distill_strength=0.70,
        soft_consolidation=True,
    ),
]


# -----------------------------
# Utility
# -----------------------------


def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_ints(text: str) -> List[int]:
    return [int(x.strip()) for x in text.split(",") if x.strip()]


def parse_floats(text: str) -> List[float]:
    out = []
    for x in text.split(","):
        x = x.strip()
        if not x:
            continue
        val = float(x)
        if val < 0.0 or val >= 1.0:
            raise ValueError("Replay fractions must be >= 0.0 and < 1.0")
        out.append(val)
    return out


def pct(x: float) -> str:
    return f"{100.0 * x:5.1f}%"


def acc_fmt(x: float) -> str:
    return f"{x:.4f}"


# -----------------------------
# Dataset helpers
# -----------------------------


def filter_by_digits(dataset: Dataset, digits: Sequence[int]) -> Subset:
    wanted = set(int(d) for d in digits)
    if hasattr(dataset, "targets"):
        labels = dataset.targets
        indices = [i for i, y in enumerate(labels) if int(y) in wanted]
    else:
        indices = [i for i, (_, y) in enumerate(dataset) if int(y) in wanted]
    return Subset(dataset, indices)


def subset_label(subset: Subset, local_idx: int) -> int:
    base_idx = subset.indices[local_idx]
    base = subset.dataset
    if hasattr(base, "targets"):
        return int(base.targets[base_idx])
    return int(base[base_idx][1])


class FlaggedDataset(Dataset):
    """Wraps a dataset so it returns (x, y, is_replay_old)."""

    def __init__(self, dataset: Dataset, is_replay_old: bool):
        self.dataset = dataset
        self.is_replay_old = bool(is_replay_old)

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int):
        x, y = self.dataset[idx]
        flag = 1 if self.is_replay_old else 0
        return x, int(y), flag


def make_loaders(
    data_dir: str,
    batch_size: int,
    old_digits: List[int],
    held_out_digits: List[int],
) -> Tuple[DataLoader, DataLoader, DataLoader, DataLoader, DataLoader, Subset, Subset]:
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])

    train_full = datasets.MNIST(root=data_dir, train=True, download=True, transform=transform)
    test_full = datasets.MNIST(root=data_dir, train=False, download=True, transform=transform)

    train_old = filter_by_digits(train_full, old_digits)
    train_new = filter_by_digits(train_full, held_out_digits)

    test_old = filter_by_digits(test_full, old_digits)
    test_new = filter_by_digits(test_full, held_out_digits)

    train_old_loader = DataLoader(train_old, batch_size=batch_size, shuffle=True)
    train_new_loader = DataLoader(train_new, batch_size=batch_size, shuffle=True)
    test_old_loader = DataLoader(test_old, batch_size=batch_size, shuffle=False)
    test_new_loader = DataLoader(test_new, batch_size=batch_size, shuffle=False)
    test_all_loader = DataLoader(test_full, batch_size=batch_size, shuffle=False)

    return (
        train_old_loader,
        train_new_loader,
        test_old_loader,
        test_new_loader,
        test_all_loader,
        train_old,
        train_new,
    )


# -----------------------------
# Model
# -----------------------------


class SmallCNN(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, 10)

    def features(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = torch.flatten(x, 1)
        x = F.relu(self.fc1(x))
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.features(x)
        return self.fc2(z)


# -----------------------------
# Optimizers and losses
# -----------------------------


def make_optimizer(model: SmallCNN, strategy: Optional[Strategy] = None) -> torch.optim.Optimizer:
    """
    Same architecture for all strategies.
    Soft consolidation only changes Phase-2 learning rates, not layers/parameters.
    """
    if strategy is not None and strategy.soft_consolidation:
        groups = [
            {"name": "conv1", "params": model.conv1.parameters(), "lr": 3e-4},
            {"name": "conv2", "params": model.conv2.parameters(), "lr": 5e-4},
            {"name": "fc1", "params": model.fc1.parameters(), "lr": 8e-4},
            {"name": "fc2", "params": model.fc2.parameters(), "lr": 1e-3},
        ]
    else:
        groups = [
            {"name": "conv1", "params": model.conv1.parameters(), "lr": 1e-3},
            {"name": "conv2", "params": model.conv2.parameters(), "lr": 1e-3},
            {"name": "fc1", "params": model.fc1.parameters(), "lr": 1e-3},
            {"name": "fc2", "params": model.fc2.parameters(), "lr": 1e-3},
        ]
    return torch.optim.Adam(groups)


def mask_logits_to_digits(logits: torch.Tensor, allowed_digits: Optional[List[int]]) -> torch.Tensor:
    if allowed_digits is None:
        return logits
    masked = torch.full_like(logits, -1e9)
    allowed = torch.tensor(allowed_digits, dtype=torch.long, device=logits.device)
    masked[:, allowed] = logits[:, allowed]
    return masked


def parameter_anchor_loss(model: nn.Module, anchor_state: Dict[str, torch.Tensor]) -> torch.Tensor:
    total = None
    count = 0
    for name, p in model.named_parameters():
        old = anchor_state[name].to(p.device)
        term = (p - old).pow(2).sum()
        total = term if total is None else total + term
        count += p.numel()
    assert total is not None
    return total / max(1, count)


def distillation_loss(
    student_logits: torch.Tensor,
    teacher_logits: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    t = temperature
    student_log_probs = F.log_softmax(student_logits / t, dim=1)
    teacher_probs = F.softmax(teacher_logits / t, dim=1)
    return F.kl_div(student_log_probs, teacher_probs, reduction="batchmean") * (t * t)


# -----------------------------
# Phase 1 training and evaluation
# -----------------------------


def train_phase1_epoch(
    model: SmallCNN,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: str,
    old_digits: List[int],
) -> float:
    model.train()
    total_loss = 0.0
    total_seen = 0
    for x, y in loader:
        x = x.to(device)
        y = y.to(device)
        optimizer.zero_grad(set_to_none=True)
        logits = mask_logits_to_digits(model(x), old_digits)
        loss = F.cross_entropy(logits, y)
        loss.backward()
        optimizer.step()
        total_loss += float(loss.item()) * x.size(0)
        total_seen += x.size(0)
    return total_loss / max(1, total_seen)


@torch.no_grad()
def accuracy(model: SmallCNN, loader: DataLoader, device: str) -> float:
    model.eval()
    correct = 0
    total = 0
    for x, y in loader:
        x = x.to(device)
        y = y.to(device)
        logits = model(x)
        pred = logits.argmax(dim=1)
        correct += int((pred == y).sum().item())
        total += int(y.numel())
    return correct / max(1, total)


# -----------------------------
# Memory selection
# -----------------------------


def replay_budget(n_new: int, replay_fraction: float, max_old: int) -> int:
    """
    If replay_fraction is the fraction of the Phase-2 mixed dataset that is old:
        budget / (budget + n_new) = replay_fraction
    """
    if replay_fraction <= 0.0:
        return 0
    n = int((replay_fraction / (1.0 - replay_fraction)) * n_new)
    return max(1, min(n, max_old))


def indices_by_digit(subset: Subset, digits: List[int]) -> Dict[int, List[int]]:
    out = {d: [] for d in digits}
    for i in range(len(subset)):
        y = subset_label(subset, i)
        if y in out:
            out[y].append(i)
    return out


def balanced_random_indices(
    train_old: Subset,
    old_digits: List[int],
    budget: int,
    seed: int,
) -> List[int]:
    if budget <= 0:
        return []
    rng = random.Random(seed)
    by_digit = indices_by_digit(train_old, old_digits)
    selected: List[int] = []

    base = budget // len(old_digits)
    extra = budget % len(old_digits)
    shuffled_digits = list(old_digits)
    rng.shuffle(shuffled_digits)

    for rank, d in enumerate(shuffled_digits):
        k = base + (1 if rank < extra else 0)
        pool = by_digit[d]
        if not pool:
            continue
        k = min(k, len(pool))
        selected.extend(rng.sample(pool, k))

    # Fill if some class was too small.
    if len(selected) < budget:
        remaining = list(set(range(len(train_old))) - set(selected))
        rng.shuffle(remaining)
        selected.extend(remaining[: budget - len(selected)])

    rng.shuffle(selected)
    return selected[:budget]


@torch.no_grad()
def curated_indices(
    model: SmallCNN,
    train_old: Subset,
    old_digits: List[int],
    budget: int,
    batch_size: int,
    device: str,
    seed: int,
    hard_fraction: float = 0.50,
) -> List[int]:
    """
    Curated memory selection.

    For each old digit, select a balanced mix of:
      1. hard examples: low confidence for the true class
      2. representative examples: closest to the feature centroid

    This intentionally tests whether model-chosen memory beats random memory.
    """
    if budget <= 0:
        return []

    loader = DataLoader(train_old, batch_size=batch_size, shuffle=False)
    model.eval()

    all_features: List[torch.Tensor] = []
    all_labels: List[torch.Tensor] = []
    all_conf: List[torch.Tensor] = []

    for x, y in loader:
        x = x.to(device)
        y = y.to(device)
        feats = model.features(x)
        logits = model.fc2(feats)
        probs = F.softmax(logits, dim=1)
        conf = probs.gather(1, y.view(-1, 1)).squeeze(1)
        all_features.append(feats.cpu())
        all_labels.append(y.cpu())
        all_conf.append(conf.cpu())

    features = torch.cat(all_features, dim=0)
    labels = torch.cat(all_labels, dim=0)
    confs = torch.cat(all_conf, dim=0)

    rng = random.Random(seed)
    selected: List[int] = []

    base = budget // len(old_digits)
    extra = budget % len(old_digits)
    digit_order = list(old_digits)
    rng.shuffle(digit_order)

    for rank, d in enumerate(digit_order):
        k = base + (1 if rank < extra else 0)
        class_idxs = (labels == d).nonzero(as_tuple=False).view(-1)
        if class_idxs.numel() == 0 or k <= 0:
            continue

        class_features = features[class_idxs]
        class_confs = confs[class_idxs]

        # Hard examples: lowest confidence.
        k_hard = int(round(k * hard_fraction))
        k_hard = min(k_hard, class_idxs.numel())
        hard_local = torch.argsort(class_confs, descending=False)[:k_hard]
        hard_global = class_idxs[hard_local].tolist()

        # Representative examples: closest to centroid, excluding hard examples if possible.
        k_rep = k - len(hard_global)
        centroid = class_features.mean(dim=0, keepdim=True)
        dist = torch.norm(class_features - centroid, dim=1)
        rep_order = torch.argsort(dist, descending=False).tolist()

        chosen_for_class = list(hard_global)
        used = set(chosen_for_class)
        for local_idx in rep_order:
            global_idx = int(class_idxs[local_idx].item())
            if global_idx in used:
                continue
            chosen_for_class.append(global_idx)
            used.add(global_idx)
            if len(chosen_for_class) >= k:
                break

        selected.extend(chosen_for_class)

    # Fill if needed.
    if len(selected) < budget:
        remaining = list(set(range(len(train_old))) - set(selected))
        rng.shuffle(remaining)
        selected.extend(remaining[: budget - len(selected)])

    rng.shuffle(selected)
    return selected[:budget]


def make_phase2_loader(
    train_new: Subset,
    train_old: Subset,
    replay_indices: List[int],
    batch_size: int,
    seed: int,
) -> DataLoader:
    datasets_for_phase2: List[Dataset] = [FlaggedDataset(train_new, is_replay_old=False)]
    if replay_indices:
        replay_subset = Subset(train_old, replay_indices)
        datasets_for_phase2.append(FlaggedDataset(replay_subset, is_replay_old=True))
    mixed = ConcatDataset(datasets_for_phase2)
    generator = torch.Generator()
    generator.manual_seed(seed)
    return DataLoader(mixed, batch_size=batch_size, shuffle=True, generator=generator)


# -----------------------------
# Phase 2 training
# -----------------------------


def train_phase2_epoch(
    model: SmallCNN,
    teacher: SmallCNN,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    strategy: Strategy,
    anchor_state: Dict[str, torch.Tensor],
    device: str,
    temperature: float,
) -> Dict[str, float]:
    model.train()
    teacher.eval()

    total_loss = 0.0
    total_ce = 0.0
    total_anchor = 0.0
    total_distill = 0.0
    total_seen = 0

    for x, y, is_old in loader:
        x = x.to(device)
        y = y.to(device)
        is_old = is_old.to(device).bool()

        optimizer.zero_grad(set_to_none=True)
        logits = model(x)

        ce = F.cross_entropy(logits, y)

        anchor = torch.zeros((), device=device)
        if strategy.anchor_strength > 0.0:
            anchor = parameter_anchor_loss(model, anchor_state)

        distill = torch.zeros((), device=device)
        if strategy.distill_strength > 0.0 and is_old.any():
            with torch.no_grad():
                teacher_logits = teacher(x[is_old])
            student_logits = logits[is_old]
            distill = distillation_loss(student_logits, teacher_logits, temperature=temperature)

        loss = ce + strategy.anchor_strength * anchor + strategy.distill_strength * distill
        loss.backward()
        optimizer.step()

        n = x.size(0)
        total_loss += float(loss.item()) * n
        total_ce += float(ce.item()) * n
        total_anchor += float(anchor.item()) * n
        total_distill += float(distill.item()) * n
        total_seen += n

    denom = max(1, total_seen)
    return {
        "loss": total_loss / denom,
        "ce": total_ce / denom,
        "anchor": total_anchor / denom,
        "distill": total_distill / denom,
    }


# -----------------------------
# Experiment
# -----------------------------


def select_replay_indices(
    strategy: Strategy,
    replay_fraction: float,
    model_after_phase1: SmallCNN,
    train_old: Subset,
    train_new: Subset,
    old_digits: List[int],
    batch_size: int,
    device: str,
    seed: int,
) -> List[int]:
    if strategy.replay_kind == "none":
        return []

    budget = replay_budget(len(train_new), replay_fraction, len(train_old))
    if budget <= 0:
        return []

    if strategy.replay_kind == "random":
        return balanced_random_indices(train_old, old_digits, budget, seed=seed)

    if strategy.replay_kind == "curated":
        return curated_indices(
            model=model_after_phase1,
            train_old=train_old,
            old_digits=old_digits,
            budget=budget,
            batch_size=batch_size,
            device=device,
            seed=seed,
            hard_fraction=0.50,
        )

    raise ValueError(f"Unknown replay_kind: {strategy.replay_kind}")


def run_one_condition(
    seed: int,
    replay_fraction: float,
    strategy: Strategy,
    phase1_state: Dict[str, torch.Tensor],
    phase1_metrics: Dict[str, float],
    teacher: SmallCNN,
    train_old: Subset,
    train_new: Subset,
    test_old_loader: DataLoader,
    test_new_loader: DataLoader,
    test_all_loader: DataLoader,
    old_digits: List[int],
    batch_size: int,
    phase2_epochs: int,
    device: str,
    temperature: float,
    condition_seed: int,
    quiet: bool,
) -> Dict[str, object]:
    model = SmallCNN().to(device)
    model.load_state_dict(copy.deepcopy(phase1_state))
    optimizer = make_optimizer(model, strategy)

    replay_indices = select_replay_indices(
        strategy=strategy,
        replay_fraction=replay_fraction,
        model_after_phase1=teacher,
        train_old=train_old,
        train_new=train_new,
        old_digits=old_digits,
        batch_size=batch_size,
        device=device,
        seed=condition_seed,
    )

    phase2_loader = make_phase2_loader(
        train_new=train_new,
        train_old=train_old,
        replay_indices=replay_indices,
        batch_size=batch_size,
        seed=condition_seed + 77,
    )

    anchor_state = {k: v.detach().clone().to(device) for k, v in phase1_state.items()}

    if not quiet:
        print("=" * 132)
        print(f"Seed={seed} | Replay={pct(replay_fraction)} | {strategy.name} | budget={len(replay_indices)}")
        print("=" * 132)

    last_losses = {"loss": 0.0, "ce": 0.0, "anchor": 0.0, "distill": 0.0}
    for epoch in range(1, phase2_epochs + 1):
        last_losses = train_phase2_epoch(
            model=model,
            teacher=teacher,
            loader=phase2_loader,
            optimizer=optimizer,
            strategy=strategy,
            anchor_state=anchor_state,
            device=device,
            temperature=temperature,
        )
        old_acc_now = accuracy(model, test_old_loader, device)
        if not quiet:
            print(
                f"Phase 2 epoch {epoch:02d} | "
                f"loss {last_losses['loss']:.4f} | "
                f"ce {last_losses['ce']:.4f} | "
                f"anchor {last_losses['anchor']:.6f} | "
                f"distill {last_losses['distill']:.4f} | "
                f"old_acc {old_acc_now:.4f}"
            )

    old_p2 = accuracy(model, test_old_loader, device)
    new_p2 = accuracy(model, test_new_loader, device)
    all_p2 = accuracy(model, test_all_loader, device)
    forgetting = phase1_metrics["old_p1"] - old_p2
    stability_score = all_p2 - forgetting
    harmonic_old_new = 2.0 * old_p2 * new_p2 / max(1e-12, old_p2 + new_p2)

    result: Dict[str, object] = {
        "seed": seed,
        "replay_fraction": replay_fraction,
        "strategy": strategy.name,
        "replay_kind": strategy.replay_kind,
        "budget": len(replay_indices),
        "anchor_strength": strategy.anchor_strength,
        "distill_strength": strategy.distill_strength,
        "soft_consolidation": strategy.soft_consolidation,
        "old_p1": phase1_metrics["old_p1"],
        "new_p1": phase1_metrics["new_p1"],
        "all_p1": phase1_metrics["all_p1"],
        "old_p2": old_p2,
        "new_p2": new_p2,
        "all_p2": all_p2,
        "forgetting": forgetting,
        "stability_score": stability_score,
        "harmonic_old_new": harmonic_old_new,
        "final_loss": last_losses["loss"],
        "final_ce": last_losses["ce"],
        "final_anchor_loss": last_losses["anchor"],
        "final_distill_loss": last_losses["distill"],
    }

    if not quiet:
        print(
            f"Result | Old P2={old_p2:.4f} | New P2={new_p2:.4f} | "
            f"All P2={all_p2:.4f} | Forget={forgetting:.4f} | "
            f"Score={stability_score:.4f} | H(old,new)={harmonic_old_new:.4f}\n"
        )

    return result


def train_phase1_once(
    seed: int,
    train_old_loader: DataLoader,
    test_old_loader: DataLoader,
    test_new_loader: DataLoader,
    test_all_loader: DataLoader,
    old_digits: List[int],
    phase1_epochs: int,
    device: str,
    quiet: bool,
) -> Tuple[Dict[str, torch.Tensor], Dict[str, float], SmallCNN]:
    set_seed(seed)
    model = SmallCNN().to(device)
    optimizer = make_optimizer(model, strategy=None)

    if not quiet:
        print("\n" + "#" * 110)
        print(f"PHASE 1: train one conventional CNN on old digits only | seed={seed}")
        print("#" * 110)

    for epoch in range(1, phase1_epochs + 1):
        loss = train_phase1_epoch(model, train_old_loader, optimizer, device, old_digits)
        old_acc_now = accuracy(model, test_old_loader, device)
        if not quiet:
            print(f"Phase 1 epoch {epoch:02d} | loss {loss:.4f} | old_acc {old_acc_now:.4f}")

    old_p1 = accuracy(model, test_old_loader, device)
    new_p1 = accuracy(model, test_new_loader, device)
    all_p1 = accuracy(model, test_all_loader, device)

    if not quiet:
        print(f"Phase 1 saved state | old={old_p1:.4f} | new={new_p1:.4f} | all={all_p1:.4f}")

    state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    teacher = SmallCNN().to(device)
    teacher.load_state_dict(copy.deepcopy(state))
    teacher.eval()
    for p in teacher.parameters():
        p.requires_grad_(False)

    metrics = {"old_p1": old_p1, "new_p1": new_p1, "all_p1": all_p1}
    return state, metrics, teacher


def print_results(results: List[Dict[str, object]]) -> None:
    print("\nFINAL ABLATION RESULTS")
    print("=" * 172)
    print(
        f"{'Seed':>5s} {'Replay':>8s} {'Strategy':52s} {'Budget':>7s} "
        f"{'Old P2':>8s} {'New P2':>8s} {'All P2':>8s} {'Forget':>8s} "
        f"{'Score':>8s} {'Harmonic':>9s}"
    )
    print("-" * 172)

    for r in sorted(results, key=lambda x: (int(x["seed"]), float(x["replay_fraction"]), str(x["strategy"]))):
        print(
            f"{int(r['seed']):5d} {pct(float(r['replay_fraction'])):>8s} "
            f"{str(r['strategy']):52s} {int(r['budget']):7d} "
            f"{acc_fmt(float(r['old_p2'])):>8s} {acc_fmt(float(r['new_p2'])):>8s} "
            f"{acc_fmt(float(r['all_p2'])):>8s} {acc_fmt(float(r['forgetting'])):>8s} "
            f"{acc_fmt(float(r['stability_score'])):>8s} {acc_fmt(float(r['harmonic_old_new'])):>9s}"
        )


def average_results(results: List[Dict[str, object]]) -> List[Dict[str, object]]:
    grouped: Dict[Tuple[float, str], List[Dict[str, object]]] = {}
    for r in results:
        key = (float(r["replay_fraction"]), str(r["strategy"]))
        grouped.setdefault(key, []).append(r)

    avg_rows: List[Dict[str, object]] = []
    numeric_fields = [
        "budget",
        "old_p1",
        "new_p1",
        "all_p1",
        "old_p2",
        "new_p2",
        "all_p2",
        "forgetting",
        "stability_score",
        "harmonic_old_new",
        "final_loss",
        "final_ce",
        "final_anchor_loss",
        "final_distill_loss",
    ]

    for (frac, strat), rows in grouped.items():
        out: Dict[str, object] = {
            "replay_fraction": frac,
            "strategy": strat,
            "n_seeds": len(rows),
        }
        for field in numeric_fields:
            vals = [float(r[field]) for r in rows]
            out[field] = sum(vals) / len(vals)
        avg_rows.append(out)

    return sorted(avg_rows, key=lambda x: (float(x["replay_fraction"]), str(x["strategy"])))


def print_average_results(avg_rows: List[Dict[str, object]]) -> None:
    print("\nAVERAGE RESULTS OVER SEEDS")
    print("=" * 172)
    print(
        f"{'Replay':>8s} {'Strategy':52s} {'Seeds':>5s} {'Budget':>7s} "
        f"{'Old P2':>8s} {'New P2':>8s} {'All P2':>8s} {'Forget':>8s} "
        f"{'Score':>8s} {'Harmonic':>9s}"
    )
    print("-" * 172)
    for r in avg_rows:
        print(
            f"{pct(float(r['replay_fraction'])):>8s} {str(r['strategy']):52s} {int(r['n_seeds']):5d} "
            f"{float(r['budget']):7.1f} {acc_fmt(float(r['old_p2'])):>8s} "
            f"{acc_fmt(float(r['new_p2'])):>8s} {acc_fmt(float(r['all_p2'])):>8s} "
            f"{acc_fmt(float(r['forgetting'])):>8s} {acc_fmt(float(r['stability_score'])):>8s} "
            f"{acc_fmt(float(r['harmonic_old_new'])):>9s}"
        )


def print_best_by_replay(avg_rows: List[Dict[str, object]]) -> None:
    print("\nBEST BY REPLAY FRACTION")
    print("=" * 172)
    print("Primary sort: stability_score = All P2 - Forget. Secondary: harmonic mean of Old P2 and New P2.")
    print("-" * 172)
    fracs = sorted(set(float(r["replay_fraction"]) for r in avg_rows))
    for frac in fracs:
        rows = [r for r in avg_rows if float(r["replay_fraction"]) == frac]
        best = sorted(
            rows,
            key=lambda r: (float(r["stability_score"]), float(r["harmonic_old_new"]), float(r["all_p2"])),
            reverse=True,
        )[0]
        print(
            f"Replay {pct(frac)} | best: {best['strategy']} | "
            f"Old P2={float(best['old_p2']):.4f} | "
            f"New P2={float(best['new_p2']):.4f} | "
            f"All P2={float(best['all_p2']):.4f} | "
            f"Forget={float(best['forgetting']):.4f} | "
            f"Score={float(best['stability_score']):.4f} | "
            f"H={float(best['harmonic_old_new']):.4f}"
        )


def save_csv(path: str, rows: List[Dict[str, object]]) -> None:
    if not rows:
        return
    fieldnames = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


# -----------------------------
# Main
# -----------------------------


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=str, default="./data")
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--phase1-epochs", type=int, default=3)
    parser.add_argument("--phase2-epochs", type=int, default=3)
    parser.add_argument("--held-out", type=str, default="3,6,9")
    parser.add_argument("--replay-fractions", type=str, default="0,0.01,0.02,0.05,0.10,0.20")
    parser.add_argument("--seeds", type=str, default="42")
    parser.add_argument("--temperature", type=float, default=2.0)
    parser.add_argument("--csv", type=str, default="mnist_ablation_next_results.csv")
    parser.add_argument("--avg-csv", type=str, default="mnist_ablation_next_avg_results.csv")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    held_out_digits = parse_ints(args.held_out)
    old_digits = [d for d in range(10) if d not in held_out_digits]
    replay_fractions = parse_floats(args.replay_fractions)
    seeds = parse_ints(args.seeds)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    print(f"Device:           {device}")
    print(f"Old digits:       {old_digits}")
    print(f"Held-out digits:  {held_out_digits}")
    print(f"Replay fractions: {replay_fractions}")
    print(f"Seeds:            {seeds}")
    print("CNN architecture: identical for every strategy")
    print("Ablation: replay selection x anchor x distill x soft consolidation")
    print()

    loaders = make_loaders(
        data_dir=args.data_dir,
        batch_size=args.batch_size,
        old_digits=old_digits,
        held_out_digits=held_out_digits,
    )
    (
        train_old_loader,
        _train_new_loader,
        test_old_loader,
        test_new_loader,
        test_all_loader,
        train_old,
        train_new,
    ) = loaders

    all_results: List[Dict[str, object]] = []

    for seed in seeds:
        phase1_state, phase1_metrics, teacher = train_phase1_once(
            seed=seed,
            train_old_loader=train_old_loader,
            test_old_loader=test_old_loader,
            test_new_loader=test_new_loader,
            test_all_loader=test_all_loader,
            old_digits=old_digits,
            phase1_epochs=args.phase1_epochs,
            device=device,
            quiet=args.quiet,
        )

        condition_counter = 0
        for replay_fraction in replay_fractions:
            for strategy in STRATEGIES:
                condition_counter += 1
                condition_seed = seed * 1000003 + condition_counter * 9176
                result = run_one_condition(
                    seed=seed,
                    replay_fraction=replay_fraction,
                    strategy=strategy,
                    phase1_state=phase1_state,
                    phase1_metrics=phase1_metrics,
                    teacher=teacher,
                    train_old=train_old,
                    train_new=train_new,
                    test_old_loader=test_old_loader,
                    test_new_loader=test_new_loader,
                    test_all_loader=test_all_loader,
                    old_digits=old_digits,
                    batch_size=args.batch_size,
                    phase2_epochs=args.phase2_epochs,
                    device=device,
                    temperature=args.temperature,
                    condition_seed=condition_seed,
                    quiet=args.quiet,
                )
                all_results.append(result)

    print_results(all_results)
    avg_rows = average_results(all_results)
    print_average_results(avg_rows)
    print_best_by_replay(avg_rows)

    save_csv(args.csv, all_results)
    save_csv(args.avg_csv, avg_rows)
    print()
    print(f"Saved per-run results to: {args.csv}")
    print(f"Saved average results to: {args.avg_csv}")


if __name__ == "__main__":
    main()
