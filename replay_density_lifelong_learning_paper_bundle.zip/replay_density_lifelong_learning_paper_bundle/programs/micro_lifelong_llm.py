#!/usr/bin/env python3
"""
micro_lifelong_llm.py

A laughably small continuously-learning byte-level Transformer.

It learns text in phases. At each new phase it mixes current material with a
replay buffer from earlier phases, optionally distilling from a frozen copy of
its old self on replay examples. This is a toy embodiment of the replay-density
finding:

    sparse memory     -> prioritize balanced coverage
    moderate memory   -> weak teacher distillation
    larger memory     -> add diverse / high-loss examples

Run demo:
    python micro_lifelong_llm.py --make-demo-corpus --corpus-dir demo_corpus --steps-per-phase 200

Run on your own corpus folder:
    python micro_lifelong_llm.py --corpus-dir my_corpus --steps-per-phase 500 --memory-per-phase 300

Each .txt file in corpus-dir is one learning phase, sorted by filename.
Put filenames like:
    01_stories.txt
    02_medicine.txt
    03_code.txt
    04_poems.txt

Outputs:
    runs_micro_lifelong/model_final.pt
    runs_micro_lifelong/memory.pt
    runs_micro_lifelong/training_log.csv
"""

from __future__ import annotations

import argparse
import copy
import csv
import math
import os
import random
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


# ----------------------------
# Data utilities
# ----------------------------

VOCAB_SIZE = 256  # byte-level model: no tokenizer needed


def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def encode_bytes(text: str) -> torch.Tensor:
    return torch.tensor(list(text.encode("utf-8", errors="replace")), dtype=torch.long)


def decode_bytes(tokens: torch.Tensor) -> str:
    if tokens.dim() > 1:
        tokens = tokens.flatten()
    data = bytes([int(t) % 256 for t in tokens.tolist()])
    return data.decode("utf-8", errors="replace")


def read_text_file(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def clean_text(s: str) -> str:
    # Mild cleanup only. Do not destroy domain-specific punctuation.
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip() + "\n"


def make_chunks(tokens: torch.Tensor, block_size: int, stride: Optional[int] = None) -> List[torch.Tensor]:
    """Return chunks of length block_size + 1 for next-token prediction."""
    if stride is None:
        stride = block_size
    n = len(tokens)
    if n < block_size + 1:
        pad = torch.full((block_size + 1 - n,), ord(" "), dtype=torch.long)
        return [torch.cat([tokens, pad])]
    chunks = []
    for i in range(0, n - block_size, stride):
        chunks.append(tokens[i : i + block_size + 1].clone())
    if not chunks:
        chunks = [tokens[: block_size + 1].clone()]
    return chunks


def sample_batch(chunks: List[torch.Tensor], batch_size: int, device: torch.device) -> Tuple[torch.Tensor, torch.Tensor]:
    batch = random.choices(chunks, k=batch_size)
    x = torch.stack([b[:-1] for b in batch]).to(device)
    y = torch.stack([b[1:] for b in batch]).to(device)
    return x, y


def load_phases(corpus_dir: Path, block_size: int, max_chars_per_file: Optional[int] = None) -> List[Dict]:
    files = sorted([p for p in corpus_dir.glob("*.txt") if p.is_file()])
    if not files:
        raise FileNotFoundError(f"No .txt files found in {corpus_dir}")
    phases = []
    for idx, path in enumerate(files):
        text = clean_text(read_text_file(path))
        if max_chars_per_file is not None and len(text) > max_chars_per_file:
            text = text[:max_chars_per_file]
        tokens = encode_bytes(text)
        chunks = make_chunks(tokens, block_size=block_size, stride=block_size)
        phases.append({"id": idx, "name": path.stem, "path": str(path), "text": text, "tokens": tokens, "chunks": chunks})
    return phases


def create_demo_corpus(corpus_dir: Path) -> None:
    corpus_dir.mkdir(parents=True, exist_ok=True)
    files = {
        "01_tiny_stories.txt": """
Milo found a blue button under the kitchen table. He put it in a little box and called it his moon.
Every morning he opened the box and said, good morning moon. The button did not answer, but Milo felt brave.
Lina had a red kite. The wind pulled and pulled. She held the string and laughed when the kite climbed over the trees.
A small dog named Pepper learned the sound of the bell. When the bell rang, Pepper sat by the door and waited for a walk.
The garden had three stones, two flowers, and one sleepy bee. The bee liked the yellow flower best.
""" * 40,
        "02_clinical_plain.txt": """
The patient has fever, chills, cough, and fatigue. The clinician asks about timing, exposure, medication, and travel.
A careful assessment separates urgent danger from stable illness. Blood pressure, pulse, oxygen level, and mental status guide the first decision.
In diabetes care, treatment balances glucose control, kidney protection, heart protection, side effects, and cost.
A good note states the problem, the evidence, the uncertainty, and the plan. The plan should be safe even when the diagnosis is incomplete.
Heart failure management considers congestion, perfusion, kidney function, potassium, blood pressure, and symptoms.
""" * 40,
        "03_code_like.txt": """
def add_one(x):
    return x + 1

for item in list_of_items:
    if item.ready:
        process(item)
    else:
        wait(item)

class MemoryBank:
    def __init__(self):
        self.items = []
    def add(self, value):
        self.items.append(value)

# The loop reads data, updates state, saves memory, and tests old behavior.
""" * 40,
        "04_poetry.txt": """
The river remembers the stone but does not stop moving.
A lantern in the rain is not the sun, but it is enough for the next step.
Old leaves teach the soil what the tree cannot say.
The small machine dreamed in sparks, then woke and counted every spark again.
Memory is a room with many doors. Learning is the courage to open one more.
""" * 40,
    }
    for name, text in files.items():
        (corpus_dir / name).write_text(clean_text(text), encoding="utf-8")


# ----------------------------
# Tiny Transformer language model
# ----------------------------

class CausalSelfAttention(nn.Module):
    def __init__(self, n_embd: int, n_head: int, dropout: float, block_size: int):
        super().__init__()
        assert n_embd % n_head == 0
        self.n_head = n_head
        self.head_dim = n_embd // n_head
        self.qkv = nn.Linear(n_embd, 3 * n_embd)
        self.proj = nn.Linear(n_embd, n_embd)
        self.dropout = nn.Dropout(dropout)
        mask = torch.tril(torch.ones(block_size, block_size)).view(1, 1, block_size, block_size)
        self.register_buffer("mask", mask)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, T, C = x.shape
        qkv = self.qkv(x)
        q, k, v = qkv.split(C, dim=2)
        q = q.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        k = k.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        v = v.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        att = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_dim)
        att = att.masked_fill(self.mask[:, :, :T, :T] == 0, float("-inf"))
        att = F.softmax(att, dim=-1)
        att = self.dropout(att)
        y = att @ v
        y = y.transpose(1, 2).contiguous().view(B, T, C)
        return self.dropout(self.proj(y))


class Block(nn.Module):
    def __init__(self, n_embd: int, n_head: int, dropout: float, block_size: int):
        super().__init__()
        self.ln1 = nn.LayerNorm(n_embd)
        self.attn = CausalSelfAttention(n_embd, n_head, dropout, block_size)
        self.ln2 = nn.LayerNorm(n_embd)
        self.ff = nn.Sequential(
            nn.Linear(n_embd, 4 * n_embd),
            nn.GELU(),
            nn.Linear(4 * n_embd, n_embd),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.ln1(x))
        x = x + self.ff(self.ln2(x))
        return x


class TinyGPT(nn.Module):
    def __init__(self, block_size: int = 128, n_embd: int = 96, n_head: int = 4, n_layer: int = 2, dropout: float = 0.1):
        super().__init__()
        self.block_size = block_size
        self.token_emb = nn.Embedding(VOCAB_SIZE, n_embd)
        self.pos_emb = nn.Embedding(block_size, n_embd)
        self.drop = nn.Dropout(dropout)
        self.blocks = nn.Sequential(*[Block(n_embd, n_head, dropout, block_size) for _ in range(n_layer)])
        self.ln_f = nn.LayerNorm(n_embd)
        self.head = nn.Linear(n_embd, VOCAB_SIZE, bias=False)
        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, idx: torch.Tensor, targets: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        B, T = idx.shape
        if T > self.block_size:
            raise ValueError(f"Sequence length {T} exceeds block_size {self.block_size}")
        pos = torch.arange(0, T, device=idx.device).unsqueeze(0)
        x = self.token_emb(idx) + self.pos_emb(pos)
        x = self.drop(x)
        x = self.blocks(x)
        x = self.ln_f(x)
        logits = self.head(x)
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, VOCAB_SIZE), targets.reshape(-1))
        return logits, loss

    @torch.no_grad()
    def generate(self, prompt: str, max_new_tokens: int = 300, temperature: float = 0.9, top_k: int = 50, device: str = "cpu") -> str:
        self.eval()
        idx = encode_bytes(prompt).unsqueeze(0).to(device)
        for _ in range(max_new_tokens):
            idx_cond = idx[:, -self.block_size :]
            logits, _ = self(idx_cond)
            logits = logits[:, -1, :] / max(temperature, 1e-6)
            if top_k is not None and top_k > 0:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, [-1]]] = -float("Inf")
            probs = F.softmax(logits, dim=-1)
            next_id = torch.multinomial(probs, num_samples=1)
            idx = torch.cat((idx, next_id), dim=1)
        return decode_bytes(idx[0].cpu())


# ----------------------------
# Replay memory selection
# ----------------------------

@dataclass
class MemoryConfig:
    memory_per_phase: int
    policy: str  # auto, balanced, diverse, hard_diverse


@torch.no_grad()
def chunk_loss(model: TinyGPT, chunk: torch.Tensor, device: torch.device) -> float:
    x = chunk[:-1].unsqueeze(0).to(device)
    y = chunk[1:].unsqueeze(0).to(device)
    _, loss = model(x, y)
    return float(loss.item())


def byte_hist_distance(chunks: List[torch.Tensor]) -> List[float]:
    """Cheap diversity score: distance from mean byte histogram."""
    if not chunks:
        return []
    hists = []
    for c in chunks:
        hist = torch.bincount(c, minlength=VOCAB_SIZE).float()
        hist = hist / hist.sum().clamp_min(1)
        hists.append(hist)
    H = torch.stack(hists)
    mean = H.mean(dim=0, keepdim=True)
    dist = torch.norm(H - mean, dim=1)
    return dist.tolist()


def select_memory_chunks(
    model: TinyGPT,
    chunks: List[torch.Tensor],
    cfg: MemoryConfig,
    device: torch.device,
) -> List[torch.Tensor]:
    if cfg.memory_per_phase <= 0:
        return []
    n = min(cfg.memory_per_phase, len(chunks))
    if len(chunks) <= n:
        return [c.cpu().clone() for c in chunks]

    policy = cfg.policy
    if policy == "auto":
        # Our experimental rule of thumb:
        # tiny memory: coverage/random; moderate: include hard chunks; larger: diverse + hard.
        if n < 80:
            policy = "balanced"
        elif n < 300:
            policy = "hard"
        else:
            policy = "hard_diverse"

    if policy == "balanced":
        return [c.cpu().clone() for c in random.sample(chunks, n)]

    if policy == "diverse":
        scores = byte_hist_distance(chunks)
        # choose evenly from low to high distance, not only extremes
        order = sorted(range(len(chunks)), key=lambda i: scores[i])
        picks = []
        for j in range(n):
            idx = order[int(j * (len(order) - 1) / max(1, n - 1))]
            picks.append(chunks[idx].cpu().clone())
        return picks

    # Hard examples = chunks the current/old model finds surprising.
    # This is the language-model analog of boundary examples.
    losses = [(i, chunk_loss(model, c, device)) for i, c in enumerate(chunks)]
    losses_sorted = sorted(losses, key=lambda x: x[1], reverse=True)

    if policy == "hard":
        chosen = [chunks[i].cpu().clone() for i, _ in losses_sorted[:n]]
        return chosen

    if policy == "hard_diverse":
        n_hard = int(0.50 * n)
        n_div = int(0.35 * n)
        n_proto = n - n_hard - n_div

        hard_ids = [i for i, _ in losses_sorted[:n_hard]]
        div_scores = byte_hist_distance(chunks)
        div_order = sorted(range(len(chunks)), key=lambda i: div_scores[i], reverse=True)
        proto_order = sorted(losses, key=lambda x: x[1])  # easiest chunks as prototypes

        chosen_ids = []
        for i in hard_ids:
            if i not in chosen_ids:
                chosen_ids.append(i)
        for i in div_order:
            if len(chosen_ids) >= n_hard + n_div:
                break
            if i not in chosen_ids:
                chosen_ids.append(i)
        for i, _ in proto_order:
            if len(chosen_ids) >= n:
                break
            if i not in chosen_ids:
                chosen_ids.append(i)
        return [chunks[i].cpu().clone() for i in chosen_ids]

    raise ValueError(f"Unknown memory policy: {cfg.policy}")


# ----------------------------
# Training / evaluation
# ----------------------------

@torch.no_grad()
def estimate_loss(model: TinyGPT, chunks: List[torch.Tensor], device: torch.device, eval_batches: int = 20, batch_size: int = 16) -> float:
    model.eval()
    losses = []
    if not chunks:
        return float("nan")
    for _ in range(eval_batches):
        x, y = sample_batch(chunks, batch_size, device)
        _, loss = model(x, y)
        losses.append(float(loss.item()))
    model.train()
    return sum(losses) / len(losses)


def distill_loss(student_logits: torch.Tensor, teacher_logits: torch.Tensor, T: float) -> torch.Tensor:
    # KL(teacher || student), averaged over sequence positions.
    s_logp = F.log_softmax(student_logits / T, dim=-1)
    t_p = F.softmax(teacher_logits / T, dim=-1)
    return (T * T) * F.kl_div(s_logp, t_p, reduction="batchmean") / student_logits.shape[1]


def anchor_loss(model: TinyGPT, old_state: Dict[str, torch.Tensor], device: torch.device) -> torch.Tensor:
    loss = torch.tensor(0.0, device=device)
    count = 0
    for name, p in model.named_parameters():
        if name in old_state:
            loss = loss + F.mse_loss(p, old_state[name].to(device), reduction="mean")
            count += 1
    return loss / max(1, count)


def train_phase(
    model: TinyGPT,
    phase: Dict,
    all_memory: List[torch.Tensor],
    old_teacher: Optional[TinyGPT],
    device: torch.device,
    args,
    phase_index: int,
    log_writer,
) -> None:
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    old_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()} if args.anchor_weight > 0 else None

    current_chunks = phase["chunks"]
    replay_available = len(all_memory) > 0

    # Memory-density policy: weak/no distill when memory is tiny, unless user overrides.
    if args.distill_weight < 0:
        spc_proxy = len(all_memory) / max(1, phase_index) if phase_index > 0 else 0
        if spc_proxy < 200:
            lambda_d = 0.0
        elif spc_proxy < 900:
            lambda_d = 0.05
        else:
            lambda_d = 0.15
    else:
        lambda_d = args.distill_weight

    for step in range(1, args.steps_per_phase + 1):
        optimizer.zero_grad(set_to_none=True)
        x_cur, y_cur = sample_batch(current_chunks, args.batch_size, device)
        logits_cur, ce_cur = model(x_cur, y_cur)
        loss = ce_cur
        ce_replay = torch.tensor(0.0, device=device)
        dloss = torch.tensor(0.0, device=device)
        aloss = torch.tensor(0.0, device=device)

        if replay_available and args.replay_batch > 0:
            x_rep, y_rep = sample_batch(all_memory, args.replay_batch, device)
            logits_rep, ce_replay = model(x_rep, y_rep)
            loss = loss + args.replay_ce_weight * ce_replay

            if old_teacher is not None and lambda_d > 0:
                with torch.no_grad():
                    teacher_logits, _ = old_teacher(x_rep)
                dloss = distill_loss(logits_rep, teacher_logits, args.temperature)
                loss = loss + lambda_d * dloss

        if old_state is not None and args.anchor_weight > 0:
            aloss = anchor_loss(model, old_state, device)
            loss = loss + args.anchor_weight * aloss

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
        optimizer.step()

        if step % args.print_every == 0 or step == 1 or step == args.steps_per_phase:
            print(
                f"phase {phase_index:02d} {phase['name']:<20} step {step:04d}/{args.steps_per_phase} "
                f"loss {loss.item():.4f} ce_cur {ce_cur.item():.4f} ce_rep {ce_replay.item():.4f} "
                f"distill {dloss.item():.4f} lambda_d {lambda_d:.3f} anchor {aloss.item():.6f}"
            )
            log_writer.writerow({
                "phase": phase_index,
                "phase_name": phase["name"],
                "step": step,
                "loss": float(loss.item()),
                "ce_current": float(ce_cur.item()),
                "ce_replay": float(ce_replay.item()),
                "distill": float(dloss.item()),
                "lambda_distill": float(lambda_d),
                "anchor": float(aloss.item()),
                "memory_chunks": len(all_memory),
            })


def evaluate_all_phases(model: TinyGPT, phases: List[Dict], seen_until: int, device: torch.device, args) -> Dict[str, float]:
    out = {}
    for i in range(seen_until + 1):
        loss = estimate_loss(model, phases[i]["chunks"], device, eval_batches=args.eval_batches, batch_size=args.batch_size)
        out[f"loss_phase_{i:02d}_{phases[i]['name']}"] = loss
        out[f"ppl_phase_{i:02d}_{phases[i]['name']}"] = math.exp(min(loss, 20))
    return out


# ----------------------------
# Main
# ----------------------------

def parse_args():
    p = argparse.ArgumentParser(description="A tiny continuously-learning replay/distillation language model.")
    p.add_argument("--corpus-dir", type=str, default="demo_corpus", help="Folder of .txt files; each file is one phase.")
    p.add_argument("--make-demo-corpus", action="store_true", help="Create a tiny demo corpus in corpus-dir first.")
    p.add_argument("--out-dir", type=str, default="runs_micro_lifelong")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", type=str, default="auto", choices=["auto", "cpu", "cuda"])

    p.add_argument("--block-size", type=int, default=128)
    p.add_argument("--n-embd", type=int, default=96)
    p.add_argument("--n-head", type=int, default=4)
    p.add_argument("--n-layer", type=int, default=2)
    p.add_argument("--dropout", type=float, default=0.1)

    p.add_argument("--steps-per-phase", type=int, default=300)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--replay-batch", type=int, default=16)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--weight-decay", type=float, default=0.01)
    p.add_argument("--grad-clip", type=float, default=1.0)
    p.add_argument("--replay-ce-weight", type=float, default=1.0)
    p.add_argument("--distill-weight", type=float, default=-1.0, help="-1 = auto by memory density; otherwise fixed lambda.")
    p.add_argument("--temperature", type=float, default=2.0)
    p.add_argument("--anchor-weight", type=float, default=0.0)

    p.add_argument("--memory-per-phase", type=int, default=300, help="Chunks retained after each phase.")
    p.add_argument("--memory-policy", type=str, default="auto", choices=["auto", "balanced", "diverse", "hard", "hard_diverse"])
    p.add_argument("--max-chars-per-file", type=int, default=None)
    p.add_argument("--eval-batches", type=int, default=20)
    p.add_argument("--print-every", type=int, default=50)
    p.add_argument("--generate-every-phase", action="store_true")
    p.add_argument("--prompt", type=str, default="Memory is")
    return p.parse_args()


def main():
    args = parse_args()
    set_seed(args.seed)
    corpus_dir = Path(args.corpus_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if args.make_demo_corpus:
        create_demo_corpus(corpus_dir)
        print(f"Demo corpus written to {corpus_dir.resolve()}")

    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)

    phases = load_phases(corpus_dir, block_size=args.block_size, max_chars_per_file=args.max_chars_per_file)
    print(f"Device: {device}")
    print(f"Loaded {len(phases)} phases from {corpus_dir}")
    for ph in phases:
        print(f"  phase {ph['id']:02d}: {ph['name']:<24} chars={len(ph['text']):>7} chunks={len(ph['chunks']):>5}")

    model = TinyGPT(
        block_size=args.block_size,
        n_embd=args.n_embd,
        n_head=args.n_head,
        n_layer=args.n_layer,
        dropout=args.dropout,
    ).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    print(f"Model parameters: {n_params:,} ({n_params/1e6:.3f}M)")

    memory_by_phase: Dict[int, List[torch.Tensor]] = {}
    eval_rows = []

    log_path = out_dir / "training_log.csv"
    with log_path.open("w", newline="", encoding="utf-8") as f:
        fieldnames = ["phase", "phase_name", "step", "loss", "ce_current", "ce_replay", "distill", "lambda_distill", "anchor", "memory_chunks"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for i, phase in enumerate(phases):
            print("\n" + "#" * 100)
            print(f"PHASE {i}: learning {phase['name']}")
            print("#" * 100)

            old_teacher = None
            if i > 0:
                old_teacher = copy.deepcopy(model).to(device)
                old_teacher.eval()
                for p in old_teacher.parameters():
                    p.requires_grad_(False)

            all_memory = []
            for chunks in memory_by_phase.values():
                all_memory.extend(chunks)
            print(f"Replay memory available: {len(all_memory)} chunks")

            train_phase(model, phase, all_memory, old_teacher, device, args, i, writer)

            # Evaluation after phase
            eval_dict = evaluate_all_phases(model, phases, i, device, args)
            eval_dict["after_phase"] = i
            eval_dict["after_phase_name"] = phase["name"]
            eval_rows.append(eval_dict)
            print("\nEvaluation on seen phases:")
            for k, v in eval_dict.items():
                if k.startswith("loss_phase"):
                    print(f"  {k}: {v:.4f} | ppl {math.exp(min(v,20)):.2f}")

            if args.generate_every_phase:
                print("\nSample generation:")
                print(model.generate(args.prompt, max_new_tokens=350, temperature=0.9, top_k=60, device=str(device)))

            # Update memory with selected chunks from this phase
            mem_cfg = MemoryConfig(memory_per_phase=args.memory_per_phase, policy=args.memory_policy)
            selected = select_memory_chunks(model, phase["chunks"], mem_cfg, device)
            memory_by_phase[i] = selected
            total_mem = sum(len(v) for v in memory_by_phase.values())
            print(f"Stored {len(selected)} chunks for phase {i}; total memory now {total_mem} chunks")

            torch.save({
                "model_state": model.state_dict(),
                "args": vars(args),
                "phase": i,
                "memory_by_phase": memory_by_phase,
            }, out_dir / f"checkpoint_after_phase_{i:02d}.pt")

    # Save evaluation CSV with flexible columns
    eval_path = out_dir / "eval_log.csv"
    all_fields = sorted(set().union(*(r.keys() for r in eval_rows))) if eval_rows else []
    with eval_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=all_fields)
        writer.writeheader()
        for r in eval_rows:
            writer.writerow(r)

    torch.save({
        "model_state": model.state_dict(),
        "args": vars(args),
        "memory_by_phase": memory_by_phase,
        "phase_names": [p["name"] for p in phases],
    }, out_dir / "model_final.pt")
    torch.save(memory_by_phase, out_dir / "memory.pt")

    print("\nFinal sample:")
    print(model.generate(args.prompt, max_new_tokens=500, temperature=0.9, top_k=60, device=str(device)))
    print(f"\nSaved outputs in: {out_dir.resolve()}")


if __name__ == "__main__":
    main()
