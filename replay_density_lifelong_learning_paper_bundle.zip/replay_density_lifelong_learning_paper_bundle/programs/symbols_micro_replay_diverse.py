# symbols_micro_replay_diverse.py
#
# Combined digits + alphabet continual-learning experiment.
#
# Dataset:
#   MNIST digits 0-9 + EMNIST Letters A-Z = 36 classes.
#
# Phase 1:
#   Train on old symbols only.
#
# Phase 2:
#   Train on held-out new symbols, with tiny old-symbol replay.
#
# Goal:
#   Stress-test whether diverse/boundary-aware replay can beat strong
#   class-balanced random replay, and whether distillation remains the key
#   ingredient for preserving old knowledge.
#
# Run:
#   python symbols_micro_replay_diverse.py
#
# Faster smoke test:
#   python symbols_micro_replay_diverse.py --phase1-epochs 1 --phase2-epochs 1 --seeds 42 --replay-fractions 0,0.01 --max-train-per-class 1000 --max-test-per-class 500
#
# Longer confirmatory run:
#   python symbols_micro_replay_diverse.py --seeds 42,43,44 --replay-fractions 0,0.005,0.01,0.02,0.05,0.10,0.20 --phase1-epochs 3 --phase2-epochs 3

import argparse
import csv
import math
import random
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import ConcatDataset, DataLoader, Dataset, Subset
from torchvision import datasets, transforms
from torchvision.transforms import functional as TF


# -----------------------------
# Symbol map
# -----------------------------

DIGIT_NAMES = [str(i) for i in range(10)]
LETTER_NAMES = [chr(ord("A") + i) for i in range(26)]
CLASS_NAMES = DIGIT_NAMES + LETTER_NAMES
N_CLASSES = 36

DEFAULT_HELD_OUT = ["3", "6", "9", "C", "F", "J", "Q", "V", "X", "Y", "Z"]


def symbol_to_class_id(symbol: str) -> int:
    symbol = symbol.strip().upper()
    if symbol.isdigit():
        n = int(symbol)
        if 0 <= n <= 9:
            return n
    if len(symbol) == 1 and "A" <= symbol <= "Z":
        return 10 + ord(symbol) - ord("A")
    raise ValueError(f"Unknown symbol: {symbol}")


def class_id_to_symbol(cid: int) -> str:
    return CLASS_NAMES[cid]


def parse_symbols(text: str) -> List[int]:
    return [symbol_to_class_id(x) for x in text.split(",") if x.strip()]


def symbols_string(class_ids: Sequence[int]) -> str:
    return ",".join(class_id_to_symbol(i) for i in class_ids)


# -----------------------------
# Utilities
# -----------------------------


def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_float_list(text: str) -> List[float]:
    vals = []
    for part in text.split(","):
        part = part.strip()
        if not part:
            continue
        val = float(part)
        if val < 0.0 or val >= 1.0:
            raise ValueError("Replay fractions must be >= 0 and < 1")
        vals.append(val)
    return vals


def parse_int_list(text: str) -> List[int]:
    return [int(x.strip()) for x in text.split(",") if x.strip()]


def pct(x: float) -> str:
    return f"{100.0 * x:5.2f}%"


def harmonic_mean(a: float, b: float) -> float:
    if a <= 0 or b <= 0:
        return 0.0
    return 2.0 * a * b / (a + b)


# -----------------------------
# Dataset wrappers
# -----------------------------


class LabelOffsetDataset(Dataset):
    """Wrap a dataset and remap labels."""

    def __init__(self, dataset: Dataset, label_fn, name: str):
        self.dataset = dataset
        self.label_fn = label_fn
        self.name = name

        # Build labels once so we can filter quickly.
        labels = []
        for i in range(len(dataset)):
            _x, y = dataset[i]
            labels.append(int(label_fn(int(y))))
        self.targets = torch.tensor(labels, dtype=torch.long)

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int):
        x, y = self.dataset[idx]
        return x, int(self.label_fn(int(y)))


class CombinedLabeledDataset(Dataset):
    """Concat-like dataset with a unified targets vector."""

    def __init__(self, datasets_: Sequence[Dataset]):
        self.datasets = list(datasets_)
        self.cumulative_sizes = []
        total = 0
        targets = []
        for ds in self.datasets:
            total += len(ds)
            self.cumulative_sizes.append(total)
            if hasattr(ds, "targets"):
                targets.extend([int(x) for x in ds.targets])
            else:
                for i in range(len(ds)):
                    _x, y = ds[i]
                    targets.append(int(y))
        self.targets = torch.tensor(targets, dtype=torch.long)

    def __len__(self) -> int:
        return self.cumulative_sizes[-1] if self.cumulative_sizes else 0

    def __getitem__(self, idx: int):
        if idx < 0:
            idx += len(self)
        ds_idx = 0
        while idx >= self.cumulative_sizes[ds_idx]:
            ds_idx += 1
        prev = 0 if ds_idx == 0 else self.cumulative_sizes[ds_idx - 1]
        return self.datasets[ds_idx][idx - prev]


class FlaggedDataset(Dataset):
    """Wraps a dataset and returns x, y, is_old_replay."""

    def __init__(self, dataset: Dataset, is_old_replay: int):
        self.dataset = dataset
        self.is_old_replay = int(is_old_replay)

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int):
        x, y = self.dataset[idx]
        return x, int(y), self.is_old_replay


class NewPlusReplayDataset(Dataset):
    def __init__(self, new_subset: Dataset, replay_subset: Optional[Dataset]):
        parts: List[Dataset] = [FlaggedDataset(new_subset, 0)]
        if replay_subset is not None and len(replay_subset) > 0:
            parts.append(FlaggedDataset(replay_subset, 1))
        self.dataset = ConcatDataset(parts)

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int):
        return self.dataset[idx]


class FeatureSubset(Dataset):
    """Subset that also preserves a .targets vector."""

    def __init__(self, base: Dataset, indices: Sequence[int]):
        self.base = base
        self.indices = list(indices)
        if hasattr(base, "targets"):
            self.targets = torch.tensor([int(base.targets[i]) for i in self.indices], dtype=torch.long)
        else:
            labels = []
            for i in self.indices:
                _x, y = base[i]
                labels.append(int(y))
            self.targets = torch.tensor(labels, dtype=torch.long)

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, idx: int):
        return self.base[self.indices[idx]]


# -----------------------------
# Data creation
# -----------------------------


def emnist_orientation_fix(img):
    # EMNIST images are commonly stored rotated/transposed relative to MNIST.
    # This transform makes letters visually upright for standard display/training.
    return TF.hflip(TF.rotate(img, -90))


def make_combined_dataset(
    data_dir: str,
    train: bool,
    fix_emnist_orientation: bool = True,
) -> CombinedLabeledDataset:
    mnist_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])

    emnist_transforms = []
    if fix_emnist_orientation:
        emnist_transforms.append(transforms.Lambda(emnist_orientation_fix))
    emnist_transforms.extend([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])
    emnist_transform = transforms.Compose(emnist_transforms)

    mnist = datasets.MNIST(root=data_dir, train=train, download=True, transform=mnist_transform)
    # EMNIST Letters labels are 1..26. Map to 10..35.
    emnist_letters = datasets.EMNIST(
        root=data_dir,
        split="letters",
        train=train,
        download=True,
        transform=emnist_transform,
    )

    mnist_wrapped = LabelOffsetDataset(mnist, lambda y: y, "MNIST")
    emnist_wrapped = LabelOffsetDataset(emnist_letters, lambda y: 10 + (y - 1), "EMNIST-Letters")

    return CombinedLabeledDataset([mnist_wrapped, emnist_wrapped])


def class_filtered_indices(dataset: Dataset, allowed_classes: Sequence[int]) -> List[int]:
    allowed = set(int(c) for c in allowed_classes)
    labels = dataset.targets if hasattr(dataset, "targets") else None
    if labels is not None:
        return [i for i, y in enumerate(labels) if int(y) in allowed]
    out = []
    for i in range(len(dataset)):
        _x, y = dataset[i]
        if int(y) in allowed:
            out.append(i)
    return out


def cap_per_class_indices(
    dataset: Dataset,
    indices: Sequence[int],
    max_per_class: Optional[int],
    seed: int,
) -> List[int]:
    if max_per_class is None or max_per_class <= 0:
        return list(indices)

    rng = random.Random(seed)
    by_class: Dict[int, List[int]] = {}
    targets = dataset.targets
    for idx in indices:
        y = int(targets[idx])
        by_class.setdefault(y, []).append(int(idx))

    capped: List[int] = []
    for c, vals in sorted(by_class.items()):
        vals = list(vals)
        rng.shuffle(vals)
        capped.extend(vals[:max_per_class])
    rng.shuffle(capped)
    return capped


def make_data_splits(
    data_dir: str,
    old_classes: List[int],
    new_classes: List[int],
    batch_size: int,
    seed: int,
    max_train_per_class: Optional[int],
    max_test_per_class: Optional[int],
    fix_emnist_orientation: bool,
):
    train_full = make_combined_dataset(data_dir, train=True, fix_emnist_orientation=fix_emnist_orientation)
    test_full = make_combined_dataset(data_dir, train=False, fix_emnist_orientation=fix_emnist_orientation)

    train_old_indices = class_filtered_indices(train_full, old_classes)
    train_new_indices = class_filtered_indices(train_full, new_classes)
    test_old_indices = class_filtered_indices(test_full, old_classes)
    test_new_indices = class_filtered_indices(test_full, new_classes)

    train_old_indices = cap_per_class_indices(train_full, train_old_indices, max_train_per_class, seed + 1)
    train_new_indices = cap_per_class_indices(train_full, train_new_indices, max_train_per_class, seed + 2)
    test_old_indices = cap_per_class_indices(test_full, test_old_indices, max_test_per_class, seed + 3)
    test_new_indices = cap_per_class_indices(test_full, test_new_indices, max_test_per_class, seed + 4)

    train_old = FeatureSubset(train_full, train_old_indices)
    train_new = FeatureSubset(train_full, train_new_indices)
    test_old = FeatureSubset(test_full, test_old_indices)
    test_new = FeatureSubset(test_full, test_new_indices)

    train_old_loader = DataLoader(train_old, batch_size=batch_size, shuffle=True)
    test_old_loader = DataLoader(test_old, batch_size=batch_size, shuffle=False)
    test_new_loader = DataLoader(test_new, batch_size=batch_size, shuffle=False)
    test_all_loader = DataLoader(
        FeatureSubset(test_full, test_old_indices + test_new_indices),
        batch_size=batch_size,
        shuffle=False,
    )

    return {
        "train_full": train_full,
        "test_full": test_full,
        "train_old": train_old,
        "train_new": train_new,
        "test_old": test_old,
        "test_new": test_new,
        "train_old_loader": train_old_loader,
        "test_old_loader": test_old_loader,
        "test_new_loader": test_new_loader,
        "test_all_loader": test_all_loader,
    }


# -----------------------------
# Model
# -----------------------------


class SmallCNN36(nn.Module):
    def __init__(self, n_classes: int = N_CLASSES):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, n_classes)

    def features(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = torch.flatten(x, 1)
        x = F.relu(self.fc1(x))
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(self.features(x))


def make_optimizer(model: SmallCNN36, lr: float = 1e-3, soft: bool = False):
    if soft:
        return torch.optim.Adam([
            {"name": "conv1", "params": model.conv1.parameters(), "lr": lr * 0.25},
            {"name": "conv2", "params": model.conv2.parameters(), "lr": lr * 0.50},
            {"name": "fc1", "params": model.fc1.parameters(), "lr": lr},
            {"name": "fc2", "params": model.fc2.parameters(), "lr": lr},
        ])
    return torch.optim.Adam(model.parameters(), lr=lr)


# -----------------------------
# Evaluation / training
# -----------------------------


def mask_logits(logits: torch.Tensor, allowed_classes: Optional[Sequence[int]]) -> torch.Tensor:
    if allowed_classes is None:
        return logits
    out = torch.full_like(logits, -1e9)
    idx = torch.tensor(list(allowed_classes), dtype=torch.long, device=logits.device)
    out[:, idx] = logits[:, idx]
    return out


@torch.no_grad()
def accuracy(model: nn.Module, loader: DataLoader, device: str) -> float:
    model.eval()
    correct = 0
    total = 0
    for batch in loader:
        if len(batch) == 3:
            x, y, _flag = batch
        else:
            x, y = batch
        x = x.to(device)
        y = y.to(device)
        pred = model(x).argmax(dim=1)
        correct += int((pred == y).sum().item())
        total += int(y.numel())
    return correct / max(1, total)


def train_phase1(
    model: SmallCNN36,
    loader: DataLoader,
    optimizer,
    device: str,
    old_classes: Sequence[int],
    epochs: int,
    test_old_loader: DataLoader,
):
    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0
        total_seen = 0
        for x, y in loader:
            x = x.to(device)
            y = y.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = mask_logits(model(x), old_classes)
            loss = F.cross_entropy(logits, y)
            loss.backward()
            optimizer.step()
            total_loss += float(loss.item()) * x.size(0)
            total_seen += x.size(0)
        old_acc = accuracy(model, test_old_loader, device)
        print(f"Phase 1 epoch {epoch:02d} | loss {total_loss / max(1, total_seen):.4f} | old_acc {old_acc:.4f}")


def anchor_penalty(model: nn.Module, old_state: Dict[str, torch.Tensor]) -> torch.Tensor:
    total = None
    count = 0
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        old = old_state[name].to(p.device)
        val = (p - old).pow(2).mean()
        total = val if total is None else total + val
        count += 1
    if total is None:
        return torch.tensor(0.0, device=next(model.parameters()).device)
    return total / max(1, count)


def distill_loss_on_old_examples(
    student_logits: torch.Tensor,
    teacher_logits: torch.Tensor,
    old_classes_tensor: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    s = student_logits[:, old_classes_tensor] / temperature
    t = teacher_logits[:, old_classes_tensor] / temperature
    return F.kl_div(
        F.log_softmax(s, dim=1),
        F.softmax(t, dim=1),
        reduction="batchmean",
    ) * (temperature ** 2)


def train_phase2(
    model: SmallCNN36,
    teacher: SmallCNN36,
    loader: DataLoader,
    optimizer,
    device: str,
    epochs: int,
    old_state: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    use_anchor: bool,
    use_distill: bool,
    anchor_lambda: float,
    distill_lambda: float,
    temperature: float,
    test_old_loader: DataLoader,
    quiet: bool = False,
):
    teacher.eval()
    old_classes_tensor = torch.tensor(list(old_classes), dtype=torch.long, device=device)

    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = total_ce = total_anchor = total_distill = 0.0
        total_seen = 0

        for x, y, is_old in loader:
            x = x.to(device)
            y = y.to(device)
            is_old = is_old.to(device).bool()
            optimizer.zero_grad(set_to_none=True)

            logits = model(x)
            ce = F.cross_entropy(logits, y)

            a = torch.tensor(0.0, device=device)
            if use_anchor:
                a = anchor_penalty(model, old_state)

            d = torch.tensor(0.0, device=device)
            if use_distill and is_old.any():
                with torch.no_grad():
                    teacher_logits = teacher(x[is_old])
                d = distill_loss_on_old_examples(
                    logits[is_old],
                    teacher_logits,
                    old_classes_tensor,
                    temperature,
                )

            loss = ce + anchor_lambda * a + distill_lambda * d
            loss.backward()
            optimizer.step()

            n = x.size(0)
            total_loss += float(loss.item()) * n
            total_ce += float(ce.item()) * n
            total_anchor += float(a.item()) * n
            total_distill += float(d.item()) * n
            total_seen += n

        old_acc = accuracy(model, test_old_loader, device)
        if not quiet:
            print(
                f"Phase 2 epoch {epoch:02d} | "
                f"loss {total_loss / max(1, total_seen):.4f} | "
                f"ce {total_ce / max(1, total_seen):.4f} | "
                f"anchor {total_anchor / max(1, total_seen):.6f} | "
                f"distill {total_distill / max(1, total_seen):.4f} | "
                f"old_acc {old_acc:.4f}"
            )


# -----------------------------
# Memory selection
# -----------------------------


@torch.no_grad()
def collect_old_model_stats(
    model: SmallCNN36,
    train_old: Dataset,
    old_classes: Sequence[int],
    batch_size: int,
    device: str,
) -> Dict[str, torch.Tensor]:
    loader = DataLoader(train_old, batch_size=batch_size, shuffle=False)
    model.eval()

    all_features = []
    all_logits = []
    all_labels = []

    for x, y in loader:
        x = x.to(device)
        feats = model.features(x)
        logits = model.fc2(feats)
        all_features.append(feats.cpu())
        all_logits.append(logits.cpu())
        all_labels.append(torch.tensor(y, dtype=torch.long))

    features = torch.cat(all_features, dim=0)
    logits = torch.cat(all_logits, dim=0)
    labels = torch.cat(all_labels, dim=0)

    old_idx = torch.tensor(list(old_classes), dtype=torch.long)
    old_logits = logits[:, old_idx]
    probs = F.softmax(old_logits, dim=1)
    top2 = torch.topk(probs, k=min(2, probs.size(1)), dim=1).values
    if top2.size(1) == 1:
        margin = torch.ones(top2.size(0))
    else:
        margin = top2[:, 0] - top2[:, 1]
    confidence = top2[:, 0]
    entropy = -(probs * (probs.clamp_min(1e-12).log())).sum(dim=1)

    centers: Dict[int, torch.Tensor] = {}
    distances = torch.zeros(len(train_old))
    for c in old_classes:
        mask = labels == int(c)
        if mask.any():
            center = features[mask].mean(dim=0)
            centers[int(c)] = center
            distances[mask] = torch.norm(features[mask] - center, dim=1)

    return {
        "features": features,
        "labels": labels,
        "logits": logits,
        "margin": margin,
        "confidence": confidence,
        "entropy": entropy,
        "distance": distances,
    }


def budget_from_fraction(n_new: int, replay_fraction: float) -> int:
    if replay_fraction <= 0:
        return 0
    return int((replay_fraction / (1.0 - replay_fraction)) * n_new)


def allocate_budget_by_class(labels: torch.Tensor, old_classes: Sequence[int], budget: int) -> Dict[int, int]:
    if budget <= 0:
        return {int(c): 0 for c in old_classes}
    present = [int(c) for c in old_classes if int((labels == int(c)).sum().item()) > 0]
    if not present:
        return {}
    base = budget // len(present)
    rem = budget % len(present)
    alloc = {}
    for i, c in enumerate(present):
        alloc[c] = base + (1 if i < rem else 0)
    return alloc


def balanced_random_indices(labels: torch.Tensor, old_classes: Sequence[int], budget: int, seed: int) -> List[int]:
    rng = random.Random(seed)
    alloc = allocate_budget_by_class(labels, old_classes, budget)
    selected: List[int] = []
    for c, k in alloc.items():
        idx = torch.where(labels == c)[0].tolist()
        rng.shuffle(idx)
        selected.extend(idx[:min(k, len(idx))])
    rng.shuffle(selected)
    return selected


def sorted_take_evenly(indices: List[int], scores: torch.Tensor, k: int, reverse: bool = False) -> List[int]:
    if k <= 0 or not indices:
        return []
    if len(indices) <= k:
        return list(indices)
    idx_sorted = sorted(indices, key=lambda i: float(scores[i]), reverse=reverse)
    if k == 1:
        return [idx_sorted[len(idx_sorted) // 2]]
    picks = []
    for j in range(k):
        pos = round(j * (len(idx_sorted) - 1) / (k - 1))
        picks.append(idx_sorted[pos])
    return picks


def boundary_diverse_indices(
    stats: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    budget: int,
    seed: int,
    boundary_frac: float = 0.50,
    diverse_frac: float = 0.35,
    prototype_frac: float = 0.15,
) -> List[int]:
    """
    Stress-test selector.

    Per class, select a mix of:
      - low-margin examples: decision-boundary memories
      - diverse examples: evenly spread by embedding distance from class center
      - prototype examples: near class centers

    This is deliberately stronger than the earlier naive curated replay.
    """
    rng = random.Random(seed)
    labels = stats["labels"]
    margin = stats["margin"]
    distance = stats["distance"]
    alloc = allocate_budget_by_class(labels, old_classes, budget)
    selected: List[int] = []

    for c, k in alloc.items():
        if k <= 0:
            continue
        class_idx = torch.where(labels == c)[0].tolist()
        if len(class_idx) <= k:
            selected.extend(class_idx)
            continue

        rng.shuffle(class_idx)
        n_boundary = int(round(k * boundary_frac))
        n_diverse = int(round(k * diverse_frac))
        n_proto = k - n_boundary - n_diverse
        if n_proto < 0:
            n_proto = 0

        # 1) Low margin = ambiguous/boundary examples.
        boundary = sorted(class_idx, key=lambda i: float(margin[i]))[:n_boundary]
        used = set(boundary)
        remaining = [i for i in class_idx if i not in used]

        # 2) Diversity by selecting evenly across center-distance spectrum.
        diverse = sorted_take_evenly(remaining, distance, n_diverse, reverse=False)
        used.update(diverse)
        remaining = [i for i in remaining if i not in used]

        # 3) Prototypes near class center.
        proto = sorted(remaining, key=lambda i: float(distance[i]))[:n_proto]

        picked = boundary + diverse + proto
        if len(picked) < k:
            rest = [i for i in class_idx if i not in set(picked)]
            rng.shuffle(rest)
            picked.extend(rest[: k - len(picked)])
        selected.extend(picked[:k])

    rng.shuffle(selected)
    return selected


def pure_diverse_indices(
    stats: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    budget: int,
    seed: int,
) -> List[int]:
    labels = stats["labels"]
    distance = stats["distance"]
    alloc = allocate_budget_by_class(labels, old_classes, budget)
    rng = random.Random(seed)
    selected: List[int] = []
    for c, k in alloc.items():
        idx = torch.where(labels == c)[0].tolist()
        rng.shuffle(idx)
        selected.extend(sorted_take_evenly(idx, distance, k, reverse=False))
    rng.shuffle(selected)
    return selected


def make_replay_subset(
    train_old: Dataset,
    stats: Dict[str, torch.Tensor],
    old_classes: Sequence[int],
    budget: int,
    selector: str,
    seed: int,
) -> Optional[Dataset]:
    if budget <= 0 or selector == "none":
        return None
    labels = stats["labels"] if stats is not None else train_old.targets

    if selector == "random":
        idx = balanced_random_indices(labels, old_classes, budget, seed)
    elif selector == "diverse":
        idx = pure_diverse_indices(stats, old_classes, budget, seed)
    elif selector == "boundary_diverse":
        idx = boundary_diverse_indices(stats, old_classes, budget, seed)
    else:
        raise ValueError(f"Unknown selector: {selector}")

    return FeatureSubset(train_old, idx)


# -----------------------------
# Strategies
# -----------------------------


@dataclass
class Strategy:
    name: str
    selector: str
    use_anchor: bool = False
    use_distill: bool = False
    soft: bool = False


STRATEGIES = [
    Strategy("No replay", "none"),
    Strategy("Balanced random replay", "random"),
    Strategy("Pure diverse replay", "diverse"),
    Strategy("Boundary-diverse replay", "boundary_diverse"),
    Strategy("Balanced random + anchor", "random", use_anchor=True),
    Strategy("Boundary-diverse + anchor", "boundary_diverse", use_anchor=True),
    Strategy("Balanced random + distill", "random", use_distill=True),
    Strategy("Pure diverse + distill", "diverse", use_distill=True),
    Strategy("Boundary-diverse + distill", "boundary_diverse", use_distill=True),
    Strategy("Balanced random + anchor/distill", "random", use_anchor=True, use_distill=True),
    Strategy("Boundary-diverse + anchor/distill", "boundary_diverse", use_anchor=True, use_distill=True),
    Strategy("Balanced random + soft + anchor/distill", "random", use_anchor=True, use_distill=True, soft=True),
    Strategy("Boundary-diverse + soft + anchor/distill", "boundary_diverse", use_anchor=True, use_distill=True, soft=True),
]


def select_strategies(names_text: Optional[str]) -> List[Strategy]:
    if not names_text:
        return STRATEGIES
    wanted = {x.strip().lower() for x in names_text.split(",") if x.strip()}
    out = [s for s in STRATEGIES if s.name.lower() in wanted]
    if not out:
        raise ValueError("No strategies matched --strategies. Use exact strategy names, comma-separated.")
    return out


# -----------------------------
# Experiment
# -----------------------------


def run_one_condition(
    strategy: Strategy,
    replay_fraction: float,
    seed: int,
    data,
    old_classes: Sequence[int],
    new_classes: Sequence[int],
    phase1_state: Dict[str, torch.Tensor],
    old_state_cpu: Dict[str, torch.Tensor],
    stats,
    old_acc_phase1: float,
    new_acc_phase1: float,
    all_acc_phase1: float,
    args,
    device: str,
) -> Dict[str, object]:
    condition_seed = seed + int(replay_fraction * 1_000_000) + abs(hash(strategy.name)) % 100_000
    set_seed(condition_seed)

    model = SmallCNN36().to(device)
    model.load_state_dict(phase1_state)

    teacher = SmallCNN36().to(device)
    teacher.load_state_dict(phase1_state)
    teacher.eval()
    for p in teacher.parameters():
        p.requires_grad = False

    budget = budget_from_fraction(len(data["train_new"]), replay_fraction)
    replay_subset = make_replay_subset(
        train_old=data["train_old"],
        stats=stats,
        old_classes=old_classes,
        budget=budget,
        selector=strategy.selector,
        seed=condition_seed + 17,
    )

    phase2_dataset = NewPlusReplayDataset(data["train_new"], replay_subset)
    generator = torch.Generator()
    generator.manual_seed(condition_seed + 23)
    phase2_loader = DataLoader(
        phase2_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        generator=generator,
    )

    optimizer = make_optimizer(model, lr=args.lr, soft=strategy.soft)

    if not args.quiet:
        print("=" * 148)
        print(f"Seed={seed} | Replay={pct(replay_fraction)} | {strategy.name} | budget={budget}")
        print("=" * 148)

    train_phase2(
        model=model,
        teacher=teacher,
        loader=phase2_loader,
        optimizer=optimizer,
        device=device,
        epochs=args.phase2_epochs,
        old_state=old_state_cpu,
        old_classes=old_classes,
        use_anchor=strategy.use_anchor,
        use_distill=strategy.use_distill,
        anchor_lambda=args.anchor_lambda,
        distill_lambda=args.distill_lambda,
        temperature=args.temperature,
        test_old_loader=data["test_old_loader"],
        quiet=args.quiet,
    )

    old_acc_phase2 = accuracy(model, data["test_old_loader"], device)
    new_acc_phase2 = accuracy(model, data["test_new_loader"], device)
    all_acc_phase2 = accuracy(model, data["test_all_loader"], device)
    forgetting = old_acc_phase1 - old_acc_phase2
    h = harmonic_mean(old_acc_phase2, new_acc_phase2)
    stability_score = all_acc_phase2 - forgetting

    result = {
        "seed": seed,
        "strategy": strategy.name,
        "selector": strategy.selector,
        "use_anchor": strategy.use_anchor,
        "use_distill": strategy.use_distill,
        "soft": strategy.soft,
        "replay_fraction": replay_fraction,
        "budget": budget,
        "old_acc_phase1": old_acc_phase1,
        "new_acc_phase1": new_acc_phase1,
        "all_acc_phase1": all_acc_phase1,
        "old_acc_phase2": old_acc_phase2,
        "new_acc_phase2": new_acc_phase2,
        "all_acc_phase2": all_acc_phase2,
        "forgetting": forgetting,
        "harmonic_old_new": h,
        "stability_score": stability_score,
    }

    if not args.quiet:
        print(
            f"Result | Old P2={old_acc_phase2:.4f} | New P2={new_acc_phase2:.4f} | "
            f"All P2={all_acc_phase2:.4f} | Forget={forgetting:.4f} | "
            f"Score={stability_score:.4f} | H(old,new)={h:.4f}\n"
        )

    return result


def aggregate_results(results: List[Dict[str, object]]) -> List[Dict[str, object]]:
    keys = sorted(set((r["replay_fraction"], r["strategy"]) for r in results))
    out = []
    metrics = [
        "old_acc_phase2",
        "new_acc_phase2",
        "all_acc_phase2",
        "forgetting",
        "harmonic_old_new",
        "stability_score",
    ]
    for frac, strategy in keys:
        rows = [r for r in results if r["replay_fraction"] == frac and r["strategy"] == strategy]
        rec = {"replay_fraction": frac, "strategy": strategy, "n": len(rows)}
        for m in metrics:
            vals = [float(r[m]) for r in rows]
            mean = sum(vals) / len(vals)
            if len(vals) > 1:
                var = sum((x - mean) ** 2 for x in vals) / (len(vals) - 1)
                sd = math.sqrt(var)
            else:
                sd = 0.0
            rec[m + "_mean"] = mean
            rec[m + "_sd"] = sd
        out.append(rec)
    return out


def print_summary(results: List[Dict[str, object]]) -> None:
    agg = aggregate_results(results)

    print("\n\nFINAL AGGREGATE TABLE")
    print("=" * 170)
    print(
        f"{'Replay':>8s} {'Strategy':48s} {'Old P2':>9s} {'New P2':>9s} "
        f"{'All P2':>9s} {'Forget':>9s} {'H':>9s} {'Score':>9s} {'n':>4s}"
    )
    print("-" * 170)
    for r in sorted(agg, key=lambda x: (float(x["replay_fraction"]), str(x["strategy"]))):
        print(
            f"{pct(float(r['replay_fraction'])):>8s} "
            f"{str(r['strategy']):48s} "
            f"{float(r['old_acc_phase2_mean']):9.4f} "
            f"{float(r['new_acc_phase2_mean']):9.4f} "
            f"{float(r['all_acc_phase2_mean']):9.4f} "
            f"{float(r['forgetting_mean']):9.4f} "
            f"{float(r['harmonic_old_new_mean']):9.4f} "
            f"{float(r['stability_score_mean']):9.4f} "
            f"{int(r['n']):4d}"
        )

    print("\n\nBEST BY REPLAY FRACTION")
    print("=" * 170)
    print("Sorted by harmonic mean of old/new accuracy, then stability_score.")
    for frac in sorted(set(float(r["replay_fraction"]) for r in results)):
        rows = [r for r in agg if float(r["replay_fraction"]) == frac]
        rows = sorted(rows, key=lambda x: (float(x["harmonic_old_new_mean"]), float(x["stability_score_mean"])), reverse=True)
        b = rows[0]
        print(
            f"Replay {pct(frac)} | best: {b['strategy']} | "
            f"Old={float(b['old_acc_phase2_mean']):.4f} | "
            f"New={float(b['new_acc_phase2_mean']):.4f} | "
            f"All={float(b['all_acc_phase2_mean']):.4f} | "
            f"Forget={float(b['forgetting_mean']):.4f} | "
            f"H={float(b['harmonic_old_new_mean']):.4f} | "
            f"Score={float(b['stability_score_mean']):.4f}"
        )


def save_csv(path: str, rows: List[Dict[str, object]]) -> None:
    if not rows:
        return
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def save_agg_csv(path: str, rows: List[Dict[str, object]]) -> None:
    agg = aggregate_results(rows)
    if not agg:
        return
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(agg[0].keys()))
        writer.writeheader()
        writer.writerows(agg)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=str, default="./data")
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--phase1-epochs", type=int, default=3)
    parser.add_argument("--phase2-epochs", type=int, default=3)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--anchor-lambda", type=float, default=5.0)
    parser.add_argument("--distill-lambda", type=float, default=0.7)
    parser.add_argument("--temperature", type=float, default=2.0)
    parser.add_argument("--held-out", type=str, default=",".join(DEFAULT_HELD_OUT))
    parser.add_argument("--replay-fractions", type=str, default="0,0.005,0.01,0.02,0.05,0.10,0.20")
    parser.add_argument("--seeds", type=str, default="42")
    parser.add_argument("--max-train-per-class", type=int, default=0, help="0 = no cap")
    parser.add_argument("--max-test-per-class", type=int, default=0, help="0 = no cap")
    parser.add_argument("--no-emnist-orientation-fix", action="store_true")
    parser.add_argument("--strategies", type=str, default=None, help="Optional comma-separated exact strategy names")
    parser.add_argument("--csv", type=str, default="symbols_micro_replay_results.csv")
    parser.add_argument("--agg-csv", type=str, default="symbols_micro_replay_aggregate.csv")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"

    held_out = parse_symbols(args.held_out)
    all_classes = list(range(N_CLASSES))
    new_classes = sorted(set(held_out))
    old_classes = [c for c in all_classes if c not in set(new_classes)]
    replay_fractions = parse_float_list(args.replay_fractions)
    seeds = parse_int_list(args.seeds)
    strategies = select_strategies(args.strategies)

    max_train_per_class = args.max_train_per_class if args.max_train_per_class > 0 else None
    max_test_per_class = args.max_test_per_class if args.max_test_per_class > 0 else None

    print(f"Device:                  {device}")
    print(f"Classes:                 digits 0-9 + letters A-Z = {N_CLASSES}")
    print(f"Old symbols:             {symbols_string(old_classes)}")
    print(f"Held-out symbols:        {symbols_string(new_classes)}")
    print(f"Old class count:         {len(old_classes)}")
    print(f"Held-out class count:    {len(new_classes)}")
    print(f"Replay fractions:        {replay_fractions}")
    print(f"Seeds:                   {seeds}")
    print(f"Phase 1 epochs:          {args.phase1_epochs}")
    print(f"Phase 2 epochs:          {args.phase2_epochs}")
    print(f"Strategies:              {len(strategies)}")
    print("Dataset:                 MNIST digits + EMNIST Letters")
    print("Replay baselines:        class-balanced random, pure diverse, boundary-diverse")
    print()

    all_results: List[Dict[str, object]] = []

    for seed in seeds:
        set_seed(seed)
        data = make_data_splits(
            data_dir=args.data_dir,
            old_classes=old_classes,
            new_classes=new_classes,
            batch_size=args.batch_size,
            seed=seed,
            max_train_per_class=max_train_per_class,
            max_test_per_class=max_test_per_class,
            fix_emnist_orientation=not args.no_emnist_orientation_fix,
        )
        print(f"Train old examples:      {len(data['train_old'])}")
        print(f"Train new examples:      {len(data['train_new'])}")
        print(f"Test old examples:       {len(data['test_old'])}")
        print(f"Test new examples:       {len(data['test_new'])}")
        print()

        print("#" * 120)
        print(f"PHASE 1: train one conventional CNN on old symbols only | seed={seed}")
        print("#" * 120)

        model = SmallCNN36().to(device)
        opt = make_optimizer(model, lr=args.lr, soft=False)
        train_phase1(
            model=model,
            loader=data["train_old_loader"],
            optimizer=opt,
            device=device,
            old_classes=old_classes,
            epochs=args.phase1_epochs,
            test_old_loader=data["test_old_loader"],
        )

        old_acc_phase1 = accuracy(model, data["test_old_loader"], device)
        new_acc_phase1 = accuracy(model, data["test_new_loader"], device)
        all_acc_phase1 = accuracy(model, data["test_all_loader"], device)

        print(
            f"Phase 1 saved state | old={old_acc_phase1:.4f} | "
            f"new={new_acc_phase1:.4f} | all={all_acc_phase1:.4f}"
        )

        phase1_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        old_state_cpu = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

        print("Collecting old-model feature/logit statistics for replay selection...")
        stats = collect_old_model_stats(
            model=model,
            train_old=data["train_old"],
            old_classes=old_classes,
            batch_size=args.batch_size,
            device=device,
        )
        print("Stats collected.")

        for replay_fraction in replay_fractions:
            for strategy in strategies:
                result = run_one_condition(
                    strategy=strategy,
                    replay_fraction=replay_fraction,
                    seed=seed,
                    data=data,
                    old_classes=old_classes,
                    new_classes=new_classes,
                    phase1_state=phase1_state,
                    old_state_cpu=old_state_cpu,
                    stats=stats,
                    old_acc_phase1=old_acc_phase1,
                    new_acc_phase1=new_acc_phase1,
                    all_acc_phase1=all_acc_phase1,
                    args=args,
                    device=device,
                )
                all_results.append(result)
                save_csv(args.csv, all_results)
                save_agg_csv(args.agg_csv, all_results)

    print_summary(all_results)
    save_csv(args.csv, all_results)
    save_agg_csv(args.agg_csv, all_results)
    print(f"\nSaved per-run results to: {args.csv}")
    print(f"Saved aggregate results to: {args.agg_csv}")


if __name__ == "__main__":
    main()
