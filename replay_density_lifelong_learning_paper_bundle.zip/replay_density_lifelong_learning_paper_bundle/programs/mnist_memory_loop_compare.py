# mnist_memory_loop_compare.py
#
# Continual MNIST experiment with a learned/curated replay memory loop.
#
# Same CNN architecture for all conditions. No extra model parameters are added.
# The only differences are training strategy in Phase 2:
#   1. Conventional CNN, no replay
#   2. Conventional CNN, random replay
#   3. Conventional CNN, curated replay chosen by the trained model
#   4. Curated replay + soft consolidation learning rates
#   5. Curated replay + soft consolidation + anchoring + distillation
#
# Concept:
#   Phase 1: learn old digits only.
#   Phase 2: learn held-out digits, with or without an old-digit memory loop.
#
# Run:
#   pip install torch torchvision
#   python mnist_memory_loop_compare.py
#
# Faster first run:
#   python mnist_memory_loop_compare.py --phase1-epochs 2 --phase2-epochs 2 --replay-fractions 0,0.05,0.10
#
# More serious run:
#   python mnist_memory_loop_compare.py --seeds 42,43,44 --phase1-epochs 3 --phase2-epochs 3 --replay-fractions 0,0.02,0.05,0.10,0.20

import argparse
import copy
import csv
import math
import random
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import ConcatDataset, DataLoader, Dataset, Subset
from torchvision import datasets, transforms


# -----------------------------
# Utilities
# -----------------------------


def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_float_list(text: str) -> List[float]:
    vals = []
    for x in text.split(','):
        x = x.strip()
        if x:
            vals.append(float(x))
    return vals


def parse_int_list(text: str) -> List[int]:
    vals = []
    for x in text.split(','):
        x = x.strip()
        if x:
            vals.append(int(x))
    return vals


def pct(x: float) -> str:
    return f"{100.0 * x:5.1f}%"


def fmt(x: float) -> str:
    return f"{x:.4f}"


# -----------------------------
# Dataset helpers
# -----------------------------


def filter_by_digits(dataset: Dataset, digits: Sequence[int]) -> Subset:
    wanted = set(int(d) for d in digits)
    if hasattr(dataset, 'targets'):
        labels = dataset.targets
        indices = [i for i, y in enumerate(labels) if int(y) in wanted]
    else:
        indices = [i for i, (_, y) in enumerate(dataset) if int(y) in wanted]
    return Subset(dataset, indices)


class MarkedDataset(Dataset):
    """Wraps a dataset and returns (x, y, source_flag). source_flag: 0=new, 1=replay."""

    def __init__(self, base: Dataset, source_flag: int) -> None:
        self.base = base
        self.source_flag = int(source_flag)

    def __len__(self) -> int:
        return len(self.base)

    def __getitem__(self, idx: int):
        x, y = self.base[idx]
        return x, y, self.source_flag


def make_loaders(
    data_dir: str,
    batch_size: int,
    old_digits: Sequence[int],
    held_out_digits: Sequence[int],
) -> Tuple[DataLoader, DataLoader, DataLoader, DataLoader, DataLoader, Subset, Subset]:
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])

    train_full = datasets.MNIST(root=data_dir, train=True, download=True, transform=transform)
    test_full = datasets.MNIST(root=data_dir, train=False, download=True, transform=transform)

    train_old = filter_by_digits(train_full, old_digits)
    train_new = filter_by_digits(train_full, held_out_digits)
    test_old = filter_by_digits(test_full, old_digits)
    test_new = filter_by_digits(test_full, held_out_digits)

    train_old_loader = DataLoader(train_old, batch_size=batch_size, shuffle=True)
    train_new_loader = DataLoader(train_new, batch_size=batch_size, shuffle=True)
    test_old_loader = DataLoader(test_old, batch_size=batch_size, shuffle=False)
    test_new_loader = DataLoader(test_new, batch_size=batch_size, shuffle=False)
    test_all_loader = DataLoader(test_full, batch_size=batch_size, shuffle=False)

    return (
        train_old_loader,
        train_new_loader,
        test_old_loader,
        test_new_loader,
        test_all_loader,
        train_old,
        train_new,
    )


# -----------------------------
# Same CNN for every condition
# -----------------------------


class SmallCNN(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, 10)

    def features(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = torch.flatten(x, 1)
        x = F.relu(self.fc1(x))
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        return self.fc2(x)


# -----------------------------
# Training strategy definitions
# -----------------------------


@dataclass
class Strategy:
    name: str
    memory_mode: str  # none, random, curated
    soft_consolidation: bool = False
    anchor_lambda: float = 0.0
    distill_lambda: float = 0.0
    temperature: float = 2.0


STRATEGIES: List[Strategy] = [
    Strategy(
        name='Conventional CNN: no replay',
        memory_mode='none',
    ),
    Strategy(
        name='Conventional CNN: random replay',
        memory_mode='random',
    ),
    Strategy(
        name='Conventional CNN: curated replay',
        memory_mode='curated',
    ),
    Strategy(
        name='Memory-loop: curated + soft consolidation',
        memory_mode='curated',
        soft_consolidation=True,
    ),
    Strategy(
        name='Memory-loop: curated + soft consolidation + anchor/distill',
        memory_mode='curated',
        soft_consolidation=True,
        anchor_lambda=5.0,
        distill_lambda=0.7,
        temperature=2.0,
    ),
]


def make_optimizer(
    model: SmallCNN,
    base_lr: float,
    soft_consolidation: bool,
) -> torch.optim.Optimizer:
    """
    Same model parameters. Different phase-2 learning schedule.

    Conventional:
        all layers use base_lr.

    Soft consolidation:
        conv1 slows strongly, conv2 slows moderately, fc layers stay plastic.
        This is not a hard freeze; early visual machinery can still move.
    """
    if not soft_consolidation:
        lr_conv1 = base_lr
        lr_conv2 = base_lr
        lr_fc1 = base_lr
        lr_fc2 = base_lr
    else:
        lr_conv1 = base_lr * 0.05
        lr_conv2 = base_lr * 0.20
        lr_fc1 = base_lr
        lr_fc2 = base_lr

    return torch.optim.Adam([
        {'name': 'conv1', 'params': model.conv1.parameters(), 'lr': lr_conv1},
        {'name': 'conv2', 'params': model.conv2.parameters(), 'lr': lr_conv2},
        {'name': 'fc1', 'params': model.fc1.parameters(), 'lr': lr_fc1},
        {'name': 'fc2', 'params': model.fc2.parameters(), 'lr': lr_fc2},
    ])


# -----------------------------
# Phase 1 loss masking
# -----------------------------


def mask_logits_to_digits(logits: torch.Tensor, allowed_digits: Optional[Sequence[int]]) -> torch.Tensor:
    if allowed_digits is None:
        return logits
    masked = torch.full_like(logits, -1e9)
    idx = torch.tensor(list(allowed_digits), dtype=torch.long, device=logits.device)
    masked[:, idx] = logits[:, idx]
    return masked


# -----------------------------
# Evaluation
# -----------------------------


@torch.no_grad()
def accuracy(model: nn.Module, loader: DataLoader, device: str) -> float:
    model.eval()
    correct = 0
    total = 0
    for x, y in loader:
        x = x.to(device)
        y = y.to(device)
        logits = model(x)
        pred = logits.argmax(dim=1)
        correct += int((pred == y).sum().item())
        total += int(y.numel())
    return correct / max(1, total)


# -----------------------------
# Phase 1 training
# -----------------------------


def train_phase1(
    model: SmallCNN,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: str,
    old_digits: Sequence[int],
    epochs: int,
    test_old_loader: DataLoader,
    quiet: bool,
) -> None:
    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0
        total_seen = 0

        for x, y in loader:
            x = x.to(device)
            y = y.to(device)

            optimizer.zero_grad(set_to_none=True)
            logits = model(x)
            logits = mask_logits_to_digits(logits, old_digits)
            loss = F.cross_entropy(logits, y)
            loss.backward()
            optimizer.step()

            total_loss += float(loss.item()) * x.size(0)
            total_seen += x.size(0)

        if not quiet:
            old_acc = accuracy(model, test_old_loader, device)
            print(f"Phase 1 epoch {epoch:02d} | loss {total_loss / max(1, total_seen):.4f} | old_acc {old_acc:.4f}")


# -----------------------------
# Curated memory selection
# -----------------------------


@torch.no_grad()
def collect_old_features(
    model: SmallCNN,
    train_old_subset: Subset,
    batch_size: int,
    device: str,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    Returns:
        rel_indices: indices into train_old_subset
        labels: labels
        features: fc1 embeddings
        correct_probs: model probability assigned to the true label
    """
    loader = DataLoader(train_old_subset, batch_size=batch_size, shuffle=False)
    model.eval()

    all_rel_indices: List[torch.Tensor] = []
    all_labels: List[torch.Tensor] = []
    all_feats: List[torch.Tensor] = []
    all_probs: List[torch.Tensor] = []

    offset = 0
    for x, y in loader:
        batch_n = x.size(0)
        rel_idx = torch.arange(offset, offset + batch_n, dtype=torch.long)
        offset += batch_n

        x = x.to(device)
        y_dev = y.to(device)
        feats = model.features(x)
        logits = model.fc2(feats)
        probs = F.softmax(logits, dim=1)
        true_probs = probs.gather(1, y_dev.view(-1, 1)).squeeze(1)

        all_rel_indices.append(rel_idx.cpu())
        all_labels.append(y.long().cpu())
        all_feats.append(feats.cpu())
        all_probs.append(true_probs.cpu())

    return (
        torch.cat(all_rel_indices, dim=0),
        torch.cat(all_labels, dim=0),
        torch.cat(all_feats, dim=0),
        torch.cat(all_probs, dim=0),
    )


def split_budget_by_class(total_budget: int, classes: Sequence[int]) -> Dict[int, int]:
    classes = list(classes)
    if total_budget <= 0:
        return {c: 0 for c in classes}
    base = total_budget // len(classes)
    rem = total_budget % len(classes)
    out = {}
    for i, c in enumerate(classes):
        out[int(c)] = base + (1 if i < rem else 0)
    return out


def select_random_memory_indices(
    train_old_subset: Subset,
    budget: int,
    seed: int,
) -> List[int]:
    if budget <= 0:
        return []
    rng = random.Random(seed)
    budget = min(budget, len(train_old_subset))
    return rng.sample(range(len(train_old_subset)), budget)


def select_curated_memory_indices(
    model: SmallCNN,
    train_old_subset: Subset,
    old_digits: Sequence[int],
    budget: int,
    batch_size: int,
    device: str,
    seed: int,
    hard_fraction: float = 0.40,
) -> List[int]:
    """
    Model-chosen memory loop.

    Balanced per old digit. Within each digit, keep two kinds of examples:
      1. Representative prototypes: closest to that class's feature centroid.
      2. Hard boundary examples: lowest true-label confidence.

    This is a simple proxy for a system deciding what belongs in the memory loop:
    remember the central concept and the fragile edge cases.
    """
    if budget <= 0:
        return []

    budget = min(budget, len(train_old_subset))
    rel_indices, labels, feats, true_probs = collect_old_features(
        model=model,
        train_old_subset=train_old_subset,
        batch_size=batch_size,
        device=device,
    )

    rng = random.Random(seed)
    class_budgets = split_budget_by_class(budget, old_digits)
    selected: List[int] = []

    for digit in old_digits:
        digit = int(digit)
        k = class_budgets[digit]
        if k <= 0:
            continue

        mask = labels == digit
        class_rel = rel_indices[mask]
        class_feats = feats[mask]
        class_probs = true_probs[mask]

        if len(class_rel) <= k:
            selected.extend([int(i) for i in class_rel.tolist()])
            continue

        # Representative examples: close to centroid in feature space.
        centroid = class_feats.mean(dim=0, keepdim=True)
        dists = torch.sum((class_feats - centroid) ** 2, dim=1)

        n_hard = int(round(k * hard_fraction))
        n_rep = k - n_hard

        chosen_local = set()

        if n_rep > 0:
            rep_order = torch.argsort(dists, descending=False).tolist()
            for j in rep_order:
                if len(chosen_local) >= n_rep:
                    break
                chosen_local.add(int(j))

        if n_hard > 0:
            # Hard = lowest correct probability, excluding already selected reps.
            hard_order = torch.argsort(class_probs, descending=False).tolist()
            for j in hard_order:
                if len(chosen_local) >= k:
                    break
                chosen_local.add(int(j))

        # If duplicates left us short, fill randomly from remaining class members.
        if len(chosen_local) < k:
            remaining = [j for j in range(len(class_rel)) if j not in chosen_local]
            rng.shuffle(remaining)
            for j in remaining:
                if len(chosen_local) >= k:
                    break
                chosen_local.add(int(j))

        selected.extend([int(class_rel[j].item()) for j in chosen_local])

    if len(selected) > budget:
        rng.shuffle(selected)
        selected = selected[:budget]

    return selected


# -----------------------------
# Replay loader construction
# -----------------------------


def replay_budget_from_fraction(n_new: int, replay_fraction: float, n_old: int) -> int:
    """
    replay_fraction means old replay / total phase-2 examples.
    Example: if replay_fraction=0.20, phase 2 is 80% new and 20% old.
    """
    if replay_fraction <= 0:
        return 0
    if replay_fraction >= 1:
        raise ValueError('replay_fraction must be < 1.0')
    budget = int((replay_fraction / (1.0 - replay_fraction)) * n_new)
    return min(max(1, budget), n_old)


def make_phase2_loader(
    train_new_subset: Subset,
    train_old_subset: Subset,
    memory_indices: Sequence[int],
    batch_size: int,
    seed: int,
) -> DataLoader:
    new_marked = MarkedDataset(train_new_subset, source_flag=0)

    if len(memory_indices) > 0:
        replay_subset = Subset(train_old_subset, list(memory_indices))
        replay_marked = MarkedDataset(replay_subset, source_flag=1)
        dataset = ConcatDataset([new_marked, replay_marked])
    else:
        dataset = new_marked

    generator = torch.Generator()
    generator.manual_seed(seed)
    return DataLoader(dataset, batch_size=batch_size, shuffle=True, generator=generator)


# -----------------------------
# Phase 2 special losses
# -----------------------------


def normalized_anchor_loss(
    model: SmallCNN,
    anchor_state: Dict[str, torch.Tensor],
    device: str,
) -> torch.Tensor:
    """
    L2 anchor to the phase-1 solution.
    Normalized per tensor so the coefficient is easier to tune.
    """
    loss = torch.tensor(0.0, device=device)
    for name, param in model.named_parameters():
        old = anchor_state[name].to(device)
        loss = loss + torch.mean((param - old) ** 2)
    return loss


def distillation_loss(
    student_logits: torch.Tensor,
    teacher_logits: torch.Tensor,
    temperature: float,
) -> torch.Tensor:
    T = temperature
    student_log_probs = F.log_softmax(student_logits / T, dim=1)
    teacher_probs = F.softmax(teacher_logits / T, dim=1)
    return F.kl_div(student_log_probs, teacher_probs, reduction='batchmean') * (T * T)


# -----------------------------
# Phase 2 training
# -----------------------------


def train_phase2(
    model: SmallCNN,
    teacher: Optional[SmallCNN],
    phase2_loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: str,
    epochs: int,
    strategy: Strategy,
    anchor_state: Optional[Dict[str, torch.Tensor]],
    test_old_loader: DataLoader,
    quiet: bool,
) -> None:
    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0
        total_ce = 0.0
        total_anchor = 0.0
        total_distill = 0.0
        total_seen = 0

        for x, y, source in phase2_loader:
            x = x.to(device)
            y = y.to(device)
            source = source.to(device)

            optimizer.zero_grad(set_to_none=True)
            logits = model(x)
            ce = F.cross_entropy(logits, y)
            loss = ce

            anchor = torch.tensor(0.0, device=device)
            if strategy.anchor_lambda > 0 and anchor_state is not None:
                anchor = normalized_anchor_loss(model, anchor_state, device)
                loss = loss + strategy.anchor_lambda * anchor

            distill = torch.tensor(0.0, device=device)
            if strategy.distill_lambda > 0 and teacher is not None:
                replay_mask = source == 1
                if int(replay_mask.sum().item()) > 0:
                    with torch.no_grad():
                        teacher_logits = teacher(x[replay_mask])
                    student_logits = logits[replay_mask]
                    distill = distillation_loss(student_logits, teacher_logits, strategy.temperature)
                    loss = loss + strategy.distill_lambda * distill

            loss.backward()
            optimizer.step()

            n = x.size(0)
            total_loss += float(loss.item()) * n
            total_ce += float(ce.item()) * n
            total_anchor += float(anchor.item()) * n
            total_distill += float(distill.item()) * n
            total_seen += n

        if not quiet:
            old_acc = accuracy(model, test_old_loader, device)
            print(
                f"Phase 2 epoch {epoch:02d} "
                f"| loss {total_loss / max(1, total_seen):.4f} "
                f"| ce {total_ce / max(1, total_seen):.4f} "
                f"| anchor {total_anchor / max(1, total_seen):.6f} "
                f"| distill {total_distill / max(1, total_seen):.4f} "
                f"| old_acc {old_acc:.4f}"
            )


# -----------------------------
# Experiment runner
# -----------------------------


def run_strategy_from_same_phase1(
    strategy: Strategy,
    replay_fraction: float,
    seed: int,
    phase1_state: Dict[str, torch.Tensor],
    train_old_subset: Subset,
    train_new_subset: Subset,
    old_digits: Sequence[int],
    test_old_loader: DataLoader,
    test_new_loader: DataLoader,
    test_all_loader: DataLoader,
    batch_size: int,
    phase2_epochs: int,
    base_lr: float,
    device: str,
    quiet: bool,
) -> Dict[str, object]:
    n_new = len(train_new_subset)
    budget = replay_budget_from_fraction(n_new, replay_fraction, len(train_old_subset))

    # Every phase-2 condition starts from the exact same phase-1 state.
    model = SmallCNN().to(device)
    model.load_state_dict(copy.deepcopy(phase1_state))

    teacher = None
    if strategy.distill_lambda > 0:
        teacher = SmallCNN().to(device)
        teacher.load_state_dict(copy.deepcopy(phase1_state))
        teacher.eval()
        for p in teacher.parameters():
            p.requires_grad_(False)

    if strategy.memory_mode == 'none' or replay_fraction <= 0:
        memory_indices: List[int] = []
    elif strategy.memory_mode == 'random':
        memory_indices = select_random_memory_indices(
            train_old_subset=train_old_subset,
            budget=budget,
            seed=seed + 1000,
        )
    elif strategy.memory_mode == 'curated':
        memory_indices = select_curated_memory_indices(
            model=model,
            train_old_subset=train_old_subset,
            old_digits=old_digits,
            budget=budget,
            batch_size=batch_size,
            device=device,
            seed=seed + 2000,
        )
    else:
        raise ValueError(f'Unknown memory_mode: {strategy.memory_mode}')

    phase2_loader = make_phase2_loader(
        train_new_subset=train_new_subset,
        train_old_subset=train_old_subset,
        memory_indices=memory_indices,
        batch_size=batch_size,
        seed=seed + 3000,
    )

    optimizer = make_optimizer(
        model=model,
        base_lr=base_lr,
        soft_consolidation=strategy.soft_consolidation,
    )

    if not quiet:
        print('=' * 110)
        print(f"{strategy.name} | replay={pct(replay_fraction)} | budget={len(memory_indices)}")
        print('=' * 110)

    old_before = accuracy(model, test_old_loader, device)
    new_before = accuracy(model, test_new_loader, device)
    all_before = accuracy(model, test_all_loader, device)

    train_phase2(
        model=model,
        teacher=teacher,
        phase2_loader=phase2_loader,
        optimizer=optimizer,
        device=device,
        epochs=phase2_epochs,
        strategy=strategy,
        anchor_state=phase1_state,
        test_old_loader=test_old_loader,
        quiet=quiet,
    )

    old_after = accuracy(model, test_old_loader, device)
    new_after = accuracy(model, test_new_loader, device)
    all_after = accuracy(model, test_all_loader, device)
    forgetting = old_before - old_after

    # Useful but simple score: value final global performance and punish forgetting.
    score = all_after - forgetting

    if not quiet:
        print(
            f"Result | Old P2={old_after:.4f} | New P2={new_after:.4f} | "
            f"All P2={all_after:.4f} | Forget={forgetting:.4f} | Score={score:.4f}"
        )
        print()

    return {
        'seed': seed,
        'strategy': strategy.name,
        'replay_fraction': replay_fraction,
        'memory_mode': strategy.memory_mode,
        'memory_budget': len(memory_indices),
        'soft_consolidation': strategy.soft_consolidation,
        'anchor_lambda': strategy.anchor_lambda,
        'distill_lambda': strategy.distill_lambda,
        'old_acc_phase1': old_before,
        'new_acc_phase1': new_before,
        'all_acc_phase1': all_before,
        'old_acc_phase2': old_after,
        'new_acc_phase2': new_after,
        'all_acc_phase2': all_after,
        'forgetting': forgetting,
        'score': score,
    }


def summarize(results: List[Dict[str, object]]) -> None:
    print('\nFINAL RESULTS')
    print('=' * 170)
    header = (
        f"{'Seed':>5s} "
        f"{'Replay':>8s} "
        f"{'Strategy':58s} "
        f"{'Budget':>7s} "
        f"{'Old P1':>8s} "
        f"{'New P1':>8s} "
        f"{'All P1':>8s} "
        f"{'Old P2':>8s} "
        f"{'New P2':>8s} "
        f"{'All P2':>8s} "
        f"{'Forget':>8s} "
        f"{'Score':>8s}"
    )
    print(header)
    print('-' * 170)

    rows = sorted(results, key=lambda r: (int(r['seed']), float(r['replay_fraction']), str(r['strategy'])))
    for r in rows:
        print(
            f"{int(r['seed']):5d} "
            f"{pct(float(r['replay_fraction'])):>8s} "
            f"{str(r['strategy']):58s} "
            f"{int(r['memory_budget']):7d} "
            f"{fmt(float(r['old_acc_phase1'])):>8s} "
            f"{fmt(float(r['new_acc_phase1'])):>8s} "
            f"{fmt(float(r['all_acc_phase1'])):>8s} "
            f"{fmt(float(r['old_acc_phase2'])):>8s} "
            f"{fmt(float(r['new_acc_phase2'])):>8s} "
            f"{fmt(float(r['all_acc_phase2'])):>8s} "
            f"{fmt(float(r['forgetting'])):>8s} "
            f"{fmt(float(r['score'])):>8s}"
        )

    print('\nBEST BY REPLAY FRACTION')
    print('=' * 170)
    seeds = sorted(set(int(r['seed']) for r in results))
    replay_vals = sorted(set(float(r['replay_fraction']) for r in results))

    for replay in replay_vals:
        subset = [r for r in results if float(r['replay_fraction']) == replay]
        # If multiple seeds, average each strategy.
        by_strategy: Dict[str, List[Dict[str, object]]] = {}
        for r in subset:
            by_strategy.setdefault(str(r['strategy']), []).append(r)

        summaries = []
        for strat, rows in by_strategy.items():
            avg = lambda key: sum(float(x[key]) for x in rows) / len(rows)
            summaries.append({
                'strategy': strat,
                'n': len(rows),
                'old_p2': avg('old_acc_phase2'),
                'new_p2': avg('new_acc_phase2'),
                'all_p2': avg('all_acc_phase2'),
                'forget': avg('forgetting'),
                'score': avg('score'),
            })
        summaries.sort(key=lambda x: (x['score'], x['all_p2'], -x['forget']), reverse=True)
        best = summaries[0]
        print(
            f"Replay {pct(replay)} | best avg over {best['n']} seed(s): "
            f"{best['strategy']} | Old P2={best['old_p2']:.4f} | "
            f"New P2={best['new_p2']:.4f} | All P2={best['all_p2']:.4f} | "
            f"Forget={best['forget']:.4f} | Score={best['score']:.4f}"
        )


def save_csv(results: List[Dict[str, object]], path: str) -> None:
    if not results:
        return
    fieldnames = list(results[0].keys())
    with open(path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', type=str, default='./data')
    parser.add_argument('--batch-size', type=int, default=128)
    parser.add_argument('--phase1-epochs', type=int, default=3)
    parser.add_argument('--phase2-epochs', type=int, default=3)
    parser.add_argument('--base-lr', type=float, default=1e-3)
    parser.add_argument('--held-out', type=str, default='3,6,9')
    parser.add_argument('--replay-fractions', type=str, default='0,0.02,0.05,0.10,0.20')
    parser.add_argument('--seeds', type=str, default='42')
    parser.add_argument('--csv', type=str, default='mnist_memory_loop_results.csv')
    parser.add_argument('--quiet', action='store_true')
    args = parser.parse_args()

    held_out_digits = parse_int_list(args.held_out)
    old_digits = [d for d in range(10) if d not in held_out_digits]
    replay_fractions = parse_float_list(args.replay_fractions)
    seeds = parse_int_list(args.seeds)

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Device:           {device}")
    print(f"Old digits:       {old_digits}")
    print(f"Held-out digits:  {held_out_digits}")
    print(f"Replay fractions: {replay_fractions}")
    print(f"Seeds:            {seeds}")
    print(f"CNN architecture: identical for every strategy")
    print()

    loaders = make_loaders(
        data_dir=args.data_dir,
        batch_size=args.batch_size,
        old_digits=old_digits,
        held_out_digits=held_out_digits,
    )
    (
        train_old_loader,
        _train_new_loader,
        test_old_loader,
        test_new_loader,
        test_all_loader,
        train_old_subset,
        train_new_subset,
    ) = loaders

    results: List[Dict[str, object]] = []

    for seed in seeds:
        print('\n' + '#' * 110)
        print(f"PHASE 1: train one conventional CNN on old digits only | seed={seed}")
        print('#' * 110)
        set_seed(seed)
        phase1_model = SmallCNN().to(device)
        phase1_optimizer = make_optimizer(
            model=phase1_model,
            base_lr=args.base_lr,
            soft_consolidation=False,
        )
        train_phase1(
            model=phase1_model,
            loader=train_old_loader,
            optimizer=phase1_optimizer,
            device=device,
            old_digits=old_digits,
            epochs=args.phase1_epochs,
            test_old_loader=test_old_loader,
            quiet=args.quiet,
        )

        phase1_old = accuracy(phase1_model, test_old_loader, device)
        phase1_new = accuracy(phase1_model, test_new_loader, device)
        phase1_all = accuracy(phase1_model, test_all_loader, device)
        print(f"Phase 1 saved state | old={phase1_old:.4f} | new={phase1_new:.4f} | all={phase1_all:.4f}")

        phase1_state = copy.deepcopy(phase1_model.state_dict())

        for replay_fraction in replay_fractions:
            for strategy in STRATEGIES:
                # No-replay condition is identical regardless of replay_fraction.
                # Still keep it in the table at each fraction for easy comparison.
                result = run_strategy_from_same_phase1(
                    strategy=strategy,
                    replay_fraction=replay_fraction,
                    seed=seed,
                    phase1_state=phase1_state,
                    train_old_subset=train_old_subset,
                    train_new_subset=train_new_subset,
                    old_digits=old_digits,
                    test_old_loader=test_old_loader,
                    test_new_loader=test_new_loader,
                    test_all_loader=test_all_loader,
                    batch_size=args.batch_size,
                    phase2_epochs=args.phase2_epochs,
                    base_lr=args.base_lr,
                    device=device,
                    quiet=args.quiet,
                )
                results.append(result)

    summarize(results)
    save_csv(results, args.csv)
    print(f"\nSaved results to: {args.csv}")


if __name__ == '__main__':
    main()
