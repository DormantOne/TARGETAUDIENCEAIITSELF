@echo off
cd /d "%~dp0"
python micro_lifelong_llm.py --corpus-dir corpus --steps-per-phase 300 --memory-per-phase 300 --generate-every-phase --prompt "Memory is"
pause
