
# fastslow_full.py
#
# Continual MNIST experiment:
# 1) Train on 7 digits.
# 2) Then train on the 3 held-out digits, optionally with a small replay buffer.
# 3) Compare regular CNN, fixed layer-rate CNNs, and adaptive early-lock CNN.
#
# Run:
#   pip install torch torchvision
#   python fastslow_full.py
#
# Optional:
#   python fastslow_full.py --phase1-epochs 3 --phase2-epochs 3 --replay-fractions 0,0.05,0.10,0.20,0.50

import argparse
import csv
import random
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import ConcatDataset, DataLoader, Subset
from torchvision import datasets, transforms


# -----------------------------
# Model config
# -----------------------------

@dataclass
class ModelConfig:
    name: str

    lr_conv1: float
    lr_conv2: float
    lr_fc1: float
    lr_fc2: float

    adaptive_lock: bool = False

    conv1_lock_acc: Optional[float] = None
    conv2_lock_acc: Optional[float] = None
    fc1_lock_acc: Optional[float] = None

    locked_lr: float = 1e-6


CONFIGS: List[ModelConfig] = [
    ModelConfig(
        name="Regular CNN",
        lr_conv1=1e-3,
        lr_conv2=1e-3,
        lr_fc1=1e-3,
        lr_fc2=1e-3,
    ),
    ModelConfig(
        name="Fixed front-fast/back-slow CNN",
        lr_conv1=3e-3,
        lr_conv2=1e-3,
        lr_fc1=3e-4,
        lr_fc2=1e-4,
    ),
    ModelConfig(
        name="Fixed front-slow/back-fast CNN",
        lr_conv1=1e-4,
        lr_conv2=3e-4,
        lr_fc1=1e-3,
        lr_fc2=3e-3,
    ),
    ModelConfig(
        name="Adaptive early-lock CNN",
        lr_conv1=3e-3,
        lr_conv2=1e-3,
        lr_fc1=1e-3,
        lr_fc2=1e-3,
        adaptive_lock=True,

        # Layer-consolidation thresholds.
        # When old-digit accuracy crosses these thresholds, the layer slows way down.
        conv1_lock_acc=0.970,
        conv2_lock_acc=0.985,

        # Keep fc1/fc2 plastic by default. Locking classifiers often prevents adaptation.
        fc1_lock_acc=None,

        locked_lr=1e-6,
    ),
]


# -----------------------------
# Utilities
# -----------------------------

def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def parse_replay_fractions(text: str) -> List[float]:
    vals = []
    for part in text.split(","):
        part = part.strip()
        if not part:
            continue
        val = float(part)
        if val < 0.0 or val >= 1.0:
            raise ValueError("Replay fractions must be >= 0.0 and < 1.0")
        vals.append(val)
    return vals


def pct(x: float) -> str:
    return f"{100.0 * x:5.1f}%"


def format_acc(x: float) -> str:
    return f"{x:.4f}"


# -----------------------------
# Dataset helpers
# -----------------------------

def filter_by_digits(dataset, digits: List[int]) -> Subset:
    wanted = set(int(d) for d in digits)

    # MNIST has .targets, which avoids calling __getitem__ repeatedly.
    if hasattr(dataset, "targets"):
        labels = dataset.targets
        indices = [i for i, y in enumerate(labels) if int(y) in wanted]
    else:
        indices = [i for i, (_, y) in enumerate(dataset) if int(y) in wanted]

    return Subset(dataset, indices)


def make_loaders(
    data_dir: str,
    batch_size: int,
    old_digits: List[int],
    held_out_digits: List[int],
) -> Tuple[DataLoader, DataLoader, DataLoader, DataLoader, DataLoader, Subset, Subset]:
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])

    train_full = datasets.MNIST(
        root=data_dir,
        train=True,
        download=True,
        transform=transform,
    )

    test_full = datasets.MNIST(
        root=data_dir,
        train=False,
        download=True,
        transform=transform,
    )

    train_old = filter_by_digits(train_full, old_digits)
    train_new = filter_by_digits(train_full, held_out_digits)

    test_old = filter_by_digits(test_full, old_digits)
    test_new = filter_by_digits(test_full, held_out_digits)

    train_old_loader = DataLoader(train_old, batch_size=batch_size, shuffle=True)
    train_new_loader = DataLoader(train_new, batch_size=batch_size, shuffle=True)

    test_old_loader = DataLoader(test_old, batch_size=batch_size, shuffle=False)
    test_new_loader = DataLoader(test_new, batch_size=batch_size, shuffle=False)
    test_all_loader = DataLoader(test_full, batch_size=batch_size, shuffle=False)

    return (
        train_old_loader,
        train_new_loader,
        test_old_loader,
        test_new_loader,
        test_all_loader,
        train_old,
        train_new,
    )


def make_replay_loader(
    train_new_subset: Subset,
    train_old_subset: Subset,
    replay_fraction: float,
    batch_size: int,
    seed: int,
) -> DataLoader:
    """
    Phase-2 dataset.

    replay_fraction means fraction of phase-2 examples that are old replay examples.

    replay_fraction = 0.00:
        100% new digits, 0% old digits.

    replay_fraction = 0.20:
        80% new digits, 20% old replay.

    replay_fraction = 0.50:
        50% new digits, 50% old replay.
    """
    if replay_fraction <= 0.0:
        generator = torch.Generator()
        generator.manual_seed(seed)
        return DataLoader(
            train_new_subset,
            batch_size=batch_size,
            shuffle=True,
            generator=generator,
        )

    n_new = len(train_new_subset)

    old_replay_size = int((replay_fraction / (1.0 - replay_fraction)) * n_new)
    old_replay_size = max(1, old_replay_size)
    old_replay_size = min(old_replay_size, len(train_old_subset))

    rng = random.Random(seed)
    old_indices = rng.sample(range(len(train_old_subset)), old_replay_size)

    old_replay_subset = Subset(train_old_subset, old_indices)

    mixed_dataset = ConcatDataset([
        train_new_subset,
        old_replay_subset,
    ])

    generator = torch.Generator()
    generator.manual_seed(seed)

    return DataLoader(
        mixed_dataset,
        batch_size=batch_size,
        shuffle=True,
        generator=generator,
    )


# -----------------------------
# CNN model
# -----------------------------

class SmallCNN(nn.Module):
    def __init__(self) -> None:
        super().__init__()

        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)

        self.pool = nn.MaxPool2d(2, 2)

        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pool(F.relu(self.conv1(x)))  # 28x28 -> 14x14
        x = self.pool(F.relu(self.conv2(x)))  # 14x14 -> 7x7
        x = torch.flatten(x, 1)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x


# -----------------------------
# Optimizer / adaptive locks
# -----------------------------

def make_optimizer(model: SmallCNN, cfg: ModelConfig) -> torch.optim.Optimizer:
    return torch.optim.Adam([
        {
            "name": "conv1",
            "params": model.conv1.parameters(),
            "lr": cfg.lr_conv1,
        },
        {
            "name": "conv2",
            "params": model.conv2.parameters(),
            "lr": cfg.lr_conv2,
        },
        {
            "name": "fc1",
            "params": model.fc1.parameters(),
            "lr": cfg.lr_fc1,
        },
        {
            "name": "fc2",
            "params": model.fc2.parameters(),
            "lr": cfg.lr_fc2,
        },
    ])


def set_group_lr(optimizer: torch.optim.Optimizer, group_name: str, new_lr: float) -> None:
    for group in optimizer.param_groups:
        if group.get("name") == group_name:
            group["lr"] = new_lr


def get_group_lrs(optimizer: torch.optim.Optimizer) -> Dict[str, float]:
    out = {}
    for group in optimizer.param_groups:
        out[str(group.get("name"))] = float(group["lr"])
    return out


def lr_string(optimizer: torch.optim.Optimizer) -> str:
    lrs = get_group_lrs(optimizer)
    return " | ".join(f"{k}={v:.1e}" for k, v in lrs.items())


def maybe_lock_layers(
    cfg: ModelConfig,
    optimizer: torch.optim.Optimizer,
    old_acc: float,
    lock_state: Dict[str, bool],
) -> List[str]:
    events = []

    if not cfg.adaptive_lock:
        return events

    if cfg.conv1_lock_acc is not None:
        if old_acc >= cfg.conv1_lock_acc and not lock_state["conv1"]:
            set_group_lr(optimizer, "conv1", cfg.locked_lr)
            lock_state["conv1"] = True
            events.append(f"LOCK conv1 at old_acc={old_acc:.4f}")

    if cfg.conv2_lock_acc is not None:
        if old_acc >= cfg.conv2_lock_acc and not lock_state["conv2"]:
            set_group_lr(optimizer, "conv2", cfg.locked_lr)
            lock_state["conv2"] = True
            events.append(f"LOCK conv2 at old_acc={old_acc:.4f}")

    if cfg.fc1_lock_acc is not None:
        if old_acc >= cfg.fc1_lock_acc and not lock_state["fc1"]:
            set_group_lr(optimizer, "fc1", cfg.locked_lr)
            lock_state["fc1"] = True
            events.append(f"LOCK fc1 at old_acc={old_acc:.4f}")

    return events


# -----------------------------
# Training / eval
# -----------------------------

def mask_logits_to_digits(
    logits: torch.Tensor,
    allowed_digits: Optional[List[int]],
) -> torch.Tensor:
    """
    During phase 1, we train on only old digits.
    Masking prevents the network from being explicitly punished for assigning
    probability to held-out digits it has never seen.

    In phase 2, use allowed_digits=None so all 10 classes compete.
    """
    if allowed_digits is None:
        return logits

    masked = torch.full_like(logits, -1e9)
    allowed = torch.tensor(allowed_digits, dtype=torch.long, device=logits.device)
    masked[:, allowed] = logits[:, allowed]
    return masked


def train_one_epoch(
    model: nn.Module,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: str,
    allowed_digits_for_loss: Optional[List[int]],
) -> float:
    model.train()

    total_loss = 0.0
    total_seen = 0

    for x, y in loader:
        x = x.to(device)
        y = y.to(device)

        optimizer.zero_grad(set_to_none=True)

        logits = model(x)
        logits = mask_logits_to_digits(logits, allowed_digits_for_loss)

        loss = F.cross_entropy(logits, y)
        loss.backward()
        optimizer.step()

        total_loss += float(loss.item()) * x.size(0)
        total_seen += x.size(0)

    return total_loss / max(1, total_seen)


@torch.no_grad()
def accuracy(
    model: nn.Module,
    loader: DataLoader,
    device: str,
) -> float:
    model.eval()

    correct = 0
    total = 0

    for x, y in loader:
        x = x.to(device)
        y = y.to(device)

        logits = model(x)
        pred = logits.argmax(dim=1)

        correct += int((pred == y).sum().item())
        total += int(y.numel())

    return correct / max(1, total)


def train_phase(
    model: nn.Module,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: str,
    epochs: int,
    allowed_digits_for_loss: Optional[List[int]],
    phase_name: str,
    cfg: ModelConfig,
    lock_state: Dict[str, bool],
    test_old_loader: DataLoader,
    quiet: bool = False,
) -> None:
    for epoch in range(1, epochs + 1):
        loss = train_one_epoch(
            model=model,
            loader=loader,
            optimizer=optimizer,
            device=device,
            allowed_digits_for_loss=allowed_digits_for_loss,
        )

        old_acc_now = accuracy(model, test_old_loader, device)
        lock_events = maybe_lock_layers(cfg, optimizer, old_acc_now, lock_state)

        if not quiet:
            msg = (
                f"{phase_name} epoch {epoch:02d} "
                f"| loss {loss:.4f} "
                f"| old_acc {old_acc_now:.4f} "
                f"| {lr_string(optimizer)}"
            )
            print(msg)
            for event in lock_events:
                print("  " + event)


# -----------------------------
# Experiment runner
# -----------------------------

def run_single_experiment(
    cfg: ModelConfig,
    replay_fraction: float,
    loaders,
    old_digits: List[int],
    phase1_epochs: int,
    phase2_epochs: int,
    batch_size: int,
    seed: int,
    device: str,
    quiet: bool = False,
) -> Dict[str, object]:
    (
        train_old_loader,
        _train_new_loader,
        test_old_loader,
        test_new_loader,
        test_all_loader,
        train_old_subset,
        train_new_subset,
    ) = loaders

    # Different but deterministic seed per condition.
    condition_seed = seed + int(replay_fraction * 10000) + abs(hash(cfg.name)) % 1000
    set_seed(condition_seed)

    model = SmallCNN().to(device)
    optimizer = make_optimizer(model, cfg)

    lock_state = {
        "conv1": False,
        "conv2": False,
        "fc1": False,
    }

    if not quiet:
        print("=" * 100)
        print(f"{cfg.name} | replay_fraction={replay_fraction:.2f}")
        print("=" * 100)

    # Phase 1: old digits only.
    # Mask missing classes during loss.
    train_phase(
        model=model,
        loader=train_old_loader,
        optimizer=optimizer,
        device=device,
        epochs=phase1_epochs,
        allowed_digits_for_loss=old_digits,
        phase_name="Phase 1 old digits",
        cfg=cfg,
        lock_state=lock_state,
        test_old_loader=test_old_loader,
        quiet=quiet,
    )

    old_acc_phase1 = accuracy(model, test_old_loader, device)
    new_acc_phase1 = accuracy(model, test_new_loader, device)
    all_acc_phase1 = accuracy(model, test_all_loader, device)

    # Phase 2: new digits + optional old replay.
    phase2_loader = make_replay_loader(
        train_new_subset=train_new_subset,
        train_old_subset=train_old_subset,
        replay_fraction=replay_fraction,
        batch_size=batch_size,
        seed=condition_seed + 123,
    )

    train_phase(
        model=model,
        loader=phase2_loader,
        optimizer=optimizer,
        device=device,
        epochs=phase2_epochs,
        allowed_digits_for_loss=None,
        phase_name=f"Phase 2 new + replay {pct(replay_fraction)}",
        cfg=cfg,
        lock_state=lock_state,
        test_old_loader=test_old_loader,
        quiet=quiet,
    )

    old_acc_phase2 = accuracy(model, test_old_loader, device)
    new_acc_phase2 = accuracy(model, test_new_loader, device)
    all_acc_phase2 = accuracy(model, test_all_loader, device)

    forgetting = old_acc_phase1 - old_acc_phase2

    # A rough one-number score:
    # high overall accuracy is good; forgetting is bad.
    # This is not sacred; it is just useful for sorting.
    stability_score = all_acc_phase2 - forgetting

    lrs = get_group_lrs(optimizer)

    result: Dict[str, object] = {
        "model": cfg.name,
        "replay_fraction": replay_fraction,

        "old_acc_phase1": old_acc_phase1,
        "new_acc_phase1": new_acc_phase1,
        "all_acc_phase1": all_acc_phase1,

        "old_acc_phase2": old_acc_phase2,
        "new_acc_phase2": new_acc_phase2,
        "all_acc_phase2": all_acc_phase2,

        "forgetting": forgetting,
        "stability_score": stability_score,

        "conv1_locked": lock_state["conv1"],
        "conv2_locked": lock_state["conv2"],
        "fc1_locked": lock_state["fc1"],

        "final_lr_conv1": lrs.get("conv1", None),
        "final_lr_conv2": lrs.get("conv2", None),
        "final_lr_fc1": lrs.get("fc1", None),
        "final_lr_fc2": lrs.get("fc2", None),
    }

    if not quiet:
        print()
        print(f"After phase 1 old accuracy: {old_acc_phase1:.4f}")
        print(f"After phase 1 new accuracy: {new_acc_phase1:.4f}")
        print(f"After phase 1 all accuracy: {all_acc_phase1:.4f}")
        print()
        print(f"After phase 2 old accuracy: {old_acc_phase2:.4f}")
        print(f"After phase 2 new accuracy: {new_acc_phase2:.4f}")
        print(f"After phase 2 all accuracy: {all_acc_phase2:.4f}")
        print(f"Forgetting:                 {forgetting:.4f}")
        print(f"Stability score:            {stability_score:.4f}")
        print()

    return result


def print_results_table(results: List[Dict[str, object]]) -> None:
    print()
    print()
    print("FINAL FULL GRID")
    print("=" * 150)

    header = (
        f"{'Replay':>8s} "
        f"{'Model':38s} "
        f"{'Old P1':>8s} "
        f"{'New P1':>8s} "
        f"{'All P1':>8s} "
        f"{'Old P2':>8s} "
        f"{'New P2':>8s} "
        f"{'All P2':>8s} "
        f"{'Forget':>8s} "
        f"{'Score':>8s} "
        f"{'Locks':>12s}"
    )
    print(header)
    print("-" * 150)

    results_sorted = sorted(results, key=lambda r: (float(r["replay_fraction"]), str(r["model"])))

    for r in results_sorted:
        locks = ""
        locks += "C1" if r["conv1_locked"] else "--"
        locks += "/"
        locks += "C2" if r["conv2_locked"] else "--"
        locks += "/"
        locks += "F1" if r["fc1_locked"] else "--"

        print(
            f"{pct(float(r['replay_fraction'])):>8s} "
            f"{str(r['model']):38s} "
            f"{format_acc(float(r['old_acc_phase1'])):>8s} "
            f"{format_acc(float(r['new_acc_phase1'])):>8s} "
            f"{format_acc(float(r['all_acc_phase1'])):>8s} "
            f"{format_acc(float(r['old_acc_phase2'])):>8s} "
            f"{format_acc(float(r['new_acc_phase2'])):>8s} "
            f"{format_acc(float(r['all_acc_phase2'])):>8s} "
            f"{format_acc(float(r['forgetting'])):>8s} "
            f"{format_acc(float(r['stability_score'])):>8s} "
            f"{locks:>12s}"
        )


def print_best_by_replay(results: List[Dict[str, object]]) -> None:
    print()
    print()
    print("BEST BY REPLAY FRACTION")
    print("=" * 150)
    print("Sorted by: highest stability_score = all phase-2 accuracy minus forgetting")
    print("-" * 150)

    fractions = sorted(set(float(r["replay_fraction"]) for r in results))

    for frac in fractions:
        subset = [r for r in results if float(r["replay_fraction"]) == frac]
        subset_sorted = sorted(
            subset,
            key=lambda r: (
                float(r["stability_score"]),
                float(r["all_acc_phase2"]),
                -float(r["forgetting"]),
            ),
            reverse=True,
        )
        best = subset_sorted[0]

        print(
            f"Replay {pct(frac)} | "
            f"best: {best['model']} | "
            f"Old P2={float(best['old_acc_phase2']):.4f} | "
            f"New P2={float(best['new_acc_phase2']):.4f} | "
            f"All P2={float(best['all_acc_phase2']):.4f} | "
            f"Forget={float(best['forgetting']):.4f} | "
            f"Score={float(best['stability_score']):.4f}"
        )


def save_csv(results: List[Dict[str, object]], path: str) -> None:
    if not results:
        return

    fieldnames = list(results[0].keys())

    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in results:
            writer.writerow(r)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=str, default="./data")
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--phase1-epochs", type=int, default=3)
    parser.add_argument("--phase2-epochs", type=int, default=3)
    parser.add_argument("--held-out", type=str, default="3,6,9")
    parser.add_argument("--replay-fractions", type=str, default="0,0.05,0.10,0.20,0.50")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--csv", type=str, default="fastslow_results.csv")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    held_out_digits = [int(x.strip()) for x in args.held_out.split(",") if x.strip()]
    old_digits = [d for d in range(10) if d not in held_out_digits]
    replay_fractions = parse_replay_fractions(args.replay_fractions)

    device = "cuda" if torch.cuda.is_available() else "cpu"

    print(f"Device:          {device}")
    print(f"Old digits:      {old_digits}")
    print(f"Held-out digits: {held_out_digits}")
    print(f"Replay fractions: {replay_fractions}")
    print(f"Phase 1 epochs:  {args.phase1_epochs}")
    print(f"Phase 2 epochs:  {args.phase2_epochs}")
    print()

    set_seed(args.seed)

    loaders = make_loaders(
        data_dir=args.data_dir,
        batch_size=args.batch_size,
        old_digits=old_digits,
        held_out_digits=held_out_digits,
    )

    results: List[Dict[str, object]] = []

    for replay_fraction in replay_fractions:
        for cfg in CONFIGS:
            result = run_single_experiment(
                cfg=cfg,
                replay_fraction=replay_fraction,
                loaders=loaders,
                old_digits=old_digits,
                phase1_epochs=args.phase1_epochs,
                phase2_epochs=args.phase2_epochs,
                batch_size=args.batch_size,
                seed=args.seed,
                device=device,
                quiet=args.quiet,
            )
            results.append(result)

    print_results_table(results)
    print_best_by_replay(results)

    save_csv(results, args.csv)
    print()
    print(f"Saved results to: {args.csv}")


if __name__ == "__main__":
    main()
